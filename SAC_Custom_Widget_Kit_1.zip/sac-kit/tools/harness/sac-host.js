/* ==========================================================================
 * SacHost — a small emulation of the SAC custom-widget framework for local
 * testing (no tenant needed). It mimics what SAC does with a widget:
 *   - reads the contribution JSON (defaults, methods, events)
 *   - calls onCustomWidgetBeforeUpdate / onCustomWidgetAfterUpdate / Resize
 *   - hands over the data binding result set (this.<bindingId>) + dataBindings API
 *   - wires the styling panel <-> widget through "propertiesChanged"
 *   - runs JSON method bodies against a property proxy (like a story script)
 *   - logs widget events and linked-analysis calls
 * It is NOT SAC: always re-test in a real tenant (OSE edit + view mode).
 * ========================================================================== */
(function () {
  "use strict";

  class SacHost {
    constructor({ contribution, mount, panelMount, log, widgetName }) {
      this.c = contribution;
      this.mountEl = mount;
      this.panelMount = panelMount;
      this.log = log || ((...a) => console.log(...a));
      this.widgetName = widgetName || `${contribution.newInstancePrefix || "Widget"}_1`;
      this.props = {};
      Object.entries(contribution.properties || {}).forEach(([k, v]) => (this.props[k] = v.default));
      this.props.widgetName = this.widgetName;
      this.laEnabled = true;
      this.laCalls = [];
      this.events = [];
      this.filters = {};
      this.bindingId = Object.keys(contribution.dataBindings || {})[0] || null;
      this.dataBindings = this._mockDataBindings();
      this.props.dataBindings = this.dataBindings;
    }

    _mockDataBindings() {
      const host = this;
      const dataSource = {
        setDimensionFilter(dim, member) {
          host.filters[dim] = member;
          host.log("DataSource.setDimensionFilter", dim, member);
        },
        removeDimensionFilter(dim) {
          delete host.filters[dim];
          host.log("DataSource.removeDimensionFilter", dim);
        },
        getDimensionFilters(dim) {
          return host.filters[dim] ? [{ value: host.filters[dim] }] : [];
        },
        refreshData() {
          host.log("DataSource.refreshData");
        },
      };
      const linked = {
        isDataPointSelectionEnabled: () => host.laEnabled,
        setFilters: (sel) => {
          host.laCalls.push({ op: "setFilters", sel: JSON.parse(JSON.stringify(sel)) });
          host.log("LinkedAnalysis.setFilters", JSON.stringify(sel));
        },
        removeFilters: () => {
          host.laCalls.push({ op: "removeFilters" });
          host.log("LinkedAnalysis.removeFilters");
        },
      };
      const binding = {
        getLinkedAnalysis: () => linked,
        getDataSource: () => dataSource,
        getDimensions: (feed) => [],
        getMembers: (feed) => [],
        addDimensionToFeed: (feed, dim) => host.log("DataBinding.addDimensionToFeed", feed, dim),
        addMemberToFeed: (feed, mem) => host.log("DataBinding.addMemberToFeed", feed, mem),
        removeDimension: (dim) => host.log("DataBinding.removeDimension", dim),
        removeMember: (mem) => host.log("DataBinding.removeMember", mem),
        setModel: (m) => host.log("DataBinding.setModel", m),
      };
      return { getDataBinding: () => binding };
    }

    mount(tag, stylingTag) {
      const el = document.createElement(tag);
      this.el = el;
      el.dataBindings = this.dataBindings;
      el.addEventListener("propertiesChanged", (e) => {
        const props = e.detail && e.detail.properties;
        this.log("widget → propertiesChanged", JSON.stringify(props));
        this.update(props, "widget");
      });
      Object.keys(this.c.events || {}).forEach((name) =>
        el.addEventListener(name, () => {
          this.events.push(name);
          this.log(`EVENT ${this.widgetName}.${name}()`);
        })
      );
      el.addEventListener("customWidgetRenderComplete", () => {
        this.renderCount = (this.renderCount || 0) + 1;
      });
      this.mountEl.appendChild(el);
      // SAC hands over all persisted properties first
      this._call(el, this.props);
      if (stylingTag && this.panelMount && customElements.get(stylingTag)) {
        const panel = document.createElement(stylingTag);
        this.panel = panel;
        panel.addEventListener("propertiesChanged", (e) => {
          const props = e.detail && e.detail.properties;
          this.log("styling panel → propertiesChanged", JSON.stringify(props));
          this.update(props, "panel");
        });
        this.panelMount.appendChild(panel);
        panel.onCustomWidgetBeforeUpdate(Object.assign({}, this.props));
        if (panel.onCustomWidgetAfterUpdate) panel.onCustomWidgetAfterUpdate(Object.assign({}, this.props));
      }
      return el;
    }

    _call(el, changed) {
      if (el.onCustomWidgetBeforeUpdate) el.onCustomWidgetBeforeUpdate(changed);
      Object.keys(changed).forEach((k) => {
        if (k !== "dataBindings") {
          try {
            el[k] = changed[k];
          } catch (e) {
            /* read-only DOM props */
          }
        }
      });
      if (el.onCustomWidgetAfterUpdate) el.onCustomWidgetAfterUpdate(changed);
    }

    update(changes, source) {
      if (!changes) return;
      Object.assign(this.props, changes);
      this._call(this.el, changes);
      if (this.panel && source !== "panel") this.panel.onCustomWidgetBeforeUpdate(changes);
    }

    setData(binding) {
      if (!this.bindingId) return;
      this.update({ [this.bindingId]: binding }, "host");
    }

    resize(w, h) {
      this.mountEl.style.width = `${w}px`;
      this.mountEl.style.height = `${h}px`;
      if (this.el && this.el.onCustomWidgetResize) this.el.onCustomWidgetResize(w, h);
    }

    /** Run a JSON method body like a story script would: Widget_1.method(args) */
    callMethod(name, args) {
      const m = (this.c.methods || {})[name];
      if (!m) throw new Error(`No method ${name}`);
      const changes = {};
      const host = this;
      const self = new Proxy(
        {},
        {
          get(_, key) {
            if (key === "dataBindings") return host.dataBindings;
            return key in changes ? changes[key] : host.props[key];
          },
          set(_, key, value) {
            changes[key] = value;
            return true;
          },
        }
      );
      const params = (m.parameters || []).map((p) => p.name);
      // eslint-disable-next-line no-new-func
      const fn = new Function(...params, m.body);
      const result = fn.apply(self, args || []);
      if (Object.keys(changes).length) this.update(changes, "script");
      this.log(`SCRIPT ${this.widgetName}.${name}(${(args || []).map((a) => JSON.stringify(a)).join(", ")})`, result === undefined ? "" : `→ ${JSON.stringify(result)}`);
      return result;
    }
  }

  window.SacHost = SacHost;
})();
