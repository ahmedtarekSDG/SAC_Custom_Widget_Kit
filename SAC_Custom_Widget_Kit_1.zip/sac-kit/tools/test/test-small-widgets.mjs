// Headless tests: KPI Card, Member Selector, Starter Template (node tools/test/test-small-widgets.mjs)
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const { chromium } = require("playwright");
import fs from "node:fs";
import path from "node:path";

const BASE = process.env.HARNESS || "http://127.0.0.1:8765/tools/harness/index.html";
const OUT = process.env.OUT || "/tmp/sac-tests";
fs.mkdirSync(OUT, { recursive: true });
const results = [];
const ok = (name, cond, info = "") => {
  results.push({ name, pass: !!cond, info });
  console.log(`${cond ? "PASS" : "FAIL"}  ${name}${info ? "  — " + info : ""}`);
};
const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1200, height: 800 } })).newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
async function open(widget, dataset, props, w, h) {
  await page.goto(`${BASE}?widget=${widget}&dataset=${dataset}&w=${w}&h=${h}` + (props ? `&props=${encodeURIComponent(JSON.stringify(props))}` : ""));
  await page.waitForFunction(() => window.__harnessReady === true);
  await page.waitForTimeout(450);
}
const shot = (n) => page.locator("#mount").screenshot({ path: path.join(OUT, `${n}.png`) });

// KPI card
await open("kpi-card", "monthly_series", { kpiTitle: "Revenue YTD", compareLabel: "vs Budget" }, 340, 220);
let k = await page.evaluate(() => ({ v: window.host.props.currentValue, s: window.host.props.currentStatus, r: window.host.props.currentRatio, txt: document.querySelector("sackit-kpi-card").shadowRoot.querySelector(".value").textContent }));
ok("KPI: value = Σ actual, ratio vs budget, status published", Math.round(k.v / 1e6) === 1512 && k.s === "good" && k.r > 1 && k.txt === "1.5B", JSON.stringify(k));
ok("KPI: getStatus() via script", (await page.evaluate(() => window.host.callMethod("getStatus", []))) === "good");
await shot("kpi-1-total");
await page.locator("sackit-kpi-card .pt").nth(3).click();
await page.waitForTimeout(150);
let la = await page.evaluate(() => window.host.laCalls.slice(-1)[0]);
ok("KPI: sparkline point → setFilters(month)", la && la.sel.Date_m12 === "202604", JSON.stringify(la));
await open("kpi-card", "variance_region", { kpiTitle: "Revenue (last region)", valueMode: "last", sparkType: "bar", thresholds: "98,100" }, 340, 220);
k = await page.evaluate(() => window.host.props.currentStatus);
ok("KPI: last-member mode + thresholds → warning/bad status", k === "warning" || k === "bad" || k === "good", k);
await shot("kpi-2-bars");

// Member selector
await open("member-selector", "variance_region", { displayMode: "chips" }, 640, 160);
await page.locator('sackit-member-selector [data-id="SA_W"]').click();
await page.waitForTimeout(150);
la = await page.evaluate(() => window.host.laCalls.slice(-1)[0]);
ok("Selector: chip → setFilters(single member)", la && la.sel.Region_3kd02ma === "SA_W", JSON.stringify(la));
await page.locator('sackit-member-selector [data-id="AE_DXB"]').click();
await page.waitForTimeout(150);
la = await page.evaluate(() => window.host.laCalls.slice(-1)[0]);
ok("Selector: second chip → Selection[]", la && Array.isArray(la.sel) && la.sel.length === 2);
ok("Selector: getSelectedMembers() for scripts", (await page.evaluate(() => window.host.callMethod("getSelectedMembers", []))) === "SA_W,AE_DXB");
await shot("selector-1-chips");
await page.evaluate(() => window.host.callMethod("setSelectedMembers", ["EG_CAI"]));
await page.waitForTimeout(200);
la = await page.evaluate(() => window.host.laCalls.slice(-1)[0]);
ok("Selector: setSelectedMembers() from script re-applies linked analysis", la && la.sel.Region_3kd02ma === "EG_CAI", JSON.stringify(la));
await page.locator('sackit-member-selector [data-id="__all"]').click();
await page.waitForTimeout(150);
ok("Selector: All → removeFilters", (await page.evaluate(() => window.host.laCalls.slice(-1)[0].op)) === "removeFilters");
await open("member-selector", "variance_region", { displayMode: "list", sortBy: "valueDesc", selectedMembers: "SA_C" }, 320, 360);
la = await page.evaluate(() => window.host.laCalls.slice(-1)[0]);
ok("Selector: persisted selection re-applied on load (bookmark)", la && la.sel.Region_3kd02ma === "SA_C", JSON.stringify(la));
await shot("selector-2-list");
await open("member-selector", "variance_region", { displayMode: "segmented", selectionMode: "single", showValues: false, maxMembers: 5 }, 700, 80);
await shot("selector-3-segmented");

// Starter template
await open("starter-template", "variance_region", null, 420, 300);
await page.locator("sackit-starter-template .row").nth(1).click();
await page.waitForTimeout(150);
la = await page.evaluate(() => window.host.laCalls.slice(-1)[0]);
ok("Starter: row → setFilters + onClick + output property", la && la.sel.Region_3kd02ma === "SA_W" && (await page.evaluate(() => window.host.events.slice(-1)[0])) === "onClick" && (await page.evaluate(() => window.host.callMethod("getClickedMember", []))) === "SA_W");
await page.evaluate(() => window.host.callMethod("setAccentColor", ["#E8743B"]));
await page.waitForTimeout(100);
ok("Starter: setAccentColor() method", (await page.evaluate(() => getComputedStyle(document.querySelector("sackit-starter-template").shadowRoot.querySelector(".bar")).backgroundColor)) === "rgb(232, 116, 59)");
await page.locator("sackit-starter-template-styling #t").fill("Renamed by panel");
await page.locator("sackit-starter-template-styling #t").press("Enter");
await page.locator("sackit-starter-template-styling #t").blur();
await page.waitForTimeout(150);
ok("Starter: hand-written styling panel → propertiesChanged", (await page.evaluate(() => document.querySelector("sackit-starter-template").shadowRoot.querySelector("h3").textContent)) === "Renamed by panel");
await shot("starter-1");
// Starter template on a result set without "state" (the Developer Guide's sample has only data + metadata)
await page.evaluate(() => {
  const b = JSON.parse(JSON.stringify(window.SAC_SAMPLES.variance_region.binding));
  delete b.state;
  window.host.setData(b);
});
await page.waitForTimeout(150);
ok("Starter: renders a binding without a state field", (await page.locator("sackit-starter-template .row").count()) > 3);
ok("No page errors", errors.length === 0, errors.slice(0, 3).join(" | "));
await browser.close();
const failed = results.filter((r) => !r.pass).length;
console.log(`\n${results.length - failed}/${results.length} checks passed`);
process.exit(failed ? 1 : 0);
