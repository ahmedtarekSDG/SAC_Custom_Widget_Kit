// Headless test for the Universal Chart widget — renders all 20 chart types (node tools/test/test-universal.mjs)
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const { chromium } = require("playwright");
import fs from "node:fs";
import path from "node:path";

const BASE = process.env.HARNESS || "http://127.0.0.1:8765/tools/harness/index.html";
const OUT = process.env.OUT || "/tmp/sac-tests/universal";
fs.mkdirSync(OUT, { recursive: true });
const results = [];
const ok = (name, cond, info = "") => {
  results.push({ name, pass: !!cond, info });
  console.log(`${cond ? "PASS" : "FAIL"}  ${name}${info ? "  — " + info : ""}`);
};
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1300, height: 860 }, acceptDownloads: true });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
const T = "sackit-universal-chart";
const CASES = [
  ["bar", "variance_region"], ["barHorizontal", "variance_region"], ["stackedBar", "product_region"], ["stackedPercent", "product_region"],
  ["line", "monthly_series"], ["area", "monthly_series"], ["combo", "monthly_series"], ["pareto", "variance_region"],
  ["pie", "variance_region"], ["donut", "variance_region"], ["rose", "variance_region"], ["funnel", "variance_region"],
  ["gauge", "monthly_series"], ["radar", "product_region"], ["heatmap", "product_region"], ["scatter", "product_region"],
  ["treemap", "costcenter_hierarchy"], ["sunburst", "costcenter_hierarchy"], ["tree", "costcenter_hierarchy"], ["sankey", "product_region"],
];
for (const [type, ds] of CASES) {
  const props = { chartType: type, showTitle: true, chartTitle: type, animation: false, showDataLabels: type === "bar" };
  await page.goto(`${BASE}?widget=universal-chart&dataset=${ds}&w=560&h=340&props=${encodeURIComponent(JSON.stringify(props))}`);
  await page.waitForFunction(() => window.__harnessReady === true);
  await page.waitForTimeout(700);
  const state = await page.evaluate((t) => {
    const el = document.querySelector(t);
    const msg = el.shadowRoot.querySelector(".msg");
    const canvas = el.shadowRoot.querySelector("canvas");
    return { msg: msg.classList.contains("on") ? msg.textContent : "", canvas: !!canvas, w: canvas ? canvas.width : 0 };
  }, T);
  ok(`${type} renders (${ds})`, !state.msg && state.canvas && state.w > 100, state.msg);
  await page.locator("#mount").screenshot({ path: path.join(OUT, `${String(CASES.findIndex((c) => c[0] === type)).padStart(2, "0")}-${type}.png`) });
}

// linked analysis on a column click
await page.goto(`${BASE}?widget=universal-chart&dataset=variance_region&w=700&h=380&props=${encodeURIComponent(JSON.stringify({ chartType: "bar", animation: false }))}`);
await page.waitForFunction(() => window.__harnessReady === true);
await page.waitForTimeout(600);
const pt = await page.evaluate((t) => {
  const el = document.querySelector(t);
  const lay = el._chart.getModel().getSeriesByIndex(1).getData().getItemLayout(2); // Actual, 3rd region
  const r = el.shadowRoot.querySelector(".chart").getBoundingClientRect();
  return { x: r.left + lay.x + lay.width / 2, y: r.top + lay.y + lay.height / 2 };
}, T);
await page.mouse.click(pt.x, pt.y);
await page.waitForTimeout(250);
const la = await page.evaluate(() => window.host.laCalls.slice(-1)[0]);
ok("Column click → setFilters(Region member)", la && la.op === "setFilters" && la.sel.Region_3kd02ma === "SA_E", JSON.stringify(la));
ok("onSelect fired", (await page.evaluate(() => window.host.events.slice(-1)[0])) === "onSelect");
// option override + script methods
await page.evaluate(() => window.host.callMethod("setChartType", ["donut"]));
await page.evaluate(() => window.host.callMethod("setOptionOverride", ['{"series":[{"radius":["30%","60%"]}]}']));
await page.waitForTimeout(400);
const radius = await page.evaluate((t) => document.querySelector(t)._chart.getOption().series[0].radius, T);
ok("setChartType('donut') + setOptionOverride deep-merges into series[0]", JSON.stringify(radius) === '["30%","60%"]', JSON.stringify(radius));
const [dl] = await Promise.all([page.waitForEvent("download"), page.evaluate(() => window.host.callMethod("exportChart", ["png", "UC"]))]);
await dl.saveAs(path.join(OUT, "export.png"));
ok("exportChart('png') → PNG", fs.readFileSync(path.join(OUT, "export.png")).subarray(1, 4).toString() === "PNG");
const [dl2] = await Promise.all([page.waitForEvent("download"), page.evaluate(() => window.host.callMethod("exportChart", ["xlsx", "UC"]))]);
await dl2.saveAs(path.join(OUT, "export.xlsx"));
ok("exportChart('xlsx') → data workbook", fs.statSync(path.join(OUT, "export.xlsx")).size > 1000);
ok("No window.echarts global leaked", (await page.evaluate(() => typeof window.echarts)) === "undefined");
{
  const img = await page.evaluate(() => document.querySelector("sackit-universal-chart").serializeCustomWidgetToImage());
  ok("serializeCustomWidgetToImage() → PNG data URL for story export", typeof img === "string" && img.startsWith("data:image/png;base64,") && img.length > 5000, String(img).slice(0, 40));
}
ok("No page errors", errors.length === 0, errors.slice(0, 3).join(" | "));
fs.writeFileSync(path.join(OUT, "results.json"), JSON.stringify(results, null, 2));
await browser.close();
const failed = results.filter((r) => !r.pass).length;
console.log(`\n${results.length - failed}/${results.length} checks passed`);
process.exit(failed ? 1 : 0);
