// Headless test for the Waterfall / Bridge widget (run: node tools/test/test-waterfall.mjs)
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const { chromium } = require("playwright");
import fs from "node:fs";
import path from "node:path";

const BASE = process.env.HARNESS || "http://127.0.0.1:8765/tools/harness/index.html";
const OUT = process.env.OUT || "/tmp/sac-tests";
fs.mkdirSync(OUT, { recursive: true });
const results = [];
const ok = (name, cond, info = "") => {
  results.push({ name, pass: !!cond, info });
  console.log(`${cond ? "PASS" : "FAIL"}  ${name}${info ? "  — " + info : ""}`);
};

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1320, height: 900 }, acceptDownloads: true });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });

async function open(dataset, props, w = 900, h = 460) {
  const u = `${BASE}?widget=waterfall-bridge&dataset=${dataset}&w=${w}&h=${h}` + (props ? `&props=${encodeURIComponent(JSON.stringify(props))}` : "");
  await page.goto(u);
  await page.waitForFunction(() => window.__harnessReady === true);
  await page.waitForFunction(() => {
    const el = document.querySelector("sackit-waterfall-bridge");
    return el && el.shadowRoot && el.shadowRoot.querySelectorAll("g.bar").length > 0;
  }, null, { timeout: 8000 });
  await page.waitForTimeout(150);
}
const steps = () => page.evaluate(() => {
  const el = document.querySelector("sackit-waterfall-bridge");
  return el._model.steps.map((s) => ({ label: s.label, kind: s.kind, value: Math.round(s.value / 1e4) / 100, cum: Math.round(s.cumulative / 1e4) / 100, fav: s.favorable }));
});
const shot = (name) => page.locator("#mount").screenshot({ path: path.join(OUT, `waterfall-${name}.png`) });

// 1) P&L hierarchy — auto subtotals
await open("pnl_hierarchy", { chartTitle: "Net income bridge FY2026", chartSubtitle: "Amount, SAR", showTitle: true });
let s = await steps();
console.log(s.map((x) => `${x.kind}:${x.label}=${x.value}`).join(" | "));
ok("P&L: Gross Profit auto-subtotal", s.some((x) => x.label === "Gross Profit" && x.kind === "subtotal" && x.value === 400));
ok("P&L: EBIT auto-subtotal", s.some((x) => x.label === "EBIT" && x.kind === "subtotal" && x.value === 230));
ok("P&L: OPEX group node skipped", !s.some((x) => x.label === "Operating Expenses"));
ok("P&L: Net Income is the end bar", s[s.length - 1].label === "Net Income" && s[s.length - 1].kind === "end" && s[s.length - 1].value === 180);
ok("P&L: COGS unfavourable", s.find((x) => x.label === "Cost of Goods Sold").fav === false);
await shot("1-pnl-hierarchy");

// 2) linked analysis on click
await page.locator("sackit-waterfall-bridge g.bar").nth(0).click();
await page.waitForTimeout(150);
let la = await page.evaluate(() => window.host.laCalls.slice(-1)[0]);
ok("Click → setFilters with hierarchy unique name", la && la.op === "setFilters" && la.sel.Account_7h2kq01 === "[Account_7h2kq01].[parentId].&[REV]", JSON.stringify(la));
let props = await page.evaluate(() => ({ id: window.host.props.selectedMemberId, label: window.host.props.selectedMemberLabel, ev: window.host.events.slice(-1)[0] }));
ok("Selection published to properties + onSelect fired", props.label === "Revenue" && props.ev === "onSelect", JSON.stringify(props));
await page.locator("sackit-waterfall-bridge g.bar").nth(2).click({ modifiers: ["Control"] });
await page.waitForTimeout(150);
la = await page.evaluate(() => window.host.laCalls.slice(-1)[0]);
ok("Ctrl+click → multi selection array", la && Array.isArray(la.sel) && la.sel.length === 2, JSON.stringify(la && la.sel));
await shot("2-pnl-selection");
await page.locator("sackit-waterfall-bridge .chart").click({ position: { x: 5, y: 5 } });
await page.waitForTimeout(150);
la = await page.evaluate(() => window.host.laCalls.slice(-1)[0]);
ok("Background click → removeFilters + onClear", la && la.op === "removeFilters" && (await page.evaluate(() => window.host.events.slice(-1)[0])) === "onClear");
// LA disabled in story → no setFilters
await page.evaluate(() => (window.host.laEnabled = false));
const before = await page.evaluate(() => window.host.laCalls.length);
await page.locator("sackit-waterfall-bridge g.bar").nth(1).click();
await page.waitForTimeout(150);
const after = await page.evaluate(() => window.host.laCalls.filter((c) => c.op === "setFilters").length);
ok("isDataPointSelectionEnabled()=false → no setFilters", (await page.evaluate(() => window.host.laCalls.slice(-1)[0].op)) !== "setFilters" || after === 0, `calls ${before}`);

// 3) variance bridge with Top N + Others
await open("variance_region", { bridgeMode: "variance", topN: 6, chartTitle: "Budget → Actual by region", showTitle: true, labelContent: "valueAndPercent" }, 1000, 480);
s = await steps();
console.log(s.map((x) => `${x.kind}:${x.label}=${x.value}`).join(" | "));
const others = s.find((x) => x.label.startsWith("Others"));
ok("Variance: start = Σ budget", s[0].kind === "start" && Math.abs(s[0].value - 1928) < 0.01, String(s[0].value));
ok("Variance: end = Σ actual", s[s.length - 1].kind === "end" && Math.abs(s[s.length - 1].value - 1983.5) < 0.01, String(s[s.length - 1].value));
ok("Variance: Top 6 + Others", others && s.filter((x) => x.kind === "delta").length === 7, others && others.label);
ok("Variance: sorted by absolute impact", Math.abs(s[1].value) >= Math.abs(s[2].value));
await page.locator("sackit-waterfall-bridge g.bar").nth(s.indexOf(others)).click();
await page.waitForTimeout(150);
la = await page.evaluate(() => window.host.laCalls.slice(-1)[0]);
ok("Click on Others → setFilters with Selection[] of grouped members", la && Array.isArray(la.sel) && la.sel.length >= 3, JSON.stringify(la && la.sel));
await page.locator("sackit-waterfall-bridge .chart").click({ position: { x: 5, y: 5 } });
await shot("3-variance-topn");

ok("Variance: auto axis zooms when totals dwarf steps", await page.evaluate(() => { const el = document.querySelector("sackit-waterfall-bridge"); return el._domain(el._model).zoom === true; }));
ok("Variance: auto scale picks millions", await page.evaluate(() => { const el = document.querySelector("sackit-waterfall-bridge"); return el._fmt(el._model).value.scale === "M"; }));
// 4) PVM measures bridge with residual
await open("pvm_measures", { bridgeMode: "measures", invertedMembers: "", chartTitle: "Revenue bridge PY → CY (PVM)", showTitle: true });
s = await steps();
console.log(s.map((x) => `${x.kind}:${x.label}=${x.value}`).join(" | "));
const res = s.find((x) => x.label === "Other / Residual");
ok("PVM: residual reconciles start + effects to end", res && Math.abs(res.value - 3.5) < 0.01, res && String(res.value));
ok("PVM: first & last measure are totals", s[0].kind === "start" && s[s.length - 1].kind === "end");
await shot("4-pvm-measures");

// 5) cash bridge, first member = opening, horizontal
await open("cash_bridge", { firstIsTotal: true, endLabel: "Closing cash", orientation: "horizontal", chartTitle: "Cash bridge", showTitle: true, labelPosition: "inside" }, 900, 420);
s = await steps();
ok("Cash: opening is start, closing computed", s[0].kind === "start" && s[0].value === 520 && s[s.length - 1].label === "Closing cash" && s[s.length - 1].value === 601, `${s[s.length - 1].value}`);
await shot("5-cash-horizontal");

// 6) zoomed axis (no zero) + parentheses + rotate labels
await open("pnl_hierarchy", { axisScaling: "zoom", negativeStyle: "parentheses", categoryLabelMode: "rotate", hierarchyMode: "leaves", showEndTotal: true, endLabel: "Net income" });
s = await steps();
ok("Leaves-only hierarchy: no subtotals", !s.some((x) => x.kind === "subtotal") && s.length === 7, String(s.length));
await shot("6-zoomed-rotated");

// 7) styling panel round trip → orientation
await open("pnl_hierarchy");
await page.locator("sackit-waterfall-bridge-styling summary", { hasText: "Layout" }).click();
await page.locator("sackit-waterfall-bridge-styling select").filter({ has: page.locator('option[value="horizontal"]') }).selectOption("horizontal");
await page.waitForTimeout(200);
const orient = await page.evaluate(() => window.host.props.orientation);
ok("Styling panel → propertiesChanged → widget re-render", orient === "horizontal");
await shot("7-panel-horizontal");

// 8) exports: toolbar XLSX and script method PNG
await page.locator("#mount").hover();
const [dl1] = await Promise.all([page.waitForEvent("download"), page.locator('sackit-waterfall-bridge button[data-export="xlsx"]').click()]);
const xlsxPath = path.join(OUT, "waterfall-export.xlsx");
await dl1.saveAs(xlsxPath);
ok("Toolbar XLSX download", fs.statSync(xlsxPath).size > 1500, `${fs.statSync(xlsxPath).size} bytes, ${dl1.suggestedFilename()}`);
const [dl2] = await Promise.all([page.waitForEvent("download"), page.evaluate(() => window.host.callMethod("exportChart", ["png", "ScriptExport"]))]);
const pngPath = path.join(OUT, "waterfall-export.png");
await dl2.saveAs(pngPath);
const sig = fs.readFileSync(pngPath).subarray(0, 8).toString("hex");
ok("exportChart('png') via script method → PNG", sig === "89504e470d0a1a0a" && dl2.suggestedFilename().startsWith("ScriptExport"), dl2.suggestedFilename());
const [dl3] = await Promise.all([page.waitForEvent("download"), page.evaluate(() => window.host.callMethod("exportChart", ["csv", ""]))]);
const csvPath = path.join(OUT, "waterfall-export.csv");
await dl3.saveAs(csvPath);
ok("exportChart('csv') → CSV with BOM", fs.readFileSync(csvPath).subarray(0, 3).toString("hex") === "efbbbf");
const [dl4] = await Promise.all([page.waitForEvent("download"), page.evaluate(() => window.host.callMethod("exportChart", ["svg", "Vector"]))]);
await dl4.saveAs(path.join(OUT, "waterfall-export.svg"));
ok("exportChart('svg') → SVG", fs.readFileSync(path.join(OUT, "waterfall-export.svg"), "utf8").startsWith("<svg"));

// 9) clearSelection script method, getters
await page.locator("sackit-waterfall-bridge g.bar").nth(0).click();
await page.waitForTimeout(100);
const got = await page.evaluate(() => [window.host.callMethod("getSelectedMemberLabel", []), window.host.callMethod("getSelectedDimensionId", [])]);
ok("getSelectedMemberLabel() / getSelectedDimensionId()", got[0] === "Revenue" && got[1] === "Account_7h2kq01", JSON.stringify(got));
await page.evaluate(() => window.host.callMethod("clearSelection", []));
await page.waitForTimeout(150);
la = await page.evaluate(() => window.host.laCalls.slice(-1)[0]);
ok("clearSelection() → removeFilters", la && la.op === "removeFilters");
const ds = await page.evaluate(() => typeof window.host.callMethod("getDataSource", []).setDimensionFilter);
ok("getDataSource() returns the binding's DataSource", ds === "function");

// 10) states
await page.goto(`${BASE}?widget=waterfall-bridge&dataset=empty`);
await page.waitForFunction(() => window.__harnessReady === true);
await page.waitForTimeout(300);
const msg = await page.evaluate(() => document.querySelector("sackit-waterfall-bridge").shadowRoot.querySelector(".msg").textContent);
ok("No binding → helpful message", /Bind data/.test(msg), msg);
ok("Render-complete event fired", (await page.evaluate(() => window.host.renderCount || 0)) > 0);

// Story export (Developer Guide ch. 9) and bookmarks (ch. 13)
{
  const img = await page.evaluate(() => document.querySelector("sackit-waterfall-bridge").serializeCustomWidgetToImage());
  ok("serializeCustomWidgetToImage() → PNG data URL for story export", typeof img === "string" && img.startsWith("data:image/png;base64,") && img.length > 5000, String(img).slice(0, 40));
  const json = JSON.parse(fs.readFileSync(new URL("../../dist/waterfall-bridge/waterfall-bridge.prod.json", import.meta.url)));
  ok("Command properties excluded from bookmarks", json.properties.exportToken.includeInBookmarks === false && json.properties.clearSelectionToken.includeInBookmarks === false && !("includeInBookmarks" in json.properties.selectedMemberId));
}
ok("No page errors", errors.length === 0, errors.join(" | "));
fs.writeFileSync(path.join(OUT, "waterfall-results.json"), JSON.stringify(results, null, 2));
await browser.close();
const failed = results.filter((r) => !r.pass).length;
console.log(`\n${results.length - failed}/${results.length} checks passed`);
process.exit(failed ? 1 : 0);
