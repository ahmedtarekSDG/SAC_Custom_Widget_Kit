// Headless test for the Export Table widget (run: node tools/test/test-table.mjs)
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const { chromium } = require("playwright");
import fs from "node:fs";
import path from "node:path";

const BASE = process.env.HARNESS || "http://127.0.0.1:8765/tools/harness/index.html";
const OUT = process.env.OUT || "/tmp/sac-tests";
fs.mkdirSync(OUT, { recursive: true });
const results = [];
const ok = (name, cond, info = "") => {
  results.push({ name, pass: !!cond, info });
  console.log(`${cond ? "PASS" : "FAIL"}  ${name}${info ? "  — " + info : ""}`);
};
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1320, height: 900 }, acceptDownloads: true });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
const T = "sackit-export-table";

async function open(dataset, props, w = 960, h = 460) {
  await page.goto(`${BASE}?widget=export-table&dataset=${dataset}&w=${w}&h=${h}` + (props ? `&props=${encodeURIComponent(JSON.stringify(props))}` : ""));
  await page.waitForFunction(() => window.__harnessReady === true);
  await page.waitForFunction((t) => { const el = document.querySelector(t); return el && el.shadowRoot.querySelectorAll("tbody tr").length > 0; }, T, { timeout: 8000 });
  await page.waitForTimeout(120);
}
const shot = (n) => page.locator("#mount").screenshot({ path: path.join(OUT, `table-${n}.png`) });
const bodyRows = () => page.evaluate((t) => [...document.querySelector(t).shadowRoot.querySelectorAll("tbody tr")].map((tr) => [...tr.children].map((td) => td.textContent.trim())), T);

// 1) flat two dimensions + variance + data bars
await open("product_region", { showVariance: true, varianceActualIndex: 0, varianceBaseIndex: 1, showDataBars: true, tableTitle: "Sales by product and region", showTitle: true });
let rows = await bodyRows();
ok("Flat: 15 rows rendered", rows.length === 15, String(rows.length));
ok("Flat: repeated outer member names blanked", rows[1][0] === "" && rows[0][0] === "Coffee 250g", JSON.stringify(rows.slice(0, 2)));
const head = await page.evaluate((t) => [...document.querySelector(t).shadowRoot.querySelectorAll("thead th")].map((th) => th.textContent), T);
ok("Header shows scale + variance columns", head.includes("Actual (M)") && head.includes("Δ (M)") && head.includes("Δ %"), JSON.stringify(head));
const totals = await page.evaluate((t) => [...document.querySelector(t).shadowRoot.querySelectorAll("tfoot td")].map((td) => td.textContent), T);
ok("Totals row present", totals[0] === "Total" && totals.length === head.length, JSON.stringify(totals));
await shot("1-flat-variance");

// 2) linked analysis: row tuple selection
await page.locator(`${T} tbody tr`).nth(4).click();
await page.waitForTimeout(120);
let la = await page.evaluate(() => window.host.laCalls.slice(-1)[0]);
ok("Row click → setFilters with full tuple", la && la.op === "setFilters" && la.sel.Product_9as8d === "P110" && la.sel.Region_3kd02ma === "AE_DXB", JSON.stringify(la && la.sel));
ok("onSelect + selectedRowJson", (await page.evaluate(() => window.host.events.slice(-1)[0])) === "onSelect" && (await page.evaluate(() => JSON.parse(window.host.props.selectedRowJson).length)) === 1);
await page.locator(`${T} tbody tr`).nth(7).click({ modifiers: ["Control"] });
await page.waitForTimeout(120);
la = await page.evaluate(() => window.host.laCalls.slice(-1)[0]);
ok("Ctrl+click → Selection[]", la && Array.isArray(la.sel) && la.sel.length === 2);
await shot("2-selection");
await page.evaluate(() => window.host.callMethod("clearSelection", []));
await page.waitForTimeout(120);
ok("clearSelection() → removeFilters", (await page.evaluate(() => window.host.laCalls.slice(-1)[0].op)) === "removeFilters");

// 3) sorting by header + persisted sort props
await page.locator(`${T} thead th`).nth(2).click();
await page.locator(`${T} thead th`).nth(2).click();
await page.waitForTimeout(100);
const sortProps = await page.evaluate(() => [window.host.props.sortKey, window.host.props.sortDir]);
rows = await bodyRows();
const vals = rows.map((r) => parseFloat(r[2].replace(/[^0-9.\-−]/g, "").replace("−", "-")));
ok("Header click sorts desc and persists sortKey/sortDir", sortProps[0] === "ACTUAL" && sortProps[1] === "desc" && vals.every((v, i) => i === 0 || v <= vals[i - 1]), JSON.stringify(sortProps));
// search
await page.evaluate(() => window.host.callMethod("setSearchText", ["0g"]));
await page.waitForTimeout(150);
rows = await bodyRows();
ok("setSearchText('0g') filters rows", rows.length === 6, String(rows.length));

// 4) hierarchy tree
await open("costcenter_hierarchy", { showVariance: true, varianceActualIndex: 0, varianceBaseIndex: 1, invertedMembers: "", increaseIsGood: false, tableTitle: "Cost centre spend vs budget", showTitle: true });
rows = await bodyRows();
ok("Tree: all 11 nodes expanded", rows.length === 11, String(rows.length));
ok("Tree: total = root value (no double counting)", (await page.evaluate((t) => document.querySelector(t).shadowRoot.querySelector("tfoot td:nth-child(2)").textContent, T)) === "26.6M");
await shot("3-tree");
await page.evaluate(() => window.host.callMethod("collapseAll", []));
await page.waitForTimeout(120);
rows = await bodyRows();
ok("collapseAll() → roots only", rows.length === 1, String(rows.length));
await page.locator(`${T} tbody tr .tog`).first().click();
await page.waitForTimeout(100);
ok("Toggle expands one level", (await bodyRows()).length === 4);
await page.evaluate(() => window.host.callMethod("expandAll", []));
await page.waitForTimeout(100);
await page.locator(`${T} tbody tr`).nth(2).click();
await page.waitForTimeout(120);
la = await page.evaluate(() => window.host.laCalls.slice(-1)[0]);
ok("Tree row → setFilters with hierarchy unique name", la && la.sel.CostCenter_77x === "[CostCenter_77x].[H1].&[FIN_ACC]", JSON.stringify(la && la.sel));

// 5) exports
await page.evaluate(() => { window.host.update({ exportAddinSheet: true, addinFixedFilters: "Version=public.Actual; Date=202612" }, "script"); });
const [d1] = await Promise.all([page.waitForEvent("download"), page.locator(`${T} button[data-export="xlsx"]`).click()]);
const x1 = path.join(OUT, "table-tree.xlsx");
await d1.saveAs(x1);
ok("Tree XLSX export", fs.statSync(x1).size > 2000, `${fs.statSync(x1).size} bytes`);
ok("onExported event", (await page.evaluate(() => window.host.events.slice(-1)[0])) === "onExported");
await open("product_region", { showVariance: true, tableTitle: "Sales by product and region" });
const [d2] = await Promise.all([page.waitForEvent("download"), page.evaluate(() => window.host.callMethod("exportTable", ["xlsx", "FlatExport"]))]);
const x2 = path.join(OUT, "table-flat.xlsx");
await d2.saveAs(x2);
ok("exportTable('xlsx','FlatExport') via script", d2.suggestedFilename().startsWith("FlatExport_"), d2.suggestedFilename());
const [d3] = await Promise.all([page.waitForEvent("download"), page.evaluate(() => window.host.callMethod("exportTable", ["csv", ""]))]);
const c3 = path.join(OUT, "table.csv");
await d3.saveAs(c3);
const csv = fs.readFileSync(c3, "utf8");
ok("CSV with BOM, IDs and raw numbers", csv.charCodeAt(0) === 0xfeff && csv.includes("Product ID") && /\d{6,}/.test(csv));
await ctx.grantPermissions(["clipboard-read", "clipboard-write"]);
await page.locator(`${T} button[data-export="copy"]`).click();
await page.waitForTimeout(200);
const clip = await page.evaluate(() => navigator.clipboard.readText());
ok("Copy → TSV on clipboard", clip.split("\n").length === 16 && clip.includes("\t"), `${clip.split("\n").length} lines`);

// 6) states & errors
await page.goto(`${BASE}?widget=export-table&dataset=loading`);
await page.waitForFunction(() => window.__harnessReady === true);
await page.waitForTimeout(250);
ok("Loading state message", (await page.evaluate((t) => document.querySelector(t).shadowRoot.querySelector(".msg").textContent, T)) === "Loading…");
ok("No page errors", errors.length === 0, errors.join(" | "));
fs.writeFileSync(path.join(OUT, "table-results.json"), JSON.stringify(results, null, 2));
await browser.close();
const failed = results.filter((r) => !r.pass).length;
console.log(`\n${results.length - failed}/${results.length} checks passed`);
process.exit(failed ? 1 : 0);
