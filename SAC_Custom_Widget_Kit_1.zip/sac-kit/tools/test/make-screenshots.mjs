// Regenerates the images in docs/img from the local harness.
// Run (harness served on 127.0.0.1:8765):  node tools/test/make-screenshots.mjs
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const { chromium } = require("playwright");
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const BASE = process.env.HARNESS || "http://127.0.0.1:8765/tools/harness/index.html";
const IMG = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../docs/img");
fs.mkdirSync(IMG, { recursive: true });

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 2 });

async function shot(widget, dataset, props, w, h, readySelector) {
  const u = `${BASE}?widget=${widget}&dataset=${dataset}&w=${w}&h=${h}` + (props ? `&props=${encodeURIComponent(JSON.stringify(props))}` : "");
  await page.goto(u);
  await page.waitForFunction(() => window.__harnessReady === true);
  await page.waitForFunction(
    ([w, sel]) => {
      const el = document.querySelector(`sackit-${w}`);
      return el && el.shadowRoot && el.shadowRoot.querySelector(sel);
    },
    [widget, readySelector]
  );
  await page.addStyleTag({ content: "#mount{border:none !important;resize:none !important}" }); // hide harness chrome
  await page.waitForTimeout(widget === "universal-chart" ? 900 : 300);
  return page.locator("#mount").screenshot();
}

const save = (name, buf) => {
  fs.writeFileSync(path.join(IMG, name), buf);
  console.log("wrote", path.join("docs/img", name));
};

// --- Waterfall / Bridge
save("waterfall-pnl.png", await shot("waterfall-bridge", "pnl_hierarchy", { showTitle: true, chartTitle: "P&L walk", chartSubtitle: "Automatic subtotals from the account hierarchy" }, 900, 440, "g.bar"));
save("waterfall-variance.png", await shot("waterfall-bridge", "variance_region", { bridgeMode: "variance", sortSteps: "absDesc", topN: 6, showTitle: true, chartTitle: "Budget → Actual by region", chartSubtitle: "Top 6 drivers + Others, auto axis zoom" }, 900, 440, "g.bar"));
save("waterfall-pvm.png", await shot("waterfall-bridge", "pvm_measures", { bridgeMode: "measures", orientation: "horizontal", showTitle: true, chartTitle: "Price-volume-mix", chartSubtitle: "Measures as steps, residual reconciles" }, 900, 440, "g.bar"));

// --- Export Table
save("export-table-tree.png", await shot("export-table", "pnl_hierarchy", { showTitle: true, tableTitle: "P&L", tableSubtitle: "Hierarchy, totals, data bars", showDataBars: true }, 900, 420, "table"));
save("export-table-variance.png", await shot("export-table", "variance_region", { showTitle: true, tableTitle: "Budget vs Actual", tableSubtitle: "Δ and Δ% with favourability and variance bars", showVariance: true, varianceActualIndex: 1, varianceBaseIndex: 0 }, 900, 420, "table"));

// --- Small widgets gallery (KPI cards + member selector)
const kpi1 = await shot("kpi-card", "monthly_series", { kpiTitle: "Revenue YTD", compareLabel: "vs Budget" }, 340, 220, ".card");
const kpi2 = await shot("kpi-card", "monthly_series", { kpiTitle: "Revenue (latest month)", valueMode: "last", sparkType: "bar", thresholds: "103,107", compareLabel: "vs Budget" }, 340, 220, ".card");
const chips = await shot("member-selector", "variance_region", { displayMode: "chips" }, 700, 150, "button");
const list = await shot("member-selector", "variance_region", { displayMode: "list", sortBy: "valueDesc", selectedMembers: "SA_C" }, 340, 330, ".item");
const b64 = (b) => `data:image/png;base64,${b.toString("base64")}`;
await page.setContent(`<html><body style="margin:0;padding:16px;background:#F5F6F7;font:13px Arial">
  <div style="display:flex;gap:16px;align-items:flex-start">
    <div style="display:flex;flex-direction:column;gap:16px">
      <img src="${b64(kpi1)}" style="width:340px;background:#fff;border:1px solid #E3E6EA">
      <img src="${b64(kpi2)}" style="width:340px;background:#fff;border:1px solid #E3E6EA">
    </div>
    <div style="display:flex;flex-direction:column;gap:16px">
      <img src="${b64(chips)}" style="width:700px;background:#fff;border:1px solid #E3E6EA">
      <img src="${b64(list)}" style="width:340px;background:#fff;border:1px solid #E3E6EA">
    </div>
  </div></body></html>`);
await page.waitForTimeout(200);
save("small-widgets.png", await page.locator("body > div").screenshot());

await browser.close();
