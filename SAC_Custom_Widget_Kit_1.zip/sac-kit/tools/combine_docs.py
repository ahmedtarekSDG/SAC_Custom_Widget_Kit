#!/usr/bin/env python3
"""
Combines docs/01..09 into one Markdown file: docs/SAC_Custom_Widgets_Complete_Guide.md
(links between chapters are rewritten to in-document anchors). Re-run after editing a chapter.

Usage:  python3 tools/combine_docs.py
"""
import re
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DOCS = ROOT / "docs"
OUT = DOCS / "SAC_Custom_Widgets_Complete_Guide.md"


def slug(heading: str) -> str:
    """GitHub-style heading anchor."""
    h = heading.strip().lower()
    h = re.sub(r"[^\w\- ]", "", h)
    return h.replace(" ", "-")


def main() -> None:
    chapters = sorted(p for p in DOCS.glob("0[1-9]_*.md"))
    titles = {}
    for p in chapters:
        first = next(line for line in p.read_text(encoding="utf-8").splitlines() if line.startswith("# "))
        titles[p.name] = first[2:].strip()

    def rewrite(text: str) -> str:
        def repl(m):
            label, target = m.group(1), m.group(2)
            file, _, anchor = target.partition("#")
            if file in titles:
                return f"[{label}](#{anchor or slug(titles[file])})"
            return m.group(0)

        text = re.sub(r"\[([^\]]+)\]\((0[1-9]_[^)#\s]+\.md(?:#[^)\s]+)?)\)", repl, text)
        text = re.sub(r"^Next: \[.*$", "", text, flags=re.M)  # chapter footers
        return text.rstrip() + "\n"

    parts = [
        "# SAP Analytics Cloud Custom Widgets: Complete Guide",
        "",
        f"All chapters of the SAC Custom Widget Kit documentation in one file (generated {date.today():%d %b %Y}). "
        "The kit itself (widgets, build, harness, tests) is described in the README of the kit folder; the "
        "per-widget property/method/event tables are in `docs/reference/`.",
        "",
        "## Chapters",
        "",
    ]
    parts += [f"- [{titles[p.name]}](#{slug(titles[p.name])})" for p in chapters]
    parts.append("")
    for p in chapters:
        parts += ["---", "", rewrite(p.read_text(encoding="utf-8"))]
    OUT.write_text("\n".join(parts), encoding="utf-8")
    print("wrote", OUT.relative_to(ROOT), f"({OUT.stat().st_size / 1024:.0f} KB, {len(chapters)} chapters)")


if __name__ == "__main__":
    main()
