# SAC Custom Widget Kit

Six ready-to-upload **SAP Analytics Cloud custom widgets**, a build/test toolchain and a full documentation set on
custom widgets, linked analysis, Excel export and the Excel add-in. Built for **Optimized Story Experience** stories
on **SAP Datasphere analytic models** (live), and works on SAC models too.

Every widget is data-bound through the Builder panel, acts as a linked-analysis **source and target**, has a
Styling panel, script methods and events, and supports bookmarks, viewport loading and mobile (all except the
selector are also flagged for story PDF/PowerPoint export). The bridge, the table and the chart export their own data
(XLSX/CSV, plus PNG/SVG for the charts).

![Budget to Actual bridge](docs/img/waterfall-variance.png)

---

## The widgets

| Widget | What it does | Highlights |
|---|---|---|
| **Waterfall / Bridge** (`waterfall-bridge`) | P&L walks, Budget→Actual and PY→CY variance bridges, price-volume-mix, cash and opening→closing bridges | Three modes (dimension, variance between two measures, measures as steps); automatic subtotals from a hierarchy; Top N + "Others" that still filters; favourable/unfavourable with inverted cost lines; axis zoom with break marks; residual step; vertical/horizontal; PNG/SVG/XLSX/CSV |
| **Export Table** (`export-table`) | Financial reporting table that exports exactly as shown | Hierarchy tree or flat; Δ/Δ% with favourability and variance bars; totals; data bars; sort, search; XLSX with real numbers + scaled formats, Excel grouping, *Info* sheet (IDs, filters) and an *AddIn_Grid* sheet with `SAP.GETDATA` templates; CSV; copy |
| **Universal Chart** (`universal-chart`) | 20 chart types on Apache ECharts | Bar, stacked, 100 %, line, area, combo, pareto, pie, donut, rose, funnel, gauge with target, radar, heatmap, scatter/bubble, treemap, sunburst, tree, sankey; Top N; palette; `optionOverride` for any ECharts option |
| **KPI Card** (`kpi-card`) | Value, Δ vs comparison, status, progress, sparkline | Thresholds → good/warning/bad, `onStatusChange`; sparkline points filter other widgets |
| **Member Selector** (`member-selector`) | Chips, segmented buttons or a searchable list | Single/multi, "All", values and bars, selection kept in bookmarks, drives linked analysis |
| **Starter Template** (`starter-template`) | The smallest complete data-bound widget, fully commented | Lifecycle, binding, linked analysis, property, method, event and a hand-written styling panel to copy from |

| P&L walk with automatic subtotals | Price-volume-mix (horizontal) |
|---|---|
| ![P&L walk](docs/img/waterfall-pnl.png) | ![PVM](docs/img/waterfall-pvm.png) |

| Export Table: hierarchy | Export Table: Budget vs Actual |
|---|---|
| ![Table tree](docs/img/export-table-tree.png) | ![Table variance](docs/img/export-table-variance.png) |

![KPI cards and member selector](docs/img/small-widgets.png)

![Universal Chart: the 20 chart types](docs/img/universal-chart-gallery.png)

---

## Quick start (no build needed)

`dist/` already contains the built files.

1. In SAC: **Stories → Custom Widgets → + (Create)**, select `dist/<widget>/<widget>.prod.json`, then **Select
   File** → `dist/<widget>/<widget>-resources.zip` → **OK**.
2. In an Optimized Story Experience story: **Insert → Custom Widgets → <widget>**.
3. **Builder panel:** pick the Datasphere analytic model, bind dimensions and measures.
4. **Styling panel:** set the mode, number format, colours, labels.
5. For selections that filter other widgets: **⋯ → Linked Analysis → Settings → Filter on Data Point Selection**
   and choose the targets.
6. Scripting: e.g. `WaterfallBridge_1.exportChart("xlsx", "Bridge")`; every property, method and event is listed in
   [`docs/reference/`](docs/reference/README.md).

Details: [06 — Deployment, testing, troubleshooting](docs/06_Deployment_Testing_Troubleshooting.md).

---

## Documentation

| # | Document | Read it for |
|---|---|---|
| 01 | [Custom Widget Master Guide](docs/01_Custom_Widget_Master_Guide.md) | How custom widgets work end to end: JSON, lifecycle, data binding, script API, panels, bookmarks, viewport loading, export, hosting, integrity, versions, restrictions, add-ons, security, performance, debugging |
| 02 | [Linked Analysis Cookbook](docs/02_Linked_Analysis_Cookbook.md) | Story setup, API, selection formats, per-widget behaviour, script recipes, cross-model, pitfalls |
| 03 | [Tables, Excel Export and the Excel Add-in](docs/03_Tables_Excel_Export_and_Excel_Add-in.md) | Every path to Excel, the ExportExcel API, the kit's XLSX anatomy, AddIn_Grid, `SAP.GETDATA` patterns for CY/PY and YTD |
| 04 | [Waterfall and Bridge Guide](docs/04_Waterfall_and_Bridge_Guide.md) | Native vs add-on vs kit, the three modes, favourability, Top N, axis zoom, recipes per bridge |
| 05 | [Possibilities Catalog](docs/05_Possibilities_Catalog.md) | Everything you can build with custom widgets (and what you can't) |
| 06 | [Deployment, Testing, Troubleshooting](docs/06_Deployment_Testing_Troubleshooting.md) | Build, upload, external hosting, harness, tests, tenant POC checklist, troubleshooting table |
| 07 | [Datasphere Analytic Model Recipes](docs/07_Datasphere_Analytic_Model_Recipes.md) | Measures for Actual/Budget/PY and MTD/QTD/YTD, period-mapping SQL, hierarchies, PVM, IDs, performance, restrictions |
| 08 | [Resource Library](docs/08_Resource_Library.md) | SAP docs, learning, community blogs, GitHub repos, videos, partner content |
| 09 | [Beyond Native: Visuals, Cards and Features](docs/09_Beyond_Native_Visuals_Cards_and_Features.md) | Gap matrix vs native SAC (2026), KPI card types, non-native interactions, comparison guide, playbooks per business area, prioritised build backlog |
| — | [Visual guide (HTML)](docs/SAC_Visual_Guide.html) | Chapter 09 as an interactive page: a worked example of every visual and KPI card type, filters by question, status and business area |
| — | [Complete guide (01–09 in one file)](docs/SAC_Custom_Widgets_Complete_Guide.md) | The same chapters combined, for reading offline or printing |
| — | [Widget reference](docs/reference/README.md) | Generated tables of every property, method and event per widget |
| — | [Third-party notices](THIRD_PARTY_NOTICES.md) | Apache ECharts licence |

---

## Folder layout

```
dist/<widget>/           upload-ready JSON (dev / prod / external), JS, styling JS, resource ZIP
src/<widget>/            widget.spec.json (single source of truth) + main.src.js
src/shared/              sac-kit.js (parsing, formatting, linked analysis), xlsx-lite.js (XLSX writer), panel-kit.js (styling panel)
samples/datasets.js      result sets in SAC's data binding shape for local testing
tools/build.py           spec → dist (validates the JSON, computes SRI hashes, builds flat ZIPs)
tools/gen_reference.py   spec → docs/reference
tools/combine_docs.py    docs/01–09 → one combined guide
tools/harness/           local SAC emulator (properties, binding, linked analysis log, methods, events, styling panel)
tools/test/              Playwright tests + screenshot generator
vendor/echarts/          Apache ECharts 5.6.0 (bundled into the Universal Chart)
docs/                    documentation and images
```

## Develop and test

```bash
python3 tools/build.py                      # build all widgets (python3 tools/build.py --only waterfall-bridge)
python3 tools/gen_reference.py              # regenerate docs/reference after spec changes
python3 tools/combine_docs.py               # regenerate docs/SAC_Custom_Widgets_Complete_Guide.md
python3 -m http.server 8765 --bind 127.0.0.1
#   → http://127.0.0.1:8765/tools/harness/index.html?widget=waterfall-bridge&dataset=variance_region
node tools/test/test-waterfall.mjs          # 34 checks
node tools/test/test-table.mjs              # 22 checks
node tools/test/test-universal.mjs          # 28 checks
node tools/test/test-small-widgets.mjs      # 15 checks
node tools/test/make-screenshots.mjs        # refresh docs/img
```

Tests need Node.js 18+ and Playwright with Chromium.

## Check in your tenant before go-live

The widgets follow the SAP Custom Widget Developer Guide (version 2026.8, read in full) and pass 99 automated checks in a
local SAC emulator, but haven't run in a live tenant yet. Confirm these once (checklist in [06 §7](docs/06_Deployment_Testing_Troubleshooting.md#7-proof-of-concept-in-your-tenant-datasphere-analytic-model)):

- **Data binding on your Datasphere analytic model**: SAP's documentation doesn't call out Datasphere models for
  custom widgets either way. Bind, check the result shape, hierarchy and variables first.
- **Linked analysis** as source and target with your dimensions (IDs and hierarchy unique names).
- **Story PDF/PowerPoint export** (the bridge and the chart hand SAC their own image through
  `serializeCustomWidgetToImage`) and the **mobile app**.
- **Lite Viewer:** the widgets ship with `supportsLWV: false`, so stories that use them open in the full viewer.
  Switch it on per widget after a test (chapter 01 §8.5).
- **Excel add-in IDs**: measure dimension name and member IDs used in the AddIn_Grid template.
- Output properties (selection, sort) written in **edit mode** can mark the story as changed.

## Licence

Kit code: MIT. Apache ECharts: Apache License 2.0 (see [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)).
