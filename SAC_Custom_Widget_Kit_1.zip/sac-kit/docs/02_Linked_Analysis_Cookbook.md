# 02 — Linked Analysis Cookbook

Everything needed to make custom widgets **filter, and be filtered by,** the rest of a story: story settings, the
JavaScript API, selection formats, per-widget behaviour in this kit, script-based alternatives and pitfalls.
Datasphere specifics are at the end and in [07](07_Datasphere_Analytic_Model_Recipes.md).

---

## 1. The three scenarios

Linked analysis for custom widgets is available in the **Optimized Story Experience** (since QRC3 2023). SAP
describes three scenarios:

| # | Scenario | What the designer does | Code needed |
|---|---|---|---|
| A | **Custom widget as target**: a selection in another chart or table filters the custom widget | Configure linked analysis on the *source* widget and include the custom widget (or "all widgets") | None. The widget simply receives a new result set |
| B | **Custom widget as source, widget filters**: filters set on the custom widget in its Builder panel are passed to the linked widgets | Linked Analysis settings on the custom widget, without *Filter on Data Point Selection* | None |
| C | **Custom widget as source, selections**: clicking a bar/row/chip in the custom widget filters other widgets | Linked Analysis settings on the custom widget **with** *Filter on Data Point Selection*, pick targets | JSON flag + `setFilters()` / `removeFilters()` |

Only **data-bound** custom widgets take part in linked analysis (guide ch. 10). In scenario B the story designer can also
add buttons whose scripts set and remove dimension filters. All kit widgets support A, B and C. The starter template sends a single dimension; the others send tuples and
arrays where it makes sense (§5).

---

## 2. Story setup (scenario C)

1. Select the custom widget → **More Actions (⋯) → Linked Analysis → Settings**.
2. Choose the scope: **Only this widget**, **All widgets in the story**, or **Only selected widgets** (pick the
   targets: charts, tables, other custom widgets).
3. Switch on **Filter on Data Point Selection**.
4. Save, switch to view mode, click a data point. Targets on the same model (or on models with **linked
   dimensions**) are filtered; the source widget highlights the selection.

If the targets don't react, check the list in §8 before you debug the code.

---

## 3. The JSON flag and the API

```json
{ "supportsLinkedAnalysisFilterOnSelection": true }
```

```js
const binding = this.dataBindings.getDataBinding("dataBinding");      // binding ID (may be omitted: only one binding is used)
const la = binding.getLinkedAnalysis();

la.isDataPointSelectionEnabled();      // true when the designer switched the option on
la.setFilters(selection);              // Selection or Selection[]
la.removeFilters();                    // clear the filter on the targets
```

The kit wraps this in `SacKit.linkedAnalysis(widget, bindingId, props)`. It resolves the binding from either
`props.dataBindings` or `this.dataBindings`, awaits every call (some releases return promises), skips the call when
the option is off, and never throws:

```js
const la = SacKit.linkedAnalysis(this, "dataBinding", this._props);
if (selections.length) await la.setFilters(selections.length === 1 ? selections[0] : selections);
else await la.removeFilters();
```

---

## 4. Selection formats

A **Selection** maps dimension IDs to member IDs, exactly as they appear in the data binding result
(`metadata.dimensions[...].id` and `data[i].dimensions_N.id`):

```js
// one member of one dimension
{ "Region_3x8": "[Region_3x8].[H1].&[EMEA]" }

// a tuple: one member per dimension (a table row, a heatmap cell, a Sankey link)
{ "Region_3x8": "[Region_3x8].[H1].&[EMEA]", "Product_9k2": "[Product_9k2].[H1].&[P100]" }

// several data points: an array of Selections (multi-select, "Others" groups)
[ { "Region_3x8": "…&[EMEA]" }, { "Region_3x8": "…&[APJ]" } ]
```

Rules:

- **IDs, not descriptions.** Use the IDs from the result set unchanged. With a hierarchy they are unique names
  (`[Dim].[Hierarchy].&[Key]`); don't strip them for linked analysis (the kit only strips them for display and
  Excel).
- **No measures in a selection.** A step that is a *measure* (PVM bridge, measures mode) can't filter other widgets;
  the kit publishes no filter for it but still fires `onSelect`, so a script can react (for example switch a table
  to that measure).
- **Totals and subtotals that aren't members** (start/end bars, "Residual") don't filter either.
- An **"Others"** step filters on all members it contains (a Selection array).

---

## 5. What each kit widget sends

| Widget | Click target | Selection sent | Multi-select | Clear |
|---|---|---|---|---|
| Waterfall / Bridge | A step (dimension or variance mode) | `{dim: member}` of the step's row; "Others" → array of its members | `multiSelect` property or Ctrl/⌘-click | Click empty area or press Esc → `removeFilters()`, `onClear` |
| Export Table | A row | `selectionScope: "row"` → all row dimensions (tuple); `"first"` → first dimension only; tree nodes send their own member | `multiSelect` or Ctrl/⌘/Shift-click | Click the selected row again, press Esc, or `clearSelection()` |
| Universal Chart | Bar, point, slice, cell, node, link | Category member; with a series dimension the tuple; heatmap cell / Sankey link → tuple; "Others" → array | `multiSelect` or Ctrl/⌘-click | Click chart background |
| KPI Card | A sparkline point | `{trendDim: member}` (e.g. a month) | No | Click the point again |
| Member Selector | A chip / segment / list item | `{dim: member}` or an array in multi mode | `selectionMode: "multi"` | "All" chip → `removeFilters()` |

Every widget also publishes output properties (`selectedMemberId`, `selectedMemberLabel`, …) **before** it fires
`onSelect`/`onClear`, so scripts read a consistent state. `enableLinkedAnalysis` (Styling panel, or
`setLinkedAnalysisEnabled(false)` from script) turns the filter calls off while keeping the events, which is useful
when a script should decide what to filter.

---

## 6. Script recipes

### 6.1 Drive widgets that are not on the same model

Linked analysis only reaches widgets on the same model or models with linked dimensions. For anything else, handle
`onSelect`:

```js
// WaterfallBridge_1 – onSelect
var ids = WaterfallBridge_1.getSelectedMemberId();          // "id1,id2" (rows with several dimensions: "a|b")
if (ids === "") { return; }
var first = ids.split(",")[0].split("|")[0];
Chart_Cost.getDataSource().setDimensionFilter("CostCenter", first);
Table_Detail.getDataSource().setDimensionFilter("CostCenter", first);
```

```js
// WaterfallBridge_1 – onClear
Chart_Cost.getDataSource().removeDimensionFilter("CostCenter");
Table_Detail.getDataSource().removeDimensionFilter("CostCenter");
```

When the IDs differ between models (for example a hierarchy unique name in one model and a plain key in the other),
convert in script: `var key = first.substring(first.lastIndexOf("&[") + 2, first.length - 1);`.

### 6.2 Keep an input control in sync with a selection

Linked analysis doesn't move input controls. To show the selection there as well (Optimized Story Experience
input control API; check the method name in the API reference of your release):

```js
// MemberSelector_1 – onSelect
var ids = MemberSelector_1.getSelectedMembers();             // comma separated
var list = ids === "" ? [] : ids.split(",");
InputControl_Region.getInputControlDataSource().setSelectedMembers(list);
```

### 6.3 Read the full selection (all dimensions of the selected rows)

```js
// ExportTable_1 – onSelect
// getSelectedRowJson() returns the selections exactly as sent to linked analysis:
// [{"<dimensionId>":"<memberId>", "<dimensionId2>":"<memberId2>"}, ...]
var sels = JSON.parse(ExportTable_1.getSelectedRowJson());
var label = ExportTable_1.getSelectedMemberLabel();         // "EMEA / Product A, APJ / Product B"
Text_Status.applyText("Selected: " + label + " (" + sels.length.toString() + " rows)");
```

### 6.4 Let the user choose: filter or highlight only

```js
// Switch_Filter – onChange
WaterfallBridge_1.setLinkedAnalysisEnabled(Switch_Filter.isOn());
```

### 6.5 Clear everything from a button

```js
WaterfallBridge_1.clearSelection();
ExportTable_1.clearSelection();
UniversalChart_1.clearSelection();
MemberSelector_1.clearSelection();
```

---

## 7. Cross-model linked analysis

- **Same model:** works out of the box.
- **Different models:** link the dimensions (*Linked Dimensions* in the story) so SAC can map members. For
  **SAP Datasphere live** models, linked dimensions are limited to models from the **same space** (cross-space
  linking is not supported); see SAP Note 2832606 for the current list of Datasphere live restrictions.
- **Different member IDs** (e.g. company code `1000` vs `CC1000`) can't be linked. Map them in the Datasphere view
  layer, or use the script recipe in §6.1 with a mapping table.

---

## 8. Pitfalls and checks

| Symptom | Cause | Fix |
|---|---|---|
| Click highlights but nothing is filtered | *Filter on Data Point Selection* not switched on for the custom widget, or no targets selected | Story → widget → Linked Analysis → Settings |
| Works for charts, not for the custom widget | JSON lacks `supportsLinkedAnalysisFilterOnSelection: true`, or the old JSON is still on the tenant | Re-upload the current JSON (+ ZIP); check the version in *Custom Widgets* |
| Targets are emptied instead of filtered | Selection uses descriptions or stripped keys, not the IDs from the result set | Send IDs unchanged (unique names for hierarchies) |
| Second selection cancels the first | Linked analysis from two different source widgets doesn't accumulate. SAP documents this as intended (KBA 2597724) | Use one source (e.g. a member selector in multi mode) or script filters |
| Targets don't get the source widget's input-control filter | Filters that reach the *source* through an input control are not passed on by linked analysis | Make the input control a page or story filter so every widget gets it, or sync by script (§6.2) |
| Measure step selected → no filter | Measures can't be in a selection | Script on `onSelect` |
| Target on another Datasphere space not filtered | Cross-space linked dimensions unsupported | One space per story's linked models, or script filters with ID mapping |

---

## 9. Datasphere analytic models: what to know

- **Dimension IDs** in selections are the analytic model's dimension technical names as SAC exposes them. Check them
  once in the harness-style debug view (`$0._props.dataBinding.metadata.dimensions`) or in the table export's
  *Info* sheet (it lists every bound dimension and measure ID).
- **Hierarchies** from Datasphere (parent-child or level-based) arrive as unique names; pass them back unchanged.
- **Variables are not filters.** Linked analysis never sets an analytic model variable. If a selection must change a
  variable (e.g. the reporting period), use script: `ds.setVariableValue(...)` on the target data source.
- **Restricted measures combine with filters on the same dimension.** A linked-analysis (or any) filter
  `Version = Budget` empties a measure restricted to `Version = Actual`. Don't offer the dimensions that define your
  measures (version, period offsets) for filtering, or use *constant selection* in the analytic model for measures
  that must ignore such filters.

Next: [03 — Tables, Excel export and the Excel add-in](03_Tables_Excel_Export_and_Excel_Add-in.md)
