# 04 — Waterfall and Bridge Guide

How to build every common bridge in SAC (P&L walk, budget-to-actual, PY-to-CY, price-volume-mix, cash and
opening-to-closing), when the native waterfall is enough, and how to configure the kit's **Waterfall / Bridge**
widget, including the Datasphere measures each bridge needs.

---

## 1. Native waterfall, add-on or custom widget?

| Requirement | Native waterfall chart | Widget add-on on the native chart | Kit Waterfall / Bridge |
|---|---|---|---|
| Steps from a dimension's members, with totals | Yes | — | Yes |
| Variance waterfall between two members | Yes (variance waterfall; it switches off when a page filter changes the compared members, KBA 3063225) | — | Yes, between any two **measures** (variance mode), so filters don't break it |
| Automatic subtotals from a hierarchy (Gross Profit, EBIT, …) | Manual | — | Yes (`hierarchyMode: auto`) |
| Top N + "Others" that still filters | Partly (Top N) | — | Yes; "Others" filters on all its members |
| Cost lines where an increase is unfavourable | Limited | — | Yes (`invertedMembers`, `increaseIsGood`) |
| Readable small variances on large totals (axis break) | No | — | Yes (`axisScaling: zoom`, break marks) |
| PVM with an automatic residual | Manual | — | Yes (`showResidual`) |
| Custom tooltip | — | **Yes (tooltip add-on)** | Built in |
| Extra marks on the plot area | — | **Not supported for the waterfall** (plot-area add-ons don't cover it) | Built in |
| Export of the bridge table to Excel | Via a table | — | XLSX/CSV/PNG/SVG from the widget |
| Theming, comments, translation, scheduling | **Yes** | Yes | No (custom widget restrictions, see [01](01_Custom_Widget_Master_Guide.md#10-restrictions)) |

Rule of thumb: if the native waterfall shows the right steps and the audience doesn't need subtotals, inverted cost
logic or zoom, use it. A richer tooltip on the native chart is a tooltip add-on. Everything else is the kit widget.

---

## 2. Data binding

| Feed | Bind |
|---|---|
| **Category (bridge steps)** | One dimension (with or without hierarchy). Optional; in measures mode it can stay empty |
| **Measures** | One measure (dimension mode), two (variance mode) or several (measures mode) |

Filters, variables and linked analysis apply as for any widget.

---

## 3. The three modes

### 3.1 Dimension mode: members are the steps

Start at zero (or at the first member when `firstIsTotal`), add each member's value, end with a total.

```
bridgeMode        dimension
measureIndex      0              (which bound measure)
hierarchyMode     auto           (hierarchy: parents become subtotals where they add up)
totalMembers      ""             (IDs or descriptions forced to be totals)
showEndTotal      true
```

**P&L walk with a hierarchy.** Bind *FS Item / Account* with the P&L hierarchy, measure `Amount` (signed: revenue
positive, costs negative). In `auto` mode the widget walks the hierarchy in post-order: Revenue, COGS, **Gross
Profit** (subtotal), OPEX lines, **EBIT** (subtotal), Tax, **Net Income** (end). A parent becomes a subtotal when its
value equals the running total (the hierarchy is additive); non-additive parents (ratios, statistical nodes) are
skipped. `leaves` ignores all parents; `all` treats every row as a step.

**Explicit totals.** `totalMembers: "OPENING, CLOSING"`: the running total is reset to these members' values. Use it
for opening/closing balances that come as members of a flow dimension.

### 3.2 Variance mode: from measure A to measure B by member

```
bridgeMode           variance
baseMeasureIndex     0      (A, e.g. Budget or PY)
compareMeasureIndex  1      (B, e.g. Actual or CY)
startLabel / endLabel   "Budget" / "Actual"  (blank = measure names)
```

Start bar = Σ A, one step per member = B − A, end bar = Σ B. Typical uses: **Budget → Actual by region / business
unit / FS item**, **PY → CY by product line**, **Forecast → Actual by cost centre**. Because the comparison is between
two measures, page and story filters on the category dimension don't switch the bridge off.

### 3.3 Measures mode: measures are the steps

```
bridgeMode           measures
firstMeasureIsTotal  true      (first measure = start bar, e.g. PY Revenue)
lastMeasureIsTotal   true      (last measure = end bar, e.g. CY Revenue)
showResidual         true      (adds "Other / Residual" if start + steps ≠ end)
residualLabel        "Other / Residual"
```

Typical use: **price-volume-mix**: `PY Revenue, Price effect, Volume effect, Mix effect, FX effect, CY Revenue`. The
residual step makes rounding or an incomplete decomposition visible instead of hiding it; its tooltip type reads
"Residual". Measures listed in `totalMembers` become subtotals. With a category dimension bound as well, each measure is
summed over its members.

---

## 4. Favourable and unfavourable

Colours follow the **effect on the result**, not the sign alone:

| Setting | Meaning |
|---|---|
| `increaseIsGood: true` | A positive step is favourable (green), a negative one unfavourable (red) |
| `increaseIsGood: false` | The reverse, for a bridge of a cost total |
| `invertedMembers` | Members where an increase is unfavourable even though `increaseIsGood` is true |

Sign conventions matter:

- **Signed P&L** (costs stored negative): a cost increase is already a negative step, so the default colours are
  right. Leave `invertedMembers` empty.
- **Unsigned P&L** (costs stored positive) in a variance bridge: Actual − Budget > 0 on a cost line is an overspend.
  List the cost members (or their parent nodes, by ID or description) in `invertedMembers`.

Totals use `colorTotal`, subtotals `colorSubtotal`, "Others" `colorOthers`.

---

## 5. Steps: sorting, Top N, zeros, residual

| Property | Effect |
|---|---|
| `sortSteps` | `auto` (keep model/hierarchy order), `none`, `absDesc` (largest impact first, the usual choice for variance bridges), `desc`, `asc`. Sorting happens **inside each segment** between (sub)totals, so a P&L keeps its structure |
| `topN`, `othersLabel` | Keep the N largest steps (by absolute value) per segment and group the rest into "Others (k)". Clicking "Others" filters on all its members |
| `hideZeroSteps` | Drop steps whose value is zero (relative tolerance of 10⁻⁹ of the largest value) |
| `excludeMembers` | Members never shown (IDs or descriptions), e.g. technical or unassigned nodes |

---

## 6. Layout, axis and labels

| Property | Options |
|---|---|
| `orientation` | `vertical` (columns) or `horizontal` (bars, better for long names or many steps) |
| `axisScaling` | `auto`: zoom when the steps are small compared with the totals and all totals share one sign; `zero`: always from zero; `zoom`: always truncate. Truncated start/end bars get a **break mark** |
| `showConnectors`, `connectorStyle` | Lines between bar ends: dashed / solid / dotted |
| `labelContent` | `value`, `percent` (of the start bar, or of the first bar when there is no start total), `valueAndPercent`, `none` |
| `labelPosition` | `outside` or `inside` |
| `categoryLabelMode` | `wrap` (up to `maxLabelLines`), `rotate`, `truncate`; `categoryLabelWidth` for horizontal bars |
| Number format | `scale` (auto by the median / none / K / M / B), `scaleSymbols` (e.g. `K,M,B` or `Th,Mn,Bn`), `decimals`, `percentDecimals`, `prefix`, `suffix`, `showPlusSign`, `negativeStyle`, `locale` |
| Title | `showTitle`, `chartTitle`, `chartSubtitle` |
| Colours and font | `color*`, `textColor`, `axisColor`, `gridColor`, `backgroundColor`, `fontFamily`, `fontSize` |

Keyboard: bars are focusable; Enter/Space selects, Esc clears.

---

## 7. Interaction, script and export

- **Linked analysis:** click a step to filter other widgets; Ctrl/⌘-click or `multiSelect` for several. Details and
  selection formats in [02](02_Linked_Analysis_Cookbook.md).
- **Events:** `onSelect`, `onClear`. Getters: `getSelectedMemberId()`, `getSelectedMemberLabel()`,
  `getSelectedValue()`, `getSelectedDimensionId()`.
- **Toolbar** (`showToolbar`): PNG, SVG, XLSX, CSV.

```js
// Dropdown_View – onSelect: switch between three bridges on the same widget
var v = Dropdown_View.getSelectedKey();
if (v === "PNL")  { WaterfallBridge_1.setBridgeMode("dimension"); WaterfallBridge_1.setTopN(0); }
if (v === "VAR")  { WaterfallBridge_1.setBridgeMode("variance");  WaterfallBridge_1.setTopN(8); }
if (v === "PVM")  { WaterfallBridge_1.setBridgeMode("measures");  WaterfallBridge_1.setTopN(0); }
WaterfallBridge_1.setTitle("Revenue bridge", "Budget → Actual, YTD");
WaterfallBridge_1.setScale("M", 1);
WaterfallBridge_1.setInvertedMembers("COGS, OPEX");
WaterfallBridge_1.exportChart("xlsx", "Revenue_Bridge");
```

**Exports**

| Format | Content |
|---|---|
| PNG | The chart at 2× resolution with the background colour |
| SVG | The vector chart (for PowerPoint/Visio editing) |
| XLSX | *Bridge* sheet: Step, Type (Start/Subtotal/End/Favourable/Unfavourable/Others/Residual), Value, Running total, % of start, (variance mode: A and B values), member or measure ID; true numbers with scaled formats; autofilter. *Info* sheet: mode, dimensions and measures with IDs, scale, Top N, total and inverted members |
| CSV | The same table as text |

---

## 8. Recipes with the Datasphere measures they need

Details of the modelling are in [07](07_Datasphere_Analytic_Model_Recipes.md).

| Bridge | Bind | Mode and key settings | Analytic model measures |
|---|---|---|---|
| **P&L walk** (Revenue → Net Income) | FS item hierarchy + `ACT_YTD` | dimension, `hierarchyMode: auto`, `sortSteps: auto` | Signed amount restricted to Actual, YTD by period variable |
| **Budget → Actual by FS item** | FS item (leaf level or a P&L node filter) + `BUD_YTD`, `ACT_YTD` | variance, A=0, B=1, `invertedMembers` if unsigned | Two restricted measures on the version/category dimension |
| **PY → CY by region** | Region + `ACT_YTD_PY`, `ACT_YTD` | variance, `sortSteps: absDesc`, `topN: 8` | Same base measure, restricted by CY and PY period variables |
| **Price-volume-mix** | (nothing) + `REV_PY, PRICE_EFF, VOL_EFF, MIX_EFF, FX_EFF, REV_CY` | measures, first/last are totals, residual on | Effects computed at product (and customer) level, then summed (see 07 §5) |
| **Cash bridge** (opening → closing) | Cash-flow category (sub-item / flow type) + `CASH` | dimension, `totalMembers: "OPENING, CLOSING"` or `firstIsTotal` | Opening balance as a member or as a restricted measure; flows by sub-item |
| **Headcount / FTE bridge** | Movement type (hires, leavers, transfers) + `FTE` | dimension, `firstIsTotal`, `showEndTotal` | Opening FTE as first member or measure |
| **EBITDA by business unit, Budget → Actual, top drivers** | BU + `BUD_EBITDA`, `ACT_EBITDA` | variance, `absDesc`, `topN: 6`, `othersLabel: "Other BUs"` | Restricted measures on an EBITDA node |

---

## 9. Trying the modes locally

The harness ships sample result sets for each mode (`samples/datasets.js`):

```
http://127.0.0.1:8765/tools/harness/index.html?widget=waterfall-bridge&dataset=pnl_hierarchy
…&dataset=variance_region&props={"bridgeMode":"variance","sortSteps":"absDesc"}
…&dataset=pvm_measures&props={"bridgeMode":"measures"}
…&dataset=cash_bridge&props={"totalMembers":"OPEN"}
```

(Start the server from the kit folder with `python3 -m http.server 8765`; see [06](06_Deployment_Testing_Troubleshooting.md).)

Next: [05 — Possibilities Catalog](05_Possibilities_Catalog.md)
