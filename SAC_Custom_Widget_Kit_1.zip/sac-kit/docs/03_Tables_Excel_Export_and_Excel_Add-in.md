# 03 — Tables, Excel Export and the Excel Add-in

Every way to get SAC data into Excel, when to use which, and how the kit's **Export Table** widget produces
workbooks that finance users can work with: real numbers, scaled formats, hierarchy grouping, a metadata sheet and
an ID grid ready for the SAP Analytics Cloud add-in for Microsoft Excel.

---

## 1. Which path for which need

| Need | Best path | Formatting | Live? | Notes |
|---|---|---|---|---|
| User exports what they see in a standard table | Table → *Export* (XLSX/CSV) | SAC formatting, hierarchy indent, optional appendix | Snapshot | Standard; check SAP Help *Export Table Data* for the limits of your data source |
| A button that exports one or more tables with fixed settings | **ExportExcel / ExportCsv** technical objects + script (§2) | Scale/units, indented hierarchy, appendix | Snapshot | Works on standard **tables only** (`setWidget(Table \| Table[])`) |
| Board pack: the whole story or pages | Story → *Export* PDF / PowerPoint | As displayed | Snapshot | Custom widgets are included when `supportsExport: true` |
| Export the data behind a **custom visual** (bridge steps, chart series) | Kit widgets' own export (§3) | Excel number formats, colours, outline | Snapshot | Runs in the browser; no server, no extra licence |
| A formatted management table that exports exactly as shown (IBCS signs, Δ / Δ%, totals, grouping) | **Kit Export Table** (§3) | Full control | Snapshot | Adds an *Info* sheet (IDs, filters) and an optional *AddIn_Grid* |
| A workbook that stays **live** and refreshes against the model | **SAC add-in for Microsoft Excel** (§5) | Excel, add-in default format | Live | Tables + `SAP.GETDATA` formulas; Datasphere analytic models can be used live |
| Feed another system (bulk) | Datasphere: consumption OData API, database user (ODBC/JDBC); SAC models: Data Export Service | Raw | Scheduled/API | Not a user-facing export |

Two Datasphere-specific notes: SAC's *Data Export Service* covers SAC models (not live Datasphere models). On
Datasphere data, extract with Datasphere's own APIs. And *Open in Data Analyzer* from a story widget is listed as
unsupported on Datasphere live connections; use the analytic model preview in Datasphere or the Excel add-in
instead.

---

## 2. Scripted export of standard tables

The technical objects **Export to Excel** (`ExportExcel`), **Export to CSV** (`ExportCsv`) and **Export to PDF**
(`ExportPdf`) are added in the Outline (*Scripting → Technical Objects*). API (Optimized Story Experience / analytics
designer):

| ExportExcel method | Purpose |
|---|---|
| `setWidget(table: Table \| Table[])` | Tables to export |
| `setScope(ExportScope.All \| ExportScope.PointOfView)` | All data or what is shown |
| `setExportFormattedValues(bool)` | Use the model/story scaling, units and currencies |
| `setIndentedHierarchy(bool)` | Indent hierarchy row labels |
| `setAppendixIncluded(bool)` / `setDateIncluded(bool)` | Metadata appendix, export date |
| `setFileName(text)` | File name |
| `exportReport()` | Start the export |

`ExportCsv` has the same idea with `setHierarchyLevelsInIndividualCells(bool)` and a single table.

```js
// Button_Export – onClick
ExportExcel_1.setWidget([Table_PnL, Table_BS]);
ExportExcel_1.setScope(ExportScope.All);
ExportExcel_1.setExportFormattedValues(true);
ExportExcel_1.setIndentedHierarchy(true);
ExportExcel_1.setAppendixIncluded(true);
ExportExcel_1.setFileName("Group_PnL_" + Date.now().toString());
ExportExcel_1.exportReport();
```

These objects take standard tables only, so they can't export a custom widget. That gap is what the kit's export
covers. Since they are not supported on mobile, hide export buttons there.

---

## 3. The kit's Export Table widget

A data-bound table (Rows = dimensions, Columns = measures) built for financial reporting, with its own export.

### 3.1 On screen

- **Hierarchy tree** (one dimension with a hierarchy) with expand/collapse and `expandLevel`, or **flat** rows
  with repeated or blank member names.
- **Variance columns** Δ and Δ% between any two measures (`varianceActualIndex` vs `varianceBaseIndex`), with
  favourable/unfavourable colours, `increaseIsGood` and per-member inversion (`invertedMembers`, e.g. cost accounts),
  and mini variance bars.
- **Data bars**, **totals** (top or bottom; roots for trees, leaves for flat), **sorting** by any column (sort state is
  saved and bookmarkable), **search**, sticky header, frozen first column, zebra rows, density, colours and fonts.
- **Number formatting** done by the widget: scale auto (by the median of the values)/none/K/M/B with your symbols,
  decimals, percent decimals, prefix/suffix, minus or parentheses, red negatives, locale. Or `useSacFormatting` to show
  SAC's own formatted text.
- **Linked analysis** on row selection (tuple or first dimension), see [02](02_Linked_Analysis_Cookbook.md).

### 3.2 Export formats

| Format | Trigger | Content |
|---|---|---|
| **XLSX** | Toolbar or `ExportTable_1.exportTable("xlsx", "Name")` | Sheets described below |
| **CSV** | Toolbar or `exportTable("csv", …)` | UTF-8 with BOM; delimiter `auto` (`;` for locales with a decimal comma, else `,`), `,`, `;` or tab; with `;` numbers use a decimal comma; tree level and parent ID columns; member IDs |
| **Copy** | Toolbar or `exportTable("copy", …)` | Tab-separated text on the clipboard: paste straight into Excel |

`onExported` fires after each export, so a script can log or show a message.

### 3.3 XLSX anatomy

**Data sheet** (named after the table title):

| Row / column | Content |
|---|---|
| Rows 1–2 | Title, subtitle with export timestamp and row count (`exportIncludeTitle`) |
| Header row | Bold, filled, bottom border, wrapped; scale shown in measure headers (`showScaleInHeader`) |
| Dimension columns | Member text; tree levels as Excel **indent**; parent rows bold |
| Measure columns | **True numbers** (floating-point noise removed: values below 10⁹ rounded to 6 decimals, larger ones to 15 significant digits) with an Excel **number format** that applies the scale |
| Δ / Δ% columns | Numbers with their own format; font colour green/red by favourability |
| ID columns | One `<Dimension> ID` column per dimension with the plain member key (for VLOOKUP/XLOOKUP and the add-in) |
| Total row | Bold, filled, top border |
| Sheet settings | Frozen header and dimension columns, **autofilter**, fitted column widths, **outline levels** (Excel *Group*) for the hierarchy (`exportOutline`) |

Scaling is done **only by the number format**, never by changing the value, so sums and formulas in Excel stay
right. Examples of the generated formats:

| Setting | Excel format code |
|---|---|
| Scale M, 1 decimal, red negatives | `#,##0.0,,"M";[Red]-#,##0.0,,"M";#,##0.0,,"M"` |
| Scale K, 0 decimals, parentheses | `#,##0,"K";(#,##0,"K");#,##0,"K"` |
| Percent, 1 decimal, plus sign | `+#,##0.0%;-#,##0.0%;#,##0.0%` |
| Prefix "EGP ", no scale | `"EGP "#,##0.00;-"EGP "#,##0.00;"EGP "#,##0.00` |

**Info sheet** (`exportInfoSheet`): widget and version, instance name, export time, row count, display mode, scale,
search text, sort, every bound dimension and measure with its **technical ID**, and the active dimension filters read
from the data source (best effort: when the data source doesn't return filters, the sheet says so).

**AddIn_Grid sheet** (`exportAddinSheet`): see §4.

All of it is written by `src/shared/xlsx-lite.js`, a dependency-free XLSX writer (zip with the browser's
`CompressionStream`, shared strings, a style registry, outline levels, merged cells, freeze panes, autofilter). The
files follow the Office Open XML spec and were checked with LibreOffice and openpyxl in the kit's tests; open one in
your Excel version once before you roll it out.

### 3.4 Script

```js
ExportTable_1.setScale("M", 1);
ExportTable_1.setVarianceVisible(true);
ExportTable_1.sortBy("Actual", "desc");                // column key: a measure ID, a dimension ID, "__var" or "__varpct"; "" = model order
ExportTable_1.expandAll();
ExportTable_1.exportTable("xlsx", "PnL_" + Dropdown_Period.getSelectedKey());
```

### 3.5 Limits

- Export runs in the browser from the result set the widget received: what is bound and filtered is what you
  export. For six-figure row counts use the native export or a Datasphere extract.
- `maxRows` (default 3,000) caps rendering; raise it consciously.
- Styles are the Excel basics (fonts, fills, borders, number formats, indent, alignment). No charts or conditional
  formatting rules are written. Number colours come from the format codes and fixed font colours.

---

## 4. From a story table to a live Excel add-in workbook (AddIn_Grid)

The AddIn_Grid sheet is a starting point for rebuilding a story table as a live add-in report. It contains:

| Cell(s) | Content |
|---|---|
| B2 | Data source alias (`addinDataSource`, default `DS_1`): the alias of a table you insert with the add-in on the same model |
| Row 3 | Instructions |
| Row 5 | Template formula, e.g. `=SAP.GETDATA($B$2,"Account_7h2kq01",$A8,"Measures",B$7,"Version","public.Actual")` |
| Rows 6–7 | Dimension and measure **descriptions** (row 6) and **IDs** (row 7) |
| Row 8 on | One row per exported row: plain member IDs in the dimension columns, values as numbers (for reconciliation) |

Steps:

1. In Excel, sign in with the add-in and insert a table on the same model (it gets an alias such as `DS_1`; check with
   `=SAP.GETTABLENAME(<cell in the table>)`). Put the alias in B2.
2. Copy the template formula into the first value cell (B8 for one dimension) and fill right and down. The `$A8`
   (member per row) and `B$7` (measure per column) references make one formula work for the whole grid.
3. Compare with the static values the widget wrote: they should match for the same filters.
4. Check the IDs: `addinMeasureDimension` (default `Measures`) must be the measure dimension name the add-in uses for
   your model, and `addinFixedFilters` (e.g. `Version=public.Actual; Date=202612`) must use **IDs**, not descriptions.
   On Datasphere models there is no `public.` version prefix: use the member ID of your version/category dimension, or
   leave the version out when the measure is already restricted.

---

## 5. Excel add-in patterns for financial reporting

These patterns use the SAC add-in for Microsoft Excel (Windows, Mac, web). Every formula needs the alias of a table on
a sheet, and **member IDs** everywhere.

### 5.1 Asymmetric P&L: CY vs PY, MTD/QTD/YTD

**Datasphere analytic model with period-driven measures** (recommended, see
[07](07_Datasphere_Analytic_Model_Recipes.md)): the model has restricted measures such as `ACT_MTD`, `ACT_MTD_PY`,
`ACT_YTD`, `ACT_YTD_PY`, `BUD_YTD`, all driven by one reporting-period variable. The workbook sets the period once in the
add-in's prompt and the grid only names FS items and measures:

```
         A              B             C              D             E
1   alias            DS_1
6   (measure ID)     ACT_MTD       ACT_MTD_PY     ACT_YTD       ACT_YTD_PY
8   FS_REVENUE       =SAP.GETDATA($B$1,"FSItem",$A8,"Measures",B$6)   ← fill right and down
```

Don't add the period dimension to these formulas: a filter `Period = 012` on top of a YTD measure would cut it down to
one month (filters and restrictions intersect).

**SAC model, single periods:** put the period in the formula and derive PY with `SAP.TIMEOFFSET`:

```
B7  =$B$2                                   (reporting period ID, e.g. 202612)
C7  =SAP.TIMEOFFSET($B$1,"Date",$B$2,-12)   (same period last year)
B8  =SAP.GETDATA($B$1,"Account",$A8,"Date",B$7,"Version","public.Actual")
```

### 5.2 Dropdown-driven filters

```
=SAP.GETMEMBERS("DS_1","CompanyCode","ID_Description")        → spill a member list (helper sheet)
Data Validation → List → the spilled range                     → dropdown in B3
=SAP.OVERWRITEDIMENSIONFILTER(("DS_1","DS_2"),"CompanyCode",B3) → filter both tables at once
```

### 5.3 Variance columns and checks

Native Excel on top of `GETDATA`: `=C8-D8`, `=IFERROR(C8/D8-1,"")`, conditional formatting, sparklines. Put a check row
that compares a `GETDATA` total with the table total.

### 5.4 Performance

- Avoid volatile functions (`OFFSET`, `INDIRECT`, `NOW`, `TODAY`) around SAP formulas.
- Use tables for large blocks and formulas only where the layout is asymmetric.
- Turn on the add-in's performance profiling when a workbook gets slow.
- Datasphere analytic models are **read-only** in the add-in (no `SAP.SETDATA`); variables appear as prompts, and
  `SAP.GETVARIABLES` lists them.

---

## 6. Choosing for a group reporting pack

| Audience | Recommendation |
|---|---|
| Executives reading on screen | SAC story with the bridge and KPI widgets; PDF export for the board pack |
| Controllers who need "the table in Excel" once a month | Kit Export Table → XLSX (formats, grouping, Info sheet with filters and IDs) |
| Analysts who rework the numbers daily | Excel add-in workbook on the same Datasphere analytic model (GETDATA grid, dropdown filters) |
| Downstream systems | Datasphere consumption APIs / database user, scheduled |

Next: [04 — Waterfall and Bridge Guide](04_Waterfall_and_Bridge_Guide.md)
