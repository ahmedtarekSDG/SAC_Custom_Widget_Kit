# 07 — SAP Datasphere Analytic Models for the Widgets

How to model SAP Datasphere analytic models so the kit's widgets (bridge, table, KPI, chart, selector) and the Excel
add-in work well on a **live** connection: measure design for Actual/Budget/PY and MTD/QTD/YTD, hierarchies,
variables, IDs, performance, security and the restrictions of Datasphere live connections. Examples use group
reporting (consolidated P&L and cash flow), but the patterns are general.

---

## 1. Architecture

```mermaid
flowchart LR
  S[Sources<br/>S/4HANA ACDOCU, budget files] --> R[Relational / fact views<br/>parameter-free, persisted]
  R --> M[Analytic model<br/>measures, restricted & calculated measures,<br/>variables, hierarchies, data access controls]
  M -->|live connection| SAC[SAC story<br/>Optimized Story Experience]
  SAC --> W[Custom widgets<br/>data binding · linked analysis · export]
  M -->|live| XL[Excel add-in<br/>tables + SAP.GETDATA]
```

- SAC connects **live** to Datasphere and can use analytical datasets, **analytic models** and perspectives. The
  analytic model is the recommended object; new features land there.
- Consume analytic models in **Optimized Story Experience** stories (custom widget data binding needs it anyway).
- Story users need the **DW Consumer** role in Datasphere (plus space access) and the SAC live connection.
- **Data access controls** defined in Datasphere apply to every query, so widgets and Excel only see authorised
  data. Nothing to do in the widgets.

---

## 2. Rules for widget-friendly analytic models

1. **Deliver measures, not a version dimension to compare.** SAC's version-based variance features are not
   supported on Datasphere live data (SAP Note 2832606 lists the unsupported features). Model `ACT_…`, `BUD_…`,
   `…_PY` as restricted measures. Bridges, tables and KPI cards compare **measures**, which is exactly what the kit
   expects.
2. **One sign convention.** Signed amounts (revenue +, cost −) make P&L bridges and subtotals work without
   configuration. Document it in the measure description.
3. **Stable technical names.** Scripts, linked-analysis selections, the Excel add-in and the table's AddIn_Grid use
   IDs. Renaming a measure or dimension breaks them. Choose names once (`ACT_YTD`, `BUD_YTD`, `ACT_YTD_PY`, …).
4. **Short business names.** They become labels, legend entries and Excel headers.
5. **Hierarchies on the dimensions** (FS item, consolidation unit, profit centre): the table shows trees, the bridge
   builds subtotals, treemap/sunburst nest.
6. **Variables for the reporting period and scenario,** with defaults derived from data (last closed period), so
   stories open without a prompt in most cases.
7. **Keep fact views parameter-free and persisted.** Input parameters on the fact view prevent persistence; put the
   dynamic logic into variables and helper views instead (§3.2).
8. **Prune.** Expose only the dimensions and measures the stories use; it reduces query cost and confusion.

---

## 3. Period logic: MTD / QTD / YTD, current and previous year

Three proven options. Pick one per model and stay consistent.

| | A. Restricted measures + derived variables | B. Period-mapping view | C. Time functions in restricted measures |
|---|---|---|---|
| Where the logic lives | Analytic model | SQL view layer | Analytic model |
| Fact view | Unchanged, persisted | Joined with a mapping table (rows multiply) | Unchanged |
| Fiscal calendars, special periods 13–16, carry-forward 000 | Possible, more variables | Easiest: the mapping table decides | Depends on release support |
| Effort | Medium | Medium | Low if available |
| Notes | Restricted-measure names are static ("ACT_YTD", not "YTD Dec 2026"): set titles from script | Persist the result if volumes allow | Newer releases document a `YTD()` function for restricted measures. It needs a date dimension with correct time semantics, and a July 2026 community thread reports it only returned values with the date shown **as a hierarchy**, not flat: **Verify** in your tenant |

### 3.1 Option A: restricted measures with derived variables

A pattern described by Do Hai Dang Le on SAP Community (summarised on LinkedIn): keep the fact view clean, move the
dynamic parts into variables:

1. **User-facing variables:** `V_REP_YEAR`, `V_REP_PERIOD` (with value help views).
2. **Parameter view** (a helper SQL view with input parameters mapped from those variables) that returns
   `CUR_YEAR`, `CUR_PERIOD`, `PREV_YEAR`, `QTR_START_PERIOD`.
3. **Derived restriction variables** in the analytic model (`I_CUR_YEAR`, `I_CUR_PERIOD`, `I_PREV_YEAR`, …) whose values
   come from the parameter view (lookup entity). Derived variables aren't shown to the user.
4. **Defaults** for the user-facing variables from a helper view that reads the last closed period (closing calendar).
5. **Restricted measures** on the signed amount:

| Measure | Restriction |
|---|---|
| `ACT_PER` | Category = ACT · Year = I_CUR_YEAR · Period = I_CUR_PERIOD |
| `ACT_QTD` | Category = ACT · Year = I_CUR_YEAR · Period from I_QTR_START to I_CUR_PERIOD |
| `ACT_YTD` | Category = ACT · Year = I_CUR_YEAR · Period ≤ I_CUR_PERIOD |
| `ACT_PER_PY`, `ACT_YTD_PY` | Same with Year = I_PREV_YEAR |
| `BUD_PER`, `BUD_YTD` | Category = BUD, current-year restrictions |
| `FC_YTD` | Category = FC (or the forecast version) |

Use range/interval restrictions (or two derived variables for from/to) as your release offers them. Balance-sheet
items need period 000 (carry-forward) inside the YTD range.

### 3.2 Option B: a period-mapping view

A mapping table tells, for every **reporting** period, which **posting** periods belong to MTD, QTD and YTD of the
current and the previous year. It's a well-known technique from BW/HANA, and it handles fiscal calendars and special
periods without any variable logic.

```sql
-- V_FISCPER: one row per fiscal period from your calendar
--   FISCPER ('2026012'), FISCYEAR (2026), PERIOD_NUM (0 = carry-forward, 1..12, 13..16 special)

-- V_PERIOD_MAP
SELECT r."FISCPER"  AS "REP_FISCPER",
       p."FISCPER"  AS "POST_FISCPER",
       'CY'         AS "YEAR_SHIFT",
       CASE WHEN p."PERIOD_NUM" = r."PERIOD_NUM" THEN 1 ELSE 0 END                                AS "IN_MTD",
       CASE WHEN p."PERIOD_NUM" > 0
             AND CEIL(LEAST(p."PERIOD_NUM", 12) / 3.0) = CEIL(LEAST(r."PERIOD_NUM", 12) / 3.0)
            THEN 1 ELSE 0 END                                                                      AS "IN_QTD",
       1                                                                                          AS "IN_YTD"
FROM "V_FISCPER" r
JOIN "V_FISCPER" p
  ON p."FISCYEAR" = r."FISCYEAR"
 AND p."PERIOD_NUM" <= r."PERIOD_NUM"
UNION ALL
SELECT r."FISCPER", p."FISCPER", 'PY',
       CASE WHEN p."PERIOD_NUM" = r."PERIOD_NUM" THEN 1 ELSE 0 END,
       CASE WHEN p."PERIOD_NUM" > 0
             AND CEIL(LEAST(p."PERIOD_NUM", 12) / 3.0) = CEIL(LEAST(r."PERIOD_NUM", 12) / 3.0)
            THEN 1 ELSE 0 END,
       1
FROM "V_FISCPER" r
JOIN "V_FISCPER" p
  ON p."FISCYEAR" = r."FISCYEAR" - 1
 AND p."PERIOD_NUM" <= r."PERIOD_NUM"
```

```sql
-- V_GR_REPORTING: measures per reporting period (fact view stays the source of truth)
-- Fact columns are illustrative; on ACDOCU they are typically consolidation unit, FS item, sub-item,
-- version/category, fiscal year/period and the group-currency amount.
SELECT m."REP_FISCPER",
       f."CONS_UNIT", f."FS_ITEM", f."SUBITEM",
       SUM(CASE WHEN f."CATEGORY" = 'ACT' AND m."YEAR_SHIFT" = 'CY' AND m."IN_MTD" = 1 THEN f."AMOUNT_GC" END) AS "ACT_PER",
       SUM(CASE WHEN f."CATEGORY" = 'ACT' AND m."YEAR_SHIFT" = 'CY' AND m."IN_QTD" = 1 THEN f."AMOUNT_GC" END) AS "ACT_QTD",
       SUM(CASE WHEN f."CATEGORY" = 'ACT' AND m."YEAR_SHIFT" = 'CY' AND m."IN_YTD" = 1 THEN f."AMOUNT_GC" END) AS "ACT_YTD",
       SUM(CASE WHEN f."CATEGORY" = 'ACT' AND m."YEAR_SHIFT" = 'PY' AND m."IN_MTD" = 1 THEN f."AMOUNT_GC" END) AS "ACT_PER_PY",
       SUM(CASE WHEN f."CATEGORY" = 'ACT' AND m."YEAR_SHIFT" = 'PY' AND m."IN_YTD" = 1 THEN f."AMOUNT_GC" END) AS "ACT_YTD_PY",
       SUM(CASE WHEN f."CATEGORY" = 'BUD' AND m."YEAR_SHIFT" = 'CY' AND m."IN_YTD" = 1 THEN f."AMOUNT_GC" END) AS "BUD_YTD"
FROM (   -- aggregate to period level first: the join then multiplies periods, not documents
       SELECT "FISCPER", "CATEGORY", "CONS_UNIT", "FS_ITEM", "SUBITEM", SUM("AMOUNT_GC") AS "AMOUNT_GC"
       FROM "V_GR_FACT"
       GROUP BY "FISCPER", "CATEGORY", "CONS_UNIT", "FS_ITEM", "SUBITEM"
     ) f
JOIN "V_PERIOD_MAP" m
  ON m."POST_FISCPER" = f."FISCPER"
GROUP BY m."REP_FISCPER", f."CONS_UNIT", f."FS_ITEM", f."SUBITEM"
```

Two findings from SAP's *Running YTD on fiscal periods* post (tests on 25M+ rows):

- **Aggregate before the period join**, as above, and push filters into that subquery. The YTD join multiplies
  whatever goes into it.
- A **non-equi join** (`p.PERIOD_NUM <= r.PERIOD_NUM` against a small period list) ran about **twice as fast** as an
  equi-join on a pre-filled mapping table. The view above builds the mapping with a non-equi join, so you can inline it.
- **Window functions** (`SUM(…) OVER (PARTITION BY year ORDER BY period)`) are simpler but **drop periods without
  data**, so YTD values go missing for months with no postings. That's common per product or cost centre. The
  period-mapping join doesn't have this gap.

In the analytic model, `REP_FISCPER` gets a **mandatory single-value filter variable** (default: last closed period).
Each reporting period reads up to 13 posting periods (YTD), so persist `V_GR_REPORTING` if volumes allow, or limit the
mapping to the periods you report on.

Adjust the QTD rule to your calendar (the example maps special periods 13–16 to Q4 and excludes period 000 from QTD).

### 3.3 Labels that follow the period

Measure names are static. Let the story script set the widget titles from the variable value:

```js
// onInitialization, and again after the user changes the period variable
var values = WaterfallBridge_1.getDataSource().getVariableValues("V_REP_PERIOD");
var period = "";
if (values.length > 0) {
  period = cast(Type.SingleVariableValue, values[0]).value;   // e.g. "2026012"
}
WaterfallBridge_1.setTitle("EBIT bridge", "Budget → Actual, YTD " + period);
ExportTable_1.setTitle("Group P&L", "YTD " + period);
```

---

## 4. Hierarchies

| Need | Datasphere | In the widgets |
|---|---|---|
| P&L / balance sheet structure | FS item (account) dimension with a parent-child hierarchy (one or several, e.g. a hierarchy directory for multiple FS item hierarchies) | Table: tree with expand/collapse; bridge: automatic subtotals in `auto` mode |
| Group structure | Consolidation unit / segment hierarchy | Selector (top level), treemap/sunburst, table tree |
| Cash flow | Sub-item (movement) dimension or a cash-flow FS item hierarchy | Bridge with opening/closing totals |

Points to watch:

- Activate the hierarchy in the widget's **Builder panel**; rows then carry `parentId`. Check the drill level
  (all levels for trees and subtotals).
- **Non-additive nodes** (ratios, KPIs inside the hierarchy) are skipped by the bridge in `auto` mode; list explicit
  totals in `totalMembers` if needed.
- **Sign flips for presentation** (cost shown positive in a node) belong in the view layer or in a dedicated measure,
  not in the hierarchy, or bridges will add the wrong sign.
- Technical nodes ("Not assigned") can be removed with `excludeMembers` (bridge) or `hiddenColumns`/filters (table).

---

## 5. Price-volume-mix measures

The bridge's measures mode needs effect measures that add up to the change in revenue. Compute the per-product parts
where the product grain exists, then let the analytic model aggregate:

```sql
-- V_PVM_BASE: one row per product (and customer, if mix is analysed per customer) with CY and PY side by side
SELECT "PRODUCT", "REGION",
       COALESCE(SUM(CASE WHEN "YEAR_SHIFT" = 'CY' THEN "REVENUE" END), 0) AS "REV_CY",
       COALESCE(SUM(CASE WHEN "YEAR_SHIFT" = 'PY' THEN "REVENUE" END), 0) AS "REV_PY",
       COALESCE(SUM(CASE WHEN "YEAR_SHIFT" = 'CY' THEN "QTY" END), 0)     AS "QTY_CY",
       COALESCE(SUM(CASE WHEN "YEAR_SHIFT" = 'PY' THEN "QTY" END), 0)     AS "QTY_PY"
FROM "V_SALES_YTD"
GROUP BY "PRODUCT", "REGION";

-- V_PVM: effects per product
SELECT b.*,
       CASE WHEN "QTY_CY" <> 0 AND "QTY_PY" <> 0
            THEN ("REV_CY" / "QTY_CY" - "REV_PY" / "QTY_PY") * "QTY_CY" ELSE 0 END             AS "PRICE_EFF",
       CASE WHEN "QTY_PY" <> 0
            THEN ("QTY_CY" - "QTY_PY") * ("REV_PY" / "QTY_PY")
            ELSE "REV_CY" END                                                               AS "VOLMIX_EFF"
FROM "V_PVM_BASE" b
```

Per product, `PRICE_EFF + VOLMIX_EFF = REV_CY − REV_PY` (new products: all volume/mix; discontinued products:
volume/mix = −REV_PY). Revenue without quantity (fees, rebates) doesn't fit the formula and shows up as residual.

In the analytic model:

| Measure | Definition |
|---|---|
| `REV_PY`, `REV_CY` | Source measures |
| `PRICE_EFF` | Source measure (sum of per-product price effects) |
| `VOL_EFF` | Calculated (after aggregation): `(QTY_CY − QTY_PY) × REV_PY / QTY_PY` at the level displayed (pure volume at the average PY price; guard against `QTY_PY = 0`) |
| `MIX_EFF` | Calculated: `VOLMIX_EFF − VOL_EFF` |

Bind `REV_PY, PRICE_EFF, VOL_EFF, MIX_EFF, REV_CY` to the bridge in measures mode. New or discontinued products land
in volume/mix by construction; anything that doesn't reconcile (rounding, FX if not modelled) appears as the
**residual** step. Alternatively compute the price effect in the analytic model with **exception aggregation** (sum
over product) instead of the view. Quantities must be in one unit across the products you aggregate.

---

## 6. Widget-by-widget binding on the model

| Widget | Dimensions | Measures | Settings |
|---|---|---|---|
| Waterfall: P&L walk | FS item (hierarchy) | `ACT_YTD` | dimension, `hierarchyMode: auto` |
| Waterfall: Budget → Actual | Business unit or FS item | `BUD_YTD`, `ACT_YTD` | variance, `sortSteps: absDesc`, `topN: 8` |
| Waterfall: PY → CY | Region | `ACT_YTD_PY`, `ACT_YTD` | variance |
| Waterfall: PVM | — | `REV_PY, PRICE_EFF, VOL_EFF, MIX_EFF, REV_CY` | measures, residual on |
| Waterfall: cash | Sub-item / cash-flow category | `CASH_YTD` (opening as a member, or `firstIsTotal`) | dimension, `totalMembers` |
| Export Table: group P&L | FS item (hierarchy) | `ACT_PER, ACT_YTD, BUD_YTD, ACT_YTD_PY` | `showVariance`, `varianceActualIndex: 1` (ACT_YTD), `varianceBaseIndex: 2` (BUD_YTD); `invertedMembers` only for unsigned data |
| KPI Card: revenue YTD | Fiscal period (trend, optional) | `ACT_YTD` (value), `BUD_YTD` (comparison) | `valueMode: total`. With option A, a YTD measure drilled by period returns the monthly amounts, so the sparkline shows months and the total is YTD. With option B add the posting period as a dimension for trends |
| Universal Chart: monthly trend | Fiscal period | `ACT_YTD`, `BUD_YTD` drilled by period (option A) | `combo` or `line` |
| Universal Chart: contribution | Consolidation unit hierarchy | `ACT_YTD` | `treemap` / `sunburst` |
| Member Selector | Consolidation unit / segment | `ACT_YTD` (optional, for values and bars) | `chips`, multi, linked analysis on |

The kit computes Δ and Δ% itself (table variance columns, bridge steps), so the model doesn't need variance measures
for the widgets. Add them anyway if the Excel add-in or standard tables also need them.

---

## 7. IDs you will need

| ID | Where it's used | How to find it |
|---|---|---|
| Dimension technical names | Linked-analysis selections, `setDimensionFilter`, add-in formulas | Analytic model; table export *Info* sheet; `$0._props.dataBinding.metadata.dimensions` |
| Measure technical names | `sortBy`, `totalMembers` in measures mode, add-in measure column | Analytic model; *Info* sheet |
| Member IDs (incl. hierarchy unique names) | Selections, `excludeMembers`, `invertedMembers`, `setSelectedMembers` | Result set; table *ID* columns in XLSX |
| Variable technical names | `setVariableValue` / `getVariableValues` in scripts; add-in prompts | Analytic model variables |
| Category / version member IDs | Restricted measures, add-in fixed filters | Your master data (`ACT`, `BUD`, …; there is no SAC `public.` prefix on Datasphere) |

`invertedMembers`, `totalMembers` and `excludeMembers` accept IDs **or** descriptions, so business names work for
quick setups; IDs are safer across languages.

---

## 8. Performance

- **Persist** the heavy views (view persistency) and keep the fact view free of input parameters so it can be
  persisted.
- **Prune** the analytic model; each widget binds only a few measures.
- **Limit result size** per widget: filter in the Builder panel, use Top N, avoid binding high-cardinality
  dimensions (documents, customers) to visuals.
- **Many restricted measures** on one query cost time; split rarely used measures into a second analytic model.
- **Monitor** in Datasphere (system monitor / statement logs) while testing the story; combine with SAC's
  performance analysis.
- In SAC, use **viewport loading** for long stories and avoid many widgets refreshing at once.

---

## 9. Restrictions to plan around

On Datasphere live connections (see SAP Note 2832606 for the current list; community summaries in the Resource
Library):

- Version-based variance and version mapping are not supported → restricted measures (§2).
- Blending: limited (Datasphere data with local SAC data, or with Datasphere data from the same space). Linked
  dimensions across spaces are not supported.
- Comment widgets, scheduled publications, *Open in Data Analyzer*, copying widgets between stories, importing pages
  from stories with Datasphere models, R visualizations, custom geo shapes and SAP Digital Boardroom are not supported.
  Smart Insights, Smart Discovery and Smart Predict don't work on Datasphere data.
- Analytic models can be consumed only in **Optimized** stories, not in Classic stories (they're listed as unsupported
  there).
- Some Datasphere data types aren't supported in SAC (for example large binary/string types); keep measures numeric
  and dimensions as strings/dates.
- Custom widget restrictions apply on top ([01 §10](01_Custom_Widget_Master_Guide.md#10-restrictions)).

---

## 10. Checklist

1. Analytic model deployed; story user has DW Consumer role and space access.
2. Measures: `ACT_*`, `BUD_*`, `*_PY` (and PVM effects if needed) with stable technical names and short business names.
3. Period variable(s) with derived defaults; fact view persisted.
4. Hierarchies on FS item / consolidation unit.
5. POC on the tenant: [06 §7](06_Deployment_Testing_Troubleshooting.md#7-proof-of-concept-in-your-tenant-datasphere-analytic-model),
   items 2–5 first.
6. IDs documented (§7) for scripts and the Excel add-in.

Next: [08 — Resource Library](08_Resource_Library.md)
