# 05 — What You Can Build with Custom Widgets: Possibilities Catalog

A catalogue of what custom widgets can do in SAC, grouped by purpose, with the technique, whether data binding and
linked analysis apply, what exists already (in this kit, SAP samples, community, vendors) and the catch. Use it to
scope ideas with business users and to pick the lightest technique (native → composite → add-on → custom widget).

Legend: **DB** = can be fed by data binding · **LA** = can be a linked-analysis source · ✅ in this kit ·
🔗 sample or community example exists (see [08](08_Resource_Library.md)).

For design judgement (which of these visuals are missing natively, which card types work, how to compare, and what
to build first per business area) see [09 — Beyond Native](09_Beyond_Native_Visuals_Cards_and_Features.md).

---

## 1. Visualizations SAC doesn't have (or has with fewer options)

### 1.1 In this kit

| Visual | Widget | Data shape | DB | LA |
|---|---|---|---|---|
| Waterfall / bridge (dimension, variance, measures/PVM) | ✅ Waterfall / Bridge | 1 dimension (hierarchy optional) + 1–n measures | Yes | Yes |
| Bar, horizontal bar, stacked, 100 % stacked | ✅ Universal Chart | Category dim (+ optional series dim) + measures | Yes | Yes |
| Line, area, combo (bars + line on 2nd measure) | ✅ Universal Chart | Category + measures | Yes | Yes |
| Pareto (sorted bars + cumulative % line) | ✅ Universal Chart | Category + 1 measure | Yes | Yes |
| Pie, donut, rose (Nightingale), funnel | ✅ Universal Chart | Category + 1 measure | Yes | Yes |
| Gauge with target pointer | ✅ Universal Chart | Measure 1 = value, `gaugeTargetIndex` = target | Yes | — |
| Radar | ✅ Universal Chart | Category = axes, each measure = a series | Yes | — |
| Heatmap (matrix) | ✅ Universal Chart | 2 dimensions + 1 measure | Yes | Yes (cell tuple) |
| Scatter / bubble | ✅ Universal Chart | Point dim + 2 measures (x, y), 3rd = bubble size, 2nd dim = colour group | Yes | Yes |
| Treemap, sunburst, tree | ✅ Universal Chart | Hierarchical dimension (parentId) or dim 1 > dim 2 | Yes | Yes |
| Sankey | ✅ Universal Chart | Source dim + target dim + flow measure | Yes | Yes (link tuple) |
| Extra marks and styling on the generated chart (reference lines, shaded zones, bands, dashed series) | ✅ Universal Chart + `optionOverride` (JSON merged element by element into the generated option; recipes in [09](09_Beyond_Native_Visuals_Cards_and_Features.md)) | As bound | Yes | As bound |
| Other ECharts forms with a different data shape (calendar, boxplot, parallel, graph, themeRiver, …) | Needs a mapping in code (new chart type or widget, see the backlog in [09](09_Beyond_Native_Visuals_Cards_and_Features.md)) | Depends | Yes | Partly |
| KPI tile: value, Δ vs comparison, status, progress, sparkline | ✅ KPI Card | Optional trend dim + value measure + comparison measure | Yes | Sparkline points |

### 1.2 Other proven visuals

| Visual | Technique / library | Notes |
|---|---|---|
| Gantt / project timeline | DHTMLX Gantt, UI5 Gantt 🔗 | Dates come as dimension members or attributes; licences differ (DHTMLX is GPL/commercial) |
| IBCS charts and tables (scenario notation, integrated variances, bullet charts) | Vendor suite (graphomate charts/matrix 🔗) or own SVG | Vendor: supported product with an IBCS property sheet; own build: follow the kit's bridge as a pattern |
| Bullet chart, dumbbell, slope chart, butterfly/tornado, small multiples | D3 or plain SVG | Small (<30 KB), no library needed |
| Marimekko, box plot, violin, parallel coordinates | ECharts / D3 / Vega-Lite | Box plots need the raw distribution: bind a fine-grained dimension |
| Radial bar, 3D, liquid fill, solid gauges | Highcharts 🔗 (commercial licence), amCharts 🔗, ECharts-GL | Check the licence for enterprise use |
| Decomposition tree (Power BI style), driver trees | D3 / own SVG 🔗 (several 2026 community posts) | Expanding a node = re-binding or a hierarchy; cache levels in the widget |
| Network graph, org chart, chord | ECharts graph, D3-force, FusionCharts 🔗 | Hierarchies via parentId; large graphs need WebGL |
| Word cloud | SAP sample 🔗 | Text from a dimension, size from a measure |
| Maps with own shapes or tiles | Leaflet, OpenLayers, Google Maps 🔗 | Tile servers and API keys are external calls (CORS, data privacy); SAC's geo map covers many cases |
| Python visuals (Matplotlib) in the browser | Pyodide 🔗 (SAP sample) | Several MB download, slow first load: demos rather than production |
| Vega / Vega-Lite specs | vega-embed | Lets analysts change the visual with JSON, like the kit's `optionOverride` |

---

## 2. Tables and grids

| Possibility | Technique | DB | LA | Notes |
|---|---|---|---|---|
| Formatted reporting table with tree, Δ/Δ%, totals, data bars, search, sort, XLSX/CSV export | ✅ Export Table | Yes | Rows | See [03](03_Tables_Excel_Export_and_Excel_Add-in.md) |
| Excel-like grids (column pinning, grouping, cell editing) | AG Grid Community (MIT), Tabulator (MIT), Handsontable (commercial) | Yes | Rows | Editing doesn't write back by itself; see §6 |
| IBCS tables, sparklines and bars in cells | Own HTML/SVG, graphomate matrix 🔗 | Yes | Rows | |
| Pivot with drag-and-drop | PivotTable.js, WebDataRocks | Yes (flat result) | — | SAC's own table pivots on the server, which scales better |
| Row-level annotations | Own UI + a backend API | — | — | Custom widgets don't support SAC comments; persist notes in your own service |

---

## 3. KPIs, status and alerts

| Possibility | Technique | Notes |
|---|---|---|
| KPI tile with thresholds, status stripe, progress, sparkline | ✅ KPI Card | `getStatus()` + `onStatusChange` let a script react (e.g. show a popup when a KPI turns red) |
| Traffic lights, progress rings, circle progress | SVG 🔗 (Circle Progress Bar widget) | Thresholds as properties |
| Animated counters, rankings, leaderboards ("gamify") | CSS/SVG 🔗 | Respect reduced-motion settings |
| Notifications / toasts after a script action | SweetAlert-style widget 🔗 | No data binding needed |

---

## 4. Selection, input and navigation

| Possibility | Technique | DB | LA | Notes |
|---|---|---|---|---|
| Chips / segmented buttons / list with values and bars | ✅ Member Selector | Yes | Yes (single/multi) | Selection survives bookmarks (`selectedMembers`) |
| Date and range pickers | SAP sample datepicker 🔗 | — | — | Push the value to filters/variables in `onChange` scripts |
| Sliders (thresholds, what-if parameters) | `<input type=range>` | — | — | Value as output property → script → calculation input or a story variable |
| Hierarchy tree selector with search | HTML tree | Yes (hierarchy) | Yes | |
| Tabs, accordion, breadcrumb, stepper, menus | HTML/CSS | — | — | Often better as a **composite** of standard widgets |
| Navigation to other stories/pages/URLs | Event → story script | — | — | The widget fires the event; navigation is done by script |
| Forms (dynamic fields, validation) | 🔗 FormFlex | — | — | Submit via a backend API or via script to planning |

---

## 5. Integration with other systems

All calls run **from the user's browser**. The service must allow CORS for the SAC origin, and authentication must
not rely on secrets stored in the widget (put a backend in between, e.g. on SAP BTP).

| Possibility | Examples |
|---|---|
| LLM assistants and data Q&A | ChatGPT widgets 🔗, GenAI dashboards 🔗, Databricks Genie widget 🔗 | 
| Messaging and notifications | RabbitMQ / Kafka / PubNub demos 🔗, Teams/Slack via webhook backend |
| Meetings and collaboration | Launch a Zoom meeting 🔗 |
| Documents and media | Document viewer (Excel/PowerPoint/PDF) 🔗, image widget 🔗, YouTube player 🔗 |
| Reference data | Currency rates 🔗, weather, market data |
| Write-back to non-SAP stores | REST API to your service (approval comments, data quality flags) |
| Hardware/IoT demos | Web Bluetooth (micro:bit) 🔗 |

Questions to ask before building: Does data leave the tenant? Who pays for and secures the API? What happens when the
service is down (the widget must degrade gracefully)?

---

## 6. Planning helpers

| Possibility | Status |
|---|---|
| File upload to a planning version via the Data Import API | The SAP **File Upload Custom Widget** 🔗 has reached end of life; SAC has a native *End User File Upload* since QRC3 2024. Prefer the native feature |
| Custom input forms that write to a planning model | The widget collects input and fires an event; the story script writes it (e.g. `Table.getPlanning().setUserInput(...)` + `submitData()`), or an API call writes it |
| Driver sliders for simulation | Slider widget → script → planning table or calculation input |
| Data action launchers with confirmation | Widget for the dialog, script runs the data action / multi action |

Custom widgets don't plan by themselves. They collect and show; SAC's planning APIs or the Data Import API do the
writing.

---

## 7. Utility widgets (no or little UI)

| Possibility | Examples |
|---|---|
| Timers, delays, auto-refresh, polling | DelayCode 🔗 (`setTimeout` exposed to scripts) |
| Client-side caching of lookups | CacheBuddy 🔗 |
| Clipboard copy, client-side file generation (XLSX, CSV, PNG, SVG) | ✅ `src/shared/sac-kit.js`, `xlsx-lite.js` |
| QR codes for a story URL or a document | QR generator 🔗 |
| Script data feeding: show data from several models in one visual | Story script reads `getResultSet()` from two tables and passes JSON to a widget method (e.g. `setData(json)`) |

The last pattern is how to combine **two models in one visual** when the data binding (one model per binding) is not
enough: bind nothing, expose `setData(json: string)`, and call it from `onResultChanged` of the source tables.

---

## 8. Extending standard widgets instead

| Need | Technique |
|---|---|
| Richer tooltip on a standard chart | **Widget add-on**, tooltip type |
| Extra marks or styling on bar/line plot areas | **Widget add-on**, plot area (general): bar/column, stacked bar/column, stacked area, line only (not the waterfall, not tables) |
| Restyled numeric point | **Widget add-on**, plot area (numeric point) |
| Reusable header/footer/navigation/dialog/KPI strip | **Composite** (standard widgets + script, transportable, data source can be remapped per story) |
| Corporate look | Story theme and CSS (standard widgets); custom widgets take colours and fonts from their own properties |
| Ready-made chart types from SAP | **Custom Widget Library** (one-click install; currently SAP Business Data Cloud tenants only; published as samples) |

---

## 9. What custom widgets cannot do

- Use the story theme or story CSS, data point comments, translation, scheduled publications, paused refresh and
  some smart features (see [01 §10](01_Custom_Widget_Master_Guide.md#10-restrictions)).
- Access other widgets' DOM, the SAC page, or the user's session token. Scripts are the only bridge to other
  widgets.
- Query a model directly. Data arrives through the data binding (one model per binding) or from scripts.
- Persist data on the server without your own backend (properties are saved with the story by designers, and with
  bookmarks by users, but they are not a database).
- Run outside Chrome/Edge.

---

## 10. Choosing quickly

```
Does a standard widget (with conditional formatting / calculations) show it?   → use it
Is it a reusable arrangement of standard widgets?                             → composite
Is it a standard chart that needs a better tooltip or a few extra marks?      → widget add-on
Is it in the Custom Widget Library or this kit?                               → upload and configure
Otherwise                                                                     → custom widget (start from the starter template)
```

Next: [06 — Deployment, Testing and Troubleshooting](06_Deployment_Testing_Troubleshooting.md)
