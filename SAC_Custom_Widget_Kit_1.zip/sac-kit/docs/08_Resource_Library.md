# 08 — Resource Library

Annotated list of the documentation, blogs, repositories, videos and posts on SAC custom widgets, widget add-ons,
linked analysis, Excel export and Datasphere modelling that this kit was built from. Collected in November 2026.

How to read it: ★ = start here · 🛠 = code you can download · 🎥 = video · 📖 = read in full for these docs (the
others were reviewed from search excerpts) · (year) = publication year where known.
Third-party code is untrusted until reviewed; check licences before reuse (several samples bundle commercial
libraries).

---

## 1. SAP documentation

| Resource | What it gives you |
|---|---|
| ★ [Custom Widget Developer Guide (HTML)](https://help.sap.com/doc/0ac8c6754ff84605a4372468d002f2bf/release/en-US/index.html) | The reference: JSON, web component, data binding, styling/builder panels, mobile, export, linked analysis, viewport loading, Lite Viewer, bookmarks, best practices, custom types, restrictions |
| ★📖 [Custom Widget Developer Guide (PDF)](https://help.sap.com/doc/c813a28922b54e50bd2a307b099787dc/release/en-US/CustomWidgetDevGuide_en.pdf) | Version 2026.8 (24 June 2026), 80 pages, the basis of chapter 01: restrictions, JSON reference, lifecycle, data binding, export (`serializeCustomWidgetToImage`), linked analysis, viewport loading, Lite Viewer (`supportsLWV`), bookmarks (`includeInBookmarks`), best practices |
| ★ [Hosting Custom Widgets](https://help.sap.com/docs/SAP_ANALYTICS_CLOUD/0ac8c6754ff84605a4372468d002f2bf/e983213a29554afb9700905ec0beb3d3.html) | SAC-hosted vs own web server; ZIP ≤ 10 MB, no subfolders, max 50 SAP-hosted widgets per tenant, not on Neo |
| ★ [Widget Add-On Developer Guide](https://help.sap.com/doc/35a443e276964981a85bf2b0cb58e180/release/en-US/index.html) | Tooltip and plot-area add-ons: JSON, extension points, restrictions |
| [Use Custom Add-Ons on Your Widgets](https://help.sap.com/doc/00f68c2e08b941f081002fd3691d86a7/2023.20/en-US/4a36af2e56ef44ca87ed4c538dc755bf.html) | Uploading add-ons, permissions, **major/minor version rules** |
| ★ [Optimized Story Experience API Reference](https://help.sap.com/doc/1639cb9ccaa54b2592224df577abe822/release/en-US/index.html) | Script API: DataSource, linked analysis, ExportExcel/ExportCsv/ExportPdf, input controls, variables |
| [Live Data Connections to SAP Datasphere](https://help.sap.com/doc/00f68c2e08b941f081002fd3691d86a7/2023.20/en-US/ad4281e2875949f0b4d45d1072ff4c38.html) | Consuming analytical datasets, analytic models and perspectives live |
| [Datasphere: Derived Variables](https://help.sap.com/doc/c8a54ee704e94e15926551293243fd1d/cloud/en-US/82f40f73bbbf42a283648fa312a5aec2.html) | Variables derived through a lookup entity (basis for period logic, see [07](07_Datasphere_Analytic_Model_Recipes.md)) |
| SAP Note **2832606** – Unsupported Features with SAP Datasphere Live Connections in SAP Analytics Cloud | The authoritative list of what doesn't work on Datasphere live (version-based variance, blending limits, comments, …) |
| [KBA 2597724](https://userapps.support.sap.com/sap/support/knowledge/en/2597724) | Linked analysis from two source widgets: the second selection cancels the first (intended) |
| [KBA 3063225](https://userapps.support.sap.com/sap/support/knowledge/en/3063225) | Native variance waterfall switches off when a page filter changes the compared members |

## 2. SAP Learning

| Resource | Notes |
|---|---|
| ★ [Creating and Working with Custom Widgets in SAP Analytics Cloud Stories](https://learning.sap.com/courses/creating-and-working-with-custom-widgets-in-sap-analytics-cloud-stories) | Free course (~2 h) with exercises |
| — [Introducing Custom Widgets](https://learning.sap.com/courses/creating-and-working-with-custom-widgets-in-sap-analytics-cloud-stories/introducing-custom-widgets-in-sap-analytics-cloud) | Concepts |
| — [Implementing the Web Component Foundation](https://learning.sap.com/courses/creating-and-working-with-custom-widgets-in-sap-analytics-cloud-stories/implementing-the-web-component-foundation) | First web component, metadata, upload |
| — [Importing Custom Widgets](https://learning.sap.com/courses/creating-and-working-with-custom-widgets-in-sap-analytics-cloud-stories/importing-custom-widgets-into-sap-analytics-cloud) | JSON + ZIP import |
| — [Rendering Data with a Visualization Library](https://learning.sap.com/courses/creating-and-working-with-custom-widgets-in-sap-analytics-cloud-stories/rendering-data-with-a-visualization-library) | Data binding → ECharts |
| — [Adding Interactivity: Properties, Methods, Events](https://learning.sap.com/courses/creating-and-working-with-custom-widgets-in-sap-analytics-cloud-stories/adding-interactivity-to-custom-widgets-with-properties-methods-and-events) | Script API, events, custom types |
| — [Using a Custom Widget in a Story](https://learning.sap.com/courses/creating-and-working-with-custom-widgets-in-sap-analytics-cloud-stories/using-a-custom-widget-in-a-story) | Builder/Styling panels, comparison with built-in charts |
| — [Exploring Ready-to-Use Custom Widgets](https://learning.sap.com/courses/creating-and-working-with-custom-widgets-in-sap-analytics-cloud-stories/exploring-ready-to-use-custom-widgets) | SAP sample gallery |
| [Exploring SAP Datasphere: Working with Analytic Models](https://learning.sap.com/courses/exploring-sap-datasphere/working-with-analytic-models) | Restricted/calculated measures, variables, consumption in SAC and Excel |

## 3. SAP Community: announcements and guides from SAP

| Post | Notes |
|---|---|
| [Announcing Custom Widgets in SAP Analytics Cloud](https://blogs.sap.com/2019/11/25/announcing-custom-widgets-in-sap-analytics-cloud/) (2019) | Origin and design ideas of the SDK |
| [Your First SAP Analytics Cloud Custom Widget – Introduction](https://blogs.sap.com/2020/01/27/your-first-sap-analytics-cloud-custom-widget-introduction/) (2020) | Series with a template project |
| [Announcing Custom Widgets Data Binding](https://community.sap.com/t5/technology-blog-posts-by-sap/announcing-custom-widgets-data-binding-in-sap-analytics-cloud-analytics/ba-p/13525014) | Builder-panel binding replaces the hidden-table workaround |
| ★ 📖 [Custom Widget Hands-on Guide](https://community.sap.com/t5/technology-blog-posts-by-sap/sap-analytics-cloud-custom-widget-hands-on-guide/ba-p/13573631) (2023) | 9 chapters: web component → lifecycle → data binding → ECharts → events → custom types → styling panel → integrity |
| ★ 📖 [Hosting and Uploading Custom Widget Resource Files into SAC](https://community.sap.com/t5/technology-blog-posts-by-sap/hosting-and-uploading-custom-widgets-resource-files-into-sap-analytics/ba-p/13563064) (2023) | SAC hosting with demo video (limits quoted there are the 2023 ones) |
| ★ 📖 [How to use Linked Analysis with Custom Widget](https://community.sap.com/t5/technology-blogs-by-sap/how-to-use-linked-analysis-with-custom-widget/ba-p/13574388) (2023) | The three scenarios, `setFilters`/`removeFilters` samples |
| 📖 [Custom Widget & Widget Add-Ons Samples Preview](https://community.sap.com/t5/technology-blog-posts-by-sap/sap-analytics-cloud-custom-widget-amp-widget-add-ons-samples-preview/ba-p/13585313) | Gallery of SAP samples (gauge, pareto, funnel, nested pie, word cloud, datepicker, add-ons) |
| [Announcing the Widget Add-On](https://community.sap.com/t5/technology-blog-posts-by-sap/announcing-the-new-sap-analytics-cloud-feature-widget-add-on/ba-p/13575788) (Q4 2023) | Add-on JSON, hosting, demo |
| 📖 [Development experience sharing for SAC Widget Add-On](https://blogs.sap.com/t5/technology-blogs-by-sap/development-experience-sharing-for-sac-widget-add-on/ba-p/13629330) | How add-ons get chart information, `sapHide…` properties, richer sample package |
| [Sneak peek into the Q4 2023 release](https://blogs.sap.com/2023/10/16/sneak-peek-into-sap-analytics-cloud-release-for-q4-2023/) | Add-on types and supported charts; composites |
| [SAC Custom Widget – New free learning journey](https://groups.community.sap.com/t5/technology-blogs-by-sap/sap-analytics-cloud-custom-widget-new-free-learning-journey/ba-p/13578691) | Announcement of the learning content |
| ★ 📖 [Introducing the SAC Custom Widget Library](https://community.sap.com/t5/data-professionals-blog-posts/introducing-the-sap-analytics-cloud-custom-widget-library/ba-p/14455069) | SAP-built widget catalogue (18 chart types, D3/ECharts, with HCLTech). Currently for SAP Business Data Cloud tenants only; published as samples; comments include SAP Note 3798532 (missing *Explore custom charts*) |
| [Introducing the SAC Custom Widget Library (earlier post)](https://community.sap.com/t5/data-and-analytics-blog-posts/introducing-the-sap-analytics-cloud-custom-widget-library/ba-p/14398681) | Admin upload under *Administration → Custom Widgets* |
| [SAC Highlight: Composite](https://community.sap.com/t5/technology-blogs-by-sap/sap-analytics-cloud-highlight-composite/ba-p/13579369) (Q4 2023) | Reusable widget groups, transport |
| [Composite data source configuration](https://blogs.sap.com/t5/technology-blogs-by-sap/composite-data-source-configuration-in-optimized-story-experience/ba-p/13678967) | Remap a composite's models per story |
| [Extending SAC's visualization capability with Matplotlib (Pyodide)](https://groups.community.sap.com/t5/technology-blogs-by-sap/extending-sap-analytics-cloud-s-visualization-capability-with-matplotlib/bc-p/13569489) | Python in the browser as a custom widget 🛠 |
| [File Upload Widget with React](https://community.sap.com/t5/technology-blog-posts-by-sap/file-upload-widget-how-to-develop-custom-widgets-with-the-react-framework/ba-p/13572666) | React dev server, Data Import API |
| [Upload data to a planning version with the File Upload Widget](https://community.sap.com/t5/technology-blog-posts-by-sap/how-to-upload-data-to-a-public-or-private-planning-version-using-a-file/ba-p/13576559) | Now end-of-life; native End User File Upload since QRC3 2024 |
| [Feature highlight: Linked Analysis](https://blogs.sap.com/2018/09/24/sap-analytics-cloud-feature-highlight-linked-analysis/) (2018) | Linked analysis basics for standard widgets |

## 4. SAP Community: member blogs

| Post | Notes |
|---|---|
| [Build a Custom Widget in SAC Analytics Application](https://blogs.sap.com/2019/12/06/build-a-custom-widget-in-sap-analytics-cloud-analytics-application/) (Ferry Djaja, 2019) | Gauge tutorial plus a long list of demos: amCharts, Highcharts, FusionCharts, maps, Kafka/RabbitMQ, chat bot, Zoom |
| [Transforming SAC with Custom Widgets, Part 4: Data Binding](https://blogs.sap.com/2023/06/22/transforming-sac-with-custom-widgets-part-4-custom-widgets-data-binding/) (Planifyit, 2023) | D3 pie with binding; notes a builder-panel + binding limitation 🛠 |
| [Gantt Chart Widget with Data Binding](https://community.sap.com/t5/technology-blogs-by-members/gantt-chart-widget-with-data-binding-for-sap-analytics-cloud/ba-p/13562173) (Planifyit) | DHTMLX Gantt 🛠 |
| [Custom Widgets – Increased flexibility for Reporting and Planning](https://community.sap.com/t5/technology-blog-posts-by-members/custom-widgets-in-sap-analytics-cloud-increased-flexibility-for-reporting/ba-p/14132680) | Authorisations, packaging, limits (50 per tenant) |
| [Bringing ChatGPT into SAC using a Custom Widget](https://community.sap.com/t5/technology-blogs-by-members/bringing-chatgpt-in-sap-analytics-cloud-using-custom-widget/ba-p/13567616) | OpenAI API from a widget 🛠 |
| [Data discovery using ChatGPT in SAC](https://blogs.sap.com/2023/09/04/data-discovery-using-chatgpt-in-sap-analytics-cloud/) | Part 2: model data to the LLM |
| [Building a GenAI-powered dashboard in SAC](https://community.sap.com/t5/technology-blogs-by-members/building-genai-powered-dashboard-in-sap-analytics-cloud/ba-p/13581497) | Function calling, embeddings, Pinecone, three widgets |
| [ChatGPT Custom Widget](https://blogs.sap.com/2023/03/09/chatgpt-custom-widget-enhance-your-sap-analytics-cloud-experience-with-the-chatgpt-custom-widget/) (Rohit Chouhan) | Ready-made widget 🛠 |
| [Leveraging ChatGPT to create custom widgets](https://blogs.sap.com/2023/04/18/leveraging-chatgpt-to-create-custom-widgets-for-sap-analytics-cloud/) | AI-assisted widget development tips |
| 📖 [Unsupported Features with SAP Datasphere Live Connections in SAC](https://community.sap.com/t5/technology-blog-posts-by-members/unsupported-features-with-sap-datasphere-live-connections-in-sap-analytics/ba-p/14228053) | Readable summary of Note 2832606 |

## 5. Datasphere modelling (for [07](07_Datasphere_Analytic_Model_Recipes.md))

| Post | Notes |
|---|---|
| [Introducing the Analytic Model in SAP Datasphere](https://blogs.sap.com/2023/03/13/introducing-the-analytic-model-in-sap-datasphere) | Overview of the series |
| [Analytic Model Series: Motivation, comparison with the analytical dataset](https://blogs.sap.com/2023/03/28/sap-datasphere-analytic-model-series-motivation-comparison-with-the-analytical-dataset/) | Terminology aligned with SAC |
| [Analytic Model Series: Calculated and Restricted Measures](https://blogs.sap.com/t5/technology-blogs-by-sap/sap-datasphere-analytic-model-series-calculated-and-restricted-measures/ba-p/13563628) | Account model → measure model with restricted measures |
| [Analytic Model Series: User experience and navigation](https://blogs.sap.com/2023/05/09/sap-datasphere-analytic-model-series-user-experience-and-navigation-paradigm/) | Measures, variables, filters in the editor |
| 📖 [Running Year to Date (YTD) on fiscal periods with SAP Datasphere](https://community.sap.com/t5/technology-blogs-by-sap/running-year-to-date-ytd-on-fiscal-periods-with-sap-datasphere/ba-p/13580611) | Window function vs helper table; SAC time functions and fiscal calendars on Datasphere |
| [Date calculations WTD/MTD/YTD in SAC using a DWC live connection](https://blogs.sap.com/2021/12/12/date-calculations-wtd-mtd-ytd-in-sac-using-sap-data-warehouse-cloud-live-connection/) | Date table with period flags |
| Q&A: 📖 [Function YTD not working in Datasphere](https://community.sap.com/t5/technology-q-a/function-ytd-not-working-in-datasphere/qaq-p/14441990) | Points to the documented `YTD()` function and its pitfalls |
| Q&A: [SAC compatibility with SAP Datasphere](https://community.sap.com/t5/technology-q-a/sap-analytics-cloud-compatibility-with-sap-datasphere/qaq-p/14063705) | Feature support on analytic models |
| LinkedIn post *"MTD, YTD, prior year. All dynamic, all from a clean persisted fact view"* ([found here](https://mx.linkedin.com/in/alfonsohguerra)) summarising Do Hai Dang Le's SAP Community post | Restriction variables + parameter view + closing-calendar defaults, fact view stays persisted |
| [Live connection in SAC: advantages and challenges](https://nextlytics.com/blog/live-connection-in-sap-analytics-cloud-advantages-and-challenges) (NextLytics, 2024) | Datasphere and BW live restrictions |
| [SAC story on SAP Datasphere](https://www.zpartner.eu/?p=10768) (Z_Partner) | DW Consumer role, exposure for consumption |

## 6. Linked analysis and filters

| Resource | Notes |
|---|---|
| [Three filter options in SAC stories and one alternative](https://www.nextlytics.com/blog/three-filter-options-in-sac-story-and-one-alternative) | Widget, page, story filters vs linked analysis |
| Q&A: [Linked analysis, input controls and widgets](https://community.sap.com/t5/technology-q-a/sac-linked-analysis-input-controls-and-widgets/qaq-p/13999013) | Sync input controls from a widget selection by script |
| Q&A: [Linked analysis doesn't work when filtering](https://community.sap.com/t5/technology-q-a/linked-analysis-doesnt-work-when-filtering/qaq-p/12583507) | "Filter on Data Point Selection" checks |

## 7. GitHub

| Repository | Contents |
|---|---|
| ★🛠 [SAP-samples/analytics-cloud-datasphere-community-content](https://github.com/SAP-samples/analytics-cloud-datasphere-community-content) → [`SAC_Custom_Widgets`](https://github.com/SAP-samples/analytics-cloud-datasphere-community-content/tree/main/SAC_Custom_Widgets) | SAP's sample widgets (funnel, pareto, sankey, sunburst, tree, line, UI5 Gantt, KPI ring, gauge, half donut, nested pie, word cloud, file upload, add-on sample); [release with all widgets as one ZIP](https://github.com/SAP-samples/analytics-cloud-datasphere-community-content/releases/tag/CustomWidgets) |
| 🛠 [SAP-samples/analytics-cloud-custom-widget](https://github.com/SAP-samples/analytics-cloud-custom-widget) | Further SAP samples (listed in public repository indexes) |
| 🛠 [SAC-P Custom Widget org (sap-custom-widget)](https://github.com/sap-custom-widget) | ChatGPT, circle progress bar, notifications, image, CacheBuddy, star rating, document viewer, currency |
| 🛠 [Planifyit](https://github.com/Planifyit) | Pie, Gantt, calculator, cockpit widgets from the "Transforming SAC" series |
| 🛠 [rohit-chouhan/sapwidget](https://github.com/rohit-chouhan/sapwidget) | Community widget collection |
| 🛠 [WolfgangZeller/sac-custom-widgets](https://github.com/WolfgangZeller/sac-custom-widgets) | Community widgets |
| 🛠 [SAC-Custom-Widgets/datepicker](https://github.com/SAC-Custom-Widgets/datepicker) | Date and range picker |
| 🛠 [pawelwiejkut/sac_event_calendar](https://github.com/pawelwiejkut/sac_event_calendar) | Event calendar widget |
| [secondsky/sap-skills](https://github.com/secondsky/sap-skills) | AI-assistant skill notes on SAC widgets, scripting and Datasphere (GPL-3.0): useful pointers, verify against SAP docs |

### 7.1 More repositories found on GitHub (November 2026)

| Repository | What's in it | Licence |
|---|---|---|
| 🛠 [adembaykal/sac-custom-widgets](https://github.com/adembaykal/sac-custom-widgets) | Community collection, actively maintained: **Hierarchy Pulse** (BW hierarchy variance tree, the LinkedIn post in §10), **Executive Pulse** (KPI variance narrative + contributor ranking), **WHY** (variance signal analysis), **Hierarchy SHIFT** (what-if restructuring with Excel export), Impact Ripple, Performance Skyline, Discovery, Unfold; each with README, changelog and test checklist | MIT |
| 🛠 [Marou-Fer/Black-Belt-Workshop-for-Partner---Materials](https://github.com/Marou-Fer/Black-Belt-Workshop-for-Partner---Materials) | SAP partner workshop by the author of the hands-on guide: a custom widget exercise (CWM) and a widget add-on exercise with tooltip + plot area (WAM), each with starting files and solution | not stated |
| 🛠 [SAP-archive/analytics-cloud-custom-widget](https://github.com/SAP-archive/analytics-cloud-custom-widget) | The hands-on guide's step-by-step code (steps 0–9: web component → lifecycle → binding → ECharts → properties → events → custom types → styling panel → integrity). Archived; current samples are in the community-content repo above | Apache-2.0 |
| [SAP-archive/analytics-cloud-creating-custom-widgets-learning-journey](https://github.com/SAP-archive/analytics-cloud-creating-custom-widgets-learning-journey) | Exercise files of the learning journey (archived) | Apache-2.0 |
| 🛠 [davidhstocker/SAC_CustomWidget_StartTemplate](https://github.com/davidhstocker/SAC_CustomWidget_StartTemplate) | Start template and the *Hello World* series (`SAC_CustomWidget_HelloWorld_1…5`) from the original SAP blog series | Apache-2.0 |
| 🛠 belindaxo: [sankey-hierarchy](https://github.com/belindaxo/sankey-hierarchy-custom-widget), [treemap](https://github.com/belindaxo/treemap-custom-widget), [sunburst](https://github.com/belindaxo/sunburst-custom-widget), [heatmap](https://github.com/belindaxo/heatmap-custom-widget), [bubble](https://github.com/belindaxo/bubble-custom-widget), [bar race](https://github.com/belindaxo/bar-race-custom-widget), [3D funnel](https://github.com/belindaxo/3d-funnel-custom-widget) | Data-bound widgets with linked analysis, webpack-built; they use **Highcharts**, which needs a commercial licence for business use | varies |
| [xpr0gamers/vin-sac-addon-traffic-light](https://github.com/xpr0gamers/vin-sac-addon-traffic-light) | TypeScript + Vite **widget add-on** (plot area general) with traffic lights; includes recorded `setExtensionData` payloads as test fixtures and the reserved `sapHide…` properties, the best public reference for the add-on data shape | none (internal project): reference only |
| [dedefelrodrigues/sac-dataexporter-widget](https://github.com/dedefelrodrigues/sac-dataexporter-widget) | Data-bound widget that exports bound data to CSV with configurable delimiters | not stated |
| [Barko29/sac-decomposition-tree-widget-v3](https://github.com/Barko29/sac-decomposition-tree-widget-v3) | Decomposition tree widget (v1–v3 repos) | not stated |
| [SimonLaws/SAC-Header](https://github.com/SimonLaws/SAC-Header) | Header widget that implements `serializeCustomWidgetToImage` for export | not stated |
| [jimu-dev/sac-custom-widget-ui5](https://github.com/jimu-dev/sac-custom-widget-ui5) | Widgets built on UI5 Web Components | not stated |
| [ferrygun](https://github.com/ferrygun) | Ferry Djaja's demo repos (REST API, Zoom, notifications, …) from the 2019–2022 blog posts | varies |
| [SAP-archive/analytics-cloud-export-api-wrapper](https://github.com/SAP-archive/analytics-cloud-export-api-wrapper) | Python wrapper for SAC's OData Data Export API (SAC models, not Datasphere live) | Apache-2.0 |
| [hschuettken/datenroesterei](https://github.com/hschuettken/datenroesterei) | Field notes and tools from productive Datasphere / SAC work | CC-BY-4.0 |

GitHub has no open-source **waterfall/bridge** widget of substance (the one repository named so contains a stub), and
no public widget that writes formatted **XLSX** from SAC data. Both are covered by this kit. Commercial alternative for
bridges: graphomate (§9).

## 8. Videos 🎥

| Video | Topic |
|---|---|
| [How to Build Custom Widgets in SAC](https://www.youtube.com/watch?v=skEz6FJ8GaE) | Architecture and development walkthrough |
| [DV360 Demo #2: Custom Widget with SAC SDK](https://www.youtube.com/watch?v=r4PVpBzRxQU) | SAP demo from a hands-on event |
| [Creating a Custom Widget using a 3rd-party library](https://www.youtube.com/watch?v=hPCCgap53Ao) | Library integration |
| [Custom table / data grid widget](https://www.youtube.com/watch?v=WCkWaXC4UzM) | Grid widget |
| [FormFlex: dynamic forms](https://www.youtube.com/watch?v=kSbA5hlTRjc) | Form builder widget |
| [ChatGPT custom widgets, step by step](https://www.youtube.com/watch?v=bmwkrDsXNTA) | LLM widget |
| [Real-time notification widget](https://www.youtube.com/watch?v=gSaE6xSDEbo) | Push notifications |
| [Highcharts radial bar](https://www.youtube.com/watch?v=d1a1loWQPwI) | Commercial chart library |
| [CacheBuddy](https://www.youtube.com/watch?v=pDWFVYq0QxY) | Client-side cache utility |
| [DelayCode](https://www.youtube.com/watch?v=19nLy50-7wk) | Timer utility with all methods |
| [Google Gauge demo](https://www.youtube.com/watch?v=K98ELHbqB9U) | Early custom widget demo |
| [Sankey diagram widget](https://www.youtube.com/watch?v=NpFv3AAE56I) | Sankey demo (Ferry Djaja) |
| [ASUG webcast: Introduction to Custom Widgets](https://www.asug.com/events/introduction-to-custom-widgets-in-sap-analytics-cloud) (2020) | SDK background and use cases (ASUG membership) |

The hands-on guide, the hosting blog and the add-on announcement (section 3) each embed a demo video as well.

## 9. Partner articles and products

| Resource | Notes |
|---|---|
| [A Comprehensive Guide for Custom Widget in SAC](https://www.accely.com/?p=6671) (Accely, 2023) | Walkthrough following the hands-on guide |
| [SAC – User-centred visualization with custom widgets](https://www.btelligent.com/en/blog/sac-visualization-of-data-with-custom-widgets) (b.telligent) | Structure, Chrome/Edge 79+ requirement, versions |
| [Leveraging SAC through custom widgets](https://www.improving.com/thoughts/leveraging-sap-analytics-cloud-through-custom-widgets/) (Improving) | Short introduction |
| [How to implement a KPI tile with custom widgets](https://www.nextlytics.com/blog/how-to-implement-a-kpi-tile-with-sap-analytics-cloud-custom-widgets) (NextLytics) | Pre-binding era KPI tile |
| [SAC custom widgets, part I](https://trijotech.com/sap-analytics-cloud-sac-custom-widgets-part-1/) (Trijotech) | Basics |
| [graphomate charts for SAC: user manual 2026.1](https://graphomate.atlassian.net/wiki/spaces/CHSACEN/pages/1506934814/User+Manual) | Commercial IBCS charts incl. waterfall calculation path; [installation](https://graphomate.atlassian.net/wiki/x/LwDAQ) |
| [Apache ECharts option reference](https://echarts.apache.org/en/option.html) | For the Universal Chart's `optionOverride` |

## 10. LinkedIn and social

| Post | Notes |
|---|---|
| [Hierarchy Pulse](https://es.linkedin.com/in/fblarasin) (LinkedIn) | BW hierarchy as an interactive tree with variance colouring; the source is in [adembaykal/sac-custom-widgets](https://github.com/adembaykal/sac-custom-widgets) (MIT) |
| Do Hai Dang Le's MTD/YTD/PY approach (shared by several Datasphere practitioners) | See section 5 |

## 11. Also found (titles and IDs; open via SAP Community search)

These came up during research, but their exact URLs weren't captured. Search the title or the post ID on
community.sap.com:

| Title | SAP Community ID |
|---|---|
| Demystifying Custom Widgets for SAP Analytics Cloud (Pranav Kandpal) | 13566066 |
| Unleashing the Power of Custom Widgets in SAP Analytics Cloud | 13700764 |
| Extending a Sankey custom widget to Top-N hierarchical data | 14295743 |
| Databricks Genie custom widget for SAC | 14491921 |
| Claude Code experiments, part 1 (widget add-on) and part 2 (custom widget) | 14366149, 14371568 |
| Production-ready SAC widget built with Claude AI (decomposition tree) | 14381628 |
| Transforming SAC with Custom Widgets, parts 1–3 (incl. "Gamify" and a calculator with styling/builder panels) | linked from the part 4 post |
| Best practices for CSV/Excel export performance (2021) | — |
| Ferry Djaja: Google Gauge with an RGB LED (Web Bluetooth) | — |

Other KBAs that appeared in searches on Excel export and the add-in: 3102519 (saving an SAC-exported Excel file),
3757480, 3758682, 3803111, 3767945, 3778463, 3830516, 3467382 (titles not captured; check relevance in the SAP
support portal).

Next: [09 — Beyond Native: Visuals, Cards and Features](09_Beyond_Native_Visuals_Cards_and_Features.md)
