# 06 — Deployment, Testing and Troubleshooting

From source to a widget in a production story: build, upload (SAC-hosted or external), local testing with the
harness, automated tests, a proof-of-concept checklist for your tenant (Datasphere live), updating, and a
troubleshooting table.

---

## 1. Prerequisites

| Task | Needs |
|---|---|
| Build | Python 3.9+ (standard library only) |
| Local harness | Any static web server (e.g. `python3 -m http.server`) and Chrome or Edge |
| Automated tests | Node.js 18+ and Playwright with Chromium (`npm i -D playwright && npx playwright install chromium`) |
| Upload | SAC user with **Create** permission on *Custom Widget* (and *Widget Add-On* for add-ons) |
| External hosting (optional) | HTTPS host with CORS for your SAC origin |

---

## 2. Build

```bash
python3 tools/build.py                                   # all widgets → dist/
python3 tools/build.py --only waterfall-bridge           # one widget
python3 tools/build.py --base-url https://cdn.example.com/sac/waterfall-bridge --only waterfall-bridge
python3 tools/gen_reference.py                           # refresh docs/reference/*.md after spec changes
```

Per widget, `dist/<widget>/` contains:

| File | Use |
|---|---|
| `<widget>.json` | Upload JSON for SAC-hosted resources, development (`ignoreIntegrity: true`) |
| `<widget>.prod.json` | Same with SHA-256 integrity hashes (`ignoreIntegrity: false`): **use this in QA and production** |
| `<widget>.external.json` | For external hosting: absolute URLs from `--base-url` (placeholder host otherwise) + hashes |
| `<widget>.js`, `<widget>-styling.js` | The web components |
| `<widget>-resources.zip` | Flat ZIP of the JS files for *SAC-hosted* upload (the build fails if it would exceed 10 MB) |

The build validates the JSON (allowed root keys, property/method fields, lowercase hyphenated tags) before writing.

---

## 3. Upload to SAC (SAC-hosted resources)

1. **Stories** (side navigation) → **Custom Widgets** tab (older releases: *Analytic Applications → Custom
   Widgets*). Choose **+ / Create**.
2. Select `dist/<widget>/<widget>.prod.json`.
3. In the same dialog choose **Select File** for the resources and pick `dist/<widget>/<widget>-resources.zip`.
4. **OK**. The widget appears in the list with its version.
5. In an Optimized Story Experience story: **Insert → Custom Widgets → <name>**. Bind data in the Builder panel,
   configure it in the Styling panel.

Repeat for each widget you need: they are independent (separate IDs, tags and bundles).

### Updating

Rebuild, then upload the new JSON **and** ZIP the same way. Same `id` and same major version → it replaces the
existing one; stories pick up the new version on next load (hard-reload the browser if you still see the old code).
For breaking changes raise the major version and change the tag (see [01 §9.4](01_Custom_Widget_Master_Guide.md#94-versions)).

### Removing

Delete the widget in the *Custom Widgets* list. Stories that still use it show an empty placeholder. Check where it is
used first.

---

## 4. External hosting

1. `python3 tools/build.py --only <widget> --base-url https://<host>/<path>/<widget>`
2. Copy `<widget>.js` and `<widget>-styling.js` to that URL path.
3. Configure the host to send `Access-Control-Allow-Origin: https://<your-tenant>.sapanalytics.cloud` (or the
   exact SAC origin) for these files, and serve them over HTTPS with a JavaScript content type.
4. Upload only `<widget>.external.json` to SAC (no ZIP).
5. Every user's browser must be able to reach the host (corporate proxy, VPN, firewall).

Integrity hashes are in the JSON, so changing a JS file on the server without uploading the new JSON makes the widget
fail to load. That's intended: it protects you from a tampered file.

---

## 5. Local testing with the harness

```bash
cd sac-kit
python3 -m http.server 8765 --bind 127.0.0.1
# open http://127.0.0.1:8765/tools/harness/index.html
```

The harness (`tools/harness/sac-host.js`) emulates what SAC does:

- loads `dist/<widget>/<widget>.json`, the main and the styling component;
- calls `onCustomWidgetBeforeUpdate/AfterUpdate` with the defaults, then a `state: "loading"` binding, then the
  selected sample result set (switchable at runtime; `loading` and `empty` samples test those states);
- provides `this.dataBindings.getDataBinding()` with `getDataSource()` and `getLinkedAnalysis()`, and logs every
  `setFilters` / `removeFilters` call;
- runs the JSON **method bodies** against a proxy of the widget (so `exportChart("xlsx", …)` behaves as in SAC);
- logs events and `propertiesChanged`;
- shows the generated Styling panel, wired both ways;
- resizes the widget.

URL parameters:

| Parameter | Example | Meaning |
|---|---|---|
| `widget` | `waterfall-bridge`, `export-table`, `universal-chart`, `kpi-card`, `member-selector`, `starter-template` | Which widget |
| `dataset` | `pnl_hierarchy`, `variance_region`, `pvm_measures`, `cash_bridge`, `product_region`, `costcenter_hierarchy`, `monthly_series`, `loading`, `empty` | Sample result set from `samples/datasets.js` |
| `props` | `{"bridgeMode":"variance","topN":6}` (URL-encoded JSON) | Property overrides |
| `w`, `h` | `900`, `460` | Widget size in px |

To test with your own data shape, copy a result set from the tenant (DevTools: `copy(JSON.stringify($0._props.dataBinding))`
on the selected widget element) into `samples/datasets.js`.

---

## 6. Automated tests

```bash
python3 -m http.server 8765 --bind 127.0.0.1 &          # harness must be served
node tools/test/test-waterfall.mjs
node tools/test/test-table.mjs
node tools/test/test-universal.mjs
node tools/test/test-small-widgets.mjs
# optional: HARNESS=http://host:port/tools/harness/index.html OUT=/tmp/shots node tools/test/test-table.mjs
```

| Suite | Checks | Covers |
|---|---|---|
| `test-waterfall.mjs` | 34 | Auto subtotals, end bar, favourability, linked-analysis calls (unique names, arrays for multi-select and "Others"), clearing, disabled data-point selection, variance start/end, Top N, sorting, axis zoom, auto scale, PVM residual, cash opening/closing, leaves-only, Styling panel round trip, XLSX/PNG/CSV/SVG exports, script methods, empty state, render-complete event, `serializeCustomWidgetToImage()` for story export, command properties excluded from bookmarks, no page errors |
| `test-table.mjs` | 22 | Flat and tree rendering, totals without double counting, tuple selection, multi-select, clear, sort persistence, search, expand/collapse, XLSX/CSV/TSV exports, `onExported`, loading state, no page errors |
| `test-universal.mjs` | 28 | All 20 chart types render, column click → linked analysis + `onSelect`, `setChartType` + `optionOverride` deep merge, PNG and XLSX export, `serializeCustomWidgetToImage()`, no global `echarts` leak, no page errors |
| `test-small-widgets.mjs` | 15 | KPI card value/ratio/status, `getStatus()`, sparkline → linked analysis, thresholds; member selector single and multi selection, `getSelectedMembers()`, `setSelectedMembers()`, "All" → `removeFilters`, persisted selection re-applied on load; starter template click/method/styling panel and a result set without `state`; no page errors |

Screenshots go to `/tmp/sac-tests` (or `OUT`).

---

## 7. Proof of concept in your tenant (Datasphere analytic model)

Run this once per tenant/release before rolling the widgets out. Use a small test story on the real analytic model.

| # | Check | How | Pass when |
|---|---|---|---|
| 1 | Upload | `.prod.json` + ZIP | Widget listed with version 1.0.0 |
| 2 | Binding on the analytic model | Insert widget, bind a dimension and two measures | Widget renders; no console errors |
| 3 | Result shape | DevTools: `$0._props.dataBinding.metadata` | Dimension and measure IDs as expected; note them for scripts and the add-in |
| 4 | Hierarchy | Bind the FS item / account hierarchy | Rows carry `parentId`; the bridge shows subtotals; the table shows a tree |
| 5 | Variables | Story with the analytic model's variables (e.g. reporting period) | Changing the variable refreshes the widget |
| 6 | Filters | Story/page filters and input controls | Widget follows them |
| 7 | Linked analysis as target | Chart on the same model as source | Widget is filtered |
| 8 | Linked analysis as source | Settings → *Filter on Data Point Selection* | Table on the same model is filtered by a click in the widget; cleared by Esc/background click |
| 9 | Script API | Button: `WaterfallBridge_1.exportChart("xlsx","Test")`, `getDataSource().getMembers(...)` | File downloads; members returned |
| 10 | Bookmarks | Select, sort, save bookmark, reopen | State restored |
| 11 | Story export | PDF / PowerPoint export | Widget is in the file |
| 12 | Viewport loading | Long story, widget below the fold | Loads when scrolled into view |
| 13 | Mobile | SAC mobile app | Renders, tap selects |
| 14 | Performance | Realistic filters and row counts | Interaction < 2–3 s; result set size acceptable |
| 15 | Transport | Export/import widget + story to QA | Works in QA |

Items 2–5 are the ones to do first on Datasphere: SAP's custom widget documentation doesn't call out Datasphere
analytic models specifically, so confirm the binding on your tenant before you design a story around it.

---

## 8. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Upload: "invalid JSON" or no error but nothing appears | Unknown root key, wrong type/default, uppercase or non-hyphenated tag, duplicate `id` with another widget | Rebuild with `tools/build.py` (validates); keep IDs unique |
| Upload: ZIP rejected | ZIP > 10 MB, subfolders, or file types the upload doesn't accept | Use the kit ZIP (flat, JS only) |
| Widget not in the Insert menu | Missing *Read* permission; story in classic mode | Role with Custom Widget read; use Optimized Story Experience |
| "Failed to load the custom widget" | Integrity mismatch (JS changed, JSON not), wrong URL, CORS (external), blocked host | Upload matching JSON + ZIP together; for external hosting check CORS and reachability in DevTools *Network* |
| Widget area stays empty | JavaScript error | DevTools *Console*; typical: library expecting a global, `customElements.define` called twice |
| "Builder panel → add a dimension…" | Nothing bound or binding still loading | Bind in the Builder panel; check the model and variables |
| Numbers look wrong by 1,000× | Scale property vs model scale; `useSacFormatting` | Set `scale` explicitly (`M`) or use SAC formatting |
| All bars red/green the wrong way | Sign convention | `increaseIsGood` / `invertedMembers` (see [04 §4](04_Waterfall_and_Bridge_Guide.md#4-favourable-and-unfavourable)) |
| No subtotals in the P&L bridge | Hierarchy not active on the dimension, or non-additive parents | Activate the hierarchy in the Builder panel; check `hierarchyMode`; use `totalMembers` |
| Linked analysis does nothing | See the checklist in [02 §8](02_Linked_Analysis_Cookbook.md#8-pitfalls-and-checks) | |
| Export button does nothing | Browser blocked the download | Allow downloads for the SAC site; try `exportChart("csv", …)` |
| Excel opens the file with numbers as text | A CSV opened with the wrong delimiter | Use XLSX, or set `csvDelimiter` to your Excel list separator |
| Bookmark doesn't restore the selection | `supportsBookmark` missing in the uploaded JSON, or old version on the tenant | Upload the current JSON; selection properties are bookmarkable by default |
| PDF export shows an empty box or misses axes | Widget hadn't finished rendering (export waits up to 1 minute for `customWidgetRenderComplete`), export flag missing, or the default capture can't copy the content (D3 axes, CSS) | Keep `supportsExport: true`; fire `customWidgetRenderComplete`; implement `serializeCustomWidgetToImage()` (bridge and chart do) |
| Story opens in the full viewer instead of the Lite Viewer | A widget in the story lacks `supportsLWV: true` | See [01 §8.5](01_Custom_Widget_Master_Guide.md#85-mobile-and-lite-viewer); enable after measuring |
| Widget shows "no data" in the tenant, works in the harness | Code requires `state === "success"`; the documented result set has no `state` | Treat a binding with a `data` array as loaded (the kit does) |
| Upload: ZIP rejected although small | CSS/HTML files or subfolders in the ZIP; icon not PNG/JPG | Only JS files and a PNG/JPG icon, flat |
| Styling panel empty | Styling component failed to load (tag mismatch, JS error) | Check *Console*; re-upload JSON + ZIP |
| ECharts chart blank after page switch | Container had size 0 when it was drawn | The widget redraws on resize; resize the widget or switch page again. Custom code: call `chart.resize()` in `onCustomWidgetResize` |
| Slow story | Too many rows bound; many widgets loading at once | Bind fewer members (Top N, filters), use viewport loading, persist the Datasphere views behind the analytic model |

When you report an issue to SAP, include the browser console log and the SAC version; for custom widgets, SAP
support covers the framework, not your widget's code.

Next: [07 — Datasphere Analytic Model Recipes](07_Datasphere_Analytic_Model_Recipes.md)
