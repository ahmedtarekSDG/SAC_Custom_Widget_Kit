# Third-party notices

## Apache ECharts 5.6.0

- Used by: `universal-chart` (bundled into `dist/universal-chart/universal-chart.js`)
- Copyright 2017-2024 The Apache Software Foundation
- License: Apache License 2.0, full text in [`vendor/echarts/LICENSE`](vendor/echarts/LICENSE)
- NOTICE: [`vendor/echarts/NOTICE`](vendor/echarts/NOTICE)

```
Apache ECharts
Copyright 2017-2024 The Apache Software Foundation

This product includes software developed at
The Apache Software Foundation (https://www.apache.org/).
```

The bundle keeps the library's own licence header and adds a notice line at the top of the file. SAC's resource
ZIP only accepts JavaScript and images, so the licence text is not inside the ZIP; keep this file and
`vendor/echarts/` with any copy of the kit you distribute.

## Kit code

All other code in this kit (`src/`, `tools/`, `samples/`) is original and provided under the MIT licence, as stated
in each widget's JSON (`"license": "MIT"`). No other third-party code is bundled: the XLSX writer, the styling panel
and the SVG widgets have no dependencies.
