/* ==========================================================================
 * KPI Card — SAP Analytics Cloud custom widget (main web component)
 * Injected by build: WIDGET_TAG, WIDGET_NAME, WIDGET_VERSION, PROPS_DEFAULTS; uses SacKit
 * ========================================================================== */
const BINDING_ID = "dataBinding";
const NON_RENDER_KEYS = new Set(["currentValue", "currentStatus", "currentRatio", "selectedMemberId", "widgetName"]);

const STYLE = `
:host { display:block; width:100%; height:100%; position:relative; overflow:hidden; }
* { box-sizing:border-box; }
.card { position:absolute; inset:0; display:flex; flex-direction:column; padding:12px 14px 10px 18px; overflow:hidden; cursor:pointer; }
.stripe { position:absolute; left:0; top:0; bottom:0; width:6px; }
.title { font-size:13px; opacity:.8; font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.value { font-weight:700; line-height:1.15; margin-top:4px; white-space:nowrap; }
.row { display:flex; align-items:center; gap:8px; margin-top:6px; flex-wrap:wrap; font-size:12px; }
.pill { border-radius:999px; padding:2px 8px; font-weight:700; color:#fff; font-size:12px; white-space:nowrap; }
.cmp { opacity:.75; white-space:nowrap; }
.prog { height:6px; border-radius:3px; background:#E9ECEF; margin-top:8px; overflow:hidden; position:relative; }
.prog i { position:absolute; left:0; top:0; bottom:0; border-radius:3px; }
.prog b { position:absolute; top:-2px; bottom:-2px; width:2px; background:#1D2D3E; opacity:.6; }
.spark { flex:1 1 auto; min-height:24px; margin-top:8px; }
.spark svg { width:100%; height:100%; display:block; overflow:visible; }
.spark .pt { cursor:pointer; }
.msg { position:absolute; inset:0; display:none; align-items:center; justify-content:center; text-align:center; padding:12px; font-size:12px; opacity:.75; }
.msg.on { display:flex; }
`;
const template = document.createElement("template");
template.innerHTML = `<style>${STYLE}</style><div class="card" role="group"><div class="stripe"></div><div class="title"></div><div class="value"></div><div class="row"><span class="pill"></span><span class="cmp"></span></div><div class="prog"><i></i><b></b></div><div class="spark"></div></div><div class="msg"></div>`;

class KpiCard extends HTMLElement {
  constructor() {
    super();
    this._shadow = this.attachShadow({ mode: "open" });
    this._shadow.appendChild(template.content.cloneNode(true));
    const $ = (s) => this._shadow.querySelector(s);
    this._el = { card: $(".card"), stripe: $(".stripe"), title: $(".title"), value: $(".value"), row: $(".row"), pill: $(".pill"), cmp: $(".cmp"), prog: $(".prog"), bar: $(".prog i"), mark: $(".prog b"), spark: $(".spark"), msg: $(".msg") };
    this._props = Object.assign({}, PROPS_DEFAULTS);
    this._lastStatus = null;
    this._selected = "";
    this._el.card.addEventListener("click", (e) => {
      const pt = e.target.closest(".pt");
      if (pt) {
        e.stopPropagation();
        this._selectPoint(Number(pt.getAttribute("data-i")));
        return;
      }
      SacKit.fireEvent(this, "onClick");
    });
  }
  connectedCallback() {
    if (typeof ResizeObserver !== "undefined" && !this._ro) {
      this._ro = new ResizeObserver(() => this._schedule());
      this._ro.observe(this);
    }
    this._schedule();
  }
  disconnectedCallback() {
    if (this._ro) this._ro.disconnect();
    this._ro = null;
  }
  onCustomWidgetBeforeUpdate(c) {
    this._props = Object.assign(this._props, c || {});
  }
  onCustomWidgetAfterUpdate(c) {
    const keys = Object.keys(c || {});
    if (keys.length && keys.every((k) => NON_RENDER_KEYS.has(k))) return;
    this._schedule();
  }
  onCustomWidgetResize() {
    this._schedule();
  }
  onCustomWidgetDestroy() {
    this.disconnectedCallback();
  }
  _schedule() {
    clearTimeout(this._t);
    this._t = setTimeout(() => this._render(), 0);
  }
  _binding() {
    return this._props[BINDING_ID] || this[BINDING_ID];
  }

  _render() {
    if (!this.isConnected) return;
    const p = this._props;
    const el = this._el;
    el.card.style.fontFamily = p.fontFamily;
    el.card.style.color = p.textColor;
    el.card.style.background = p.backgroundColor;
    el.card.style.borderRadius = `${p.borderRadius}px`;
    const parsed = SacKit.parseDataBinding(this._binding());
    this._parsed = parsed;
    if (parsed.state !== "success" || !parsed.measures.length) {
      el.card.style.visibility = "hidden";
      el.msg.textContent = parsed.state === "loading" ? "Loading…" : "Bind one or two measures (optional: a trend dimension such as Month).";
      el.msg.classList.add("on");
      SacKit.renderComplete(this);
      return;
    }
    el.card.style.visibility = "visible";
    el.msg.classList.remove("on");
    const ms = parsed.measures;
    const ci = Math.max(0, Math.min(ms.length - 1, p.compareIndex | 0));
    const hasCmp = ms.length > 1 && ci !== 0;
    const series = parsed.rows.map((r) => ({ id: r.dims[0] ? r.dims[0].id : "", label: r.dims[0] ? r.dims[0].label : "", v: r.values[0].raw, c: hasCmp ? r.values[ci].raw : null }));
    const agg = (key) => {
      const vals = series.map((s) => s[key]).filter((v) => v != null);
      if (!vals.length) return null;
      if (p.valueMode === "last") return vals[vals.length - 1];
      const sum = vals.reduce((a, b) => a + b, 0);
      return p.valueMode === "average" ? sum / vals.length : sum;
    };
    const value = agg("v");
    const cmp = hasCmp ? agg("c") : null;
    const fmt = {
      scale: !p.scale || p.scale === "auto" ? SacKit.autoScaleFor([value, cmp].filter((x) => x != null)) : p.scale,
      decimals: p.decimals,
      prefix: p.prefix,
      suffix: p.suffix,
      locale: p.locale,
      symbols: SacKit.parseSymbols(p.scaleSymbols),
    };
    el.title.textContent = p.kpiTitle || ms[0].label;
    el.value.textContent = SacKit.formatNumber(value, fmt);
    el.value.style.fontSize = `${p.valueFontSize}px`;
    // status
    const ratio = cmp ? value / cmp : null;
    const th = SacKit.parseList(p.thresholds).map(Number).filter((x) => isFinite(x));
    const amber = (th[0] != null ? th[0] : 95) / 100;
    const green = (th[1] != null ? th[1] : 100) / 100;
    let status = "neutral";
    if (ratio != null) {
      const r = p.increaseIsGood ? ratio : ratio ? 1 / ratio : 0;
      status = r >= green ? "good" : r >= amber ? "warning" : "bad";
    }
    const color = { good: p.goodColor, warning: p.warnColor, bad: p.badColor, neutral: p.accentColor }[status];
    el.stripe.style.background = color;
    el.stripe.style.display = p.showStatusStripe ? "block" : "none";
    // variance pill
    const delta = cmp != null ? value - cmp : null;
    const showRow = hasCmp && p.deltaMode !== "none";
    el.row.style.display = showRow ? "flex" : "none";
    if (showRow) {
      const parts = [];
      const arrow = delta > 0 ? "▲" : delta < 0 ? "▼" : "■";
      const dScale = !p.scale || p.scale === "auto" ? SacKit.autoScaleFor([delta]) : p.scale;
      if (p.deltaMode === "abs" || p.deltaMode === "both") parts.push(SacKit.formatNumber(delta, Object.assign({}, fmt, { scale: dScale, plusSign: true })));
      if ((p.deltaMode === "pct" || p.deltaMode === "both") && cmp) parts.push(SacKit.formatNumber(delta / Math.abs(cmp), { percent: true, decimals: 1, plusSign: true, locale: p.locale }));
      el.pill.textContent = `${arrow} ${parts.join(" · ")}`;
      el.pill.style.background = color;
      el.cmp.textContent = `${p.compareLabel || `vs ${ms[ci].label}`} ${SacKit.formatNumber(cmp, fmt)}`;
    }
    // progress
    el.prog.style.display = p.showProgress && ratio != null ? "block" : "none";
    if (ratio != null) {
      const max = Math.max(1.2, ratio * 1.05);
      el.bar.style.width = `${Math.max(0, Math.min(100, (ratio / max) * 100))}%`;
      el.bar.style.background = color;
      el.mark.style.left = `${(1 / max) * 100}%`;
    }
    // sparkline
    const sparkOn = p.showSparkline && parsed.dims.length > 0 && series.length > 1;
    el.spark.style.display = sparkOn ? "block" : "none";
    if (sparkOn) this._spark(series, color, fmt);
    else el.spark.innerHTML = "";
    // outputs (only when changed — avoids update loops)
    const out = { currentValue: value == null ? 0 : value, currentStatus: status, currentRatio: ratio == null ? 0 : ratio };
    if (out.currentValue !== p.currentValue || out.currentStatus !== p.currentStatus || out.currentRatio !== p.currentRatio) {
      Object.assign(this._props, out);
      SacKit.dispatchProps(this, out);
    }
    if (this._lastStatus !== null && this._lastStatus !== status) SacKit.fireEvent(this, "onStatusChange");
    this._lastStatus = status;
    this._el.card.setAttribute("aria-label", `${el.title.textContent}: ${el.value.textContent}${showRow ? ", " + el.pill.textContent : ""}`);
    SacKit.renderComplete(this);
  }

  _spark(series, color, fmt) {
    const p = this._props;
    const rect = this._el.spark.getBoundingClientRect();
    const W = Math.max(60, rect.width || 200);
    const H = Math.max(20, rect.height || 40);
    const vals = series.map((s) => s.v).concat(p.showCompareLine ? series.map((s) => s.c) : []).filter((v) => v != null);
    const lo = Math.min(...vals, p.sparkType === "bar" ? 0 : Infinity);
    const hi = Math.max(...vals);
    const n = series.length;
    const x = (i) => (n === 1 ? W / 2 : 4 + (i * (W - 8)) / (n - 1));
    const y = (v) => H - 3 - ((v - lo) / (hi - lo || 1)) * (H - 8);
    const esc = SacKit.escapeHtml;
    let svg = "";
    if (p.sparkType === "bar") {
      const bw = Math.max(2, ((W - 8) / n) * 0.65);
      series.forEach((s, i) => {
        if (s.v == null) return;
        const cx = 4 + ((i + 0.5) * (W - 8)) / n;
        const sel = this._selected && this._selected === s.id;
        svg += `<rect class="pt" data-i="${i}" x="${cx - bw / 2}" y="${y(Math.max(0, s.v))}" width="${bw}" height="${Math.max(1, Math.abs(y(s.v) - y(Math.max(lo, 0))))}" fill="${p.accentColor}" opacity="${this._selected && !sel ? 0.35 : 0.85}"><title>${esc(s.label)}: ${esc(SacKit.formatNumber(s.v, fmt))}</title></rect>`;
      });
    } else {
      const pts = series.map((s, i) => (s.v == null ? null : [x(i), y(s.v)])).filter(Boolean);
      const d = pts.map((q, i) => `${i ? "L" : "M"}${q[0].toFixed(1)},${q[1].toFixed(1)}`).join("");
      if (p.sparkType === "area" && pts.length) svg += `<path d="${d}L${pts[pts.length - 1][0]},${H}L${pts[0][0]},${H}Z" fill="${p.accentColor}" opacity="0.12"/>`;
      svg += `<path d="${d}" fill="none" stroke="${p.accentColor}" stroke-width="2" stroke-linejoin="round"/>`;
      series.forEach((s, i) => {
        if (s.v == null) return;
        const sel = this._selected === s.id;
        svg += `<circle class="pt" data-i="${i}" cx="${x(i)}" cy="${y(s.v)}" r="${sel ? 5 : i === n - 1 ? 3.5 : 6}" fill="${sel || i === n - 1 ? color : "transparent"}" stroke="${sel ? "#1D2D3E" : "none"}"><title>${esc(s.label)}: ${esc(SacKit.formatNumber(s.v, fmt))}</title></circle>`;
      });
    }
    if (p.showCompareLine && series.some((s) => s.c != null)) {
      const d = series
        .map((s, i) => (s.c == null ? null : `${x(i).toFixed(1)},${y(s.c).toFixed(1)}`))
        .filter(Boolean)
        .map((q, i) => `${i ? "L" : "M"}${q}`)
        .join("");
      svg += `<path d="${d}" fill="none" stroke="${p.textColor}" stroke-width="1.2" stroke-dasharray="3 3" opacity="0.5"/>`;
    }
    this._el.spark.innerHTML = `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">${svg}</svg>`;
  }

  async _selectPoint(i) {
    const parsed = this._parsed;
    const r = parsed && parsed.rows[i];
    if (!r || !r.dims[0]) return;
    const id = r.dims[0].id;
    this._selected = this._selected === id ? "" : id;
    this._render();
    const la = SacKit.linkedAnalysis(this, BINDING_ID, this._props);
    if (this._props.enableLinkedAnalysis) {
      if (this._selected) await la.setFilters({ [parsed.dims[0].id]: id });
      else await la.removeFilters();
    }
    SacKit.dispatchProps(this, { selectedMemberId: this._selected });
    SacKit.fireEvent(this, "onSelect");
  }
}
if (!customElements.get(WIDGET_TAG)) customElements.define(WIDGET_TAG, KpiCard);
