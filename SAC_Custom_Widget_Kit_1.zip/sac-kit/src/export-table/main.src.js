/* ==========================================================================
 * Export Table — SAP Analytics Cloud custom widget (main web component)
 * Injected by build: WIDGET_TAG, WIDGET_NAME, WIDGET_VERSION, PROPS_DEFAULTS
 * Uses: SacKit (shared helpers), XlsxLite (xlsx writer)
 * ========================================================================== */
const BINDING_ID = "dataBinding";
const OUTPUT_KEYS = ["selectedMemberId", "selectedMemberLabel", "selectedDimensionId", "selectedRowJson"];
const COMMAND_KEYS = ["exportFormat", "exportRequestFileName", "exportToken", "clearSelectionToken", "expandCommand", "expandToken"];
const NON_RENDER_KEYS = new Set([...OUTPUT_KEYS, ...COMMAND_KEYS, "widgetName"]);
const DENSITY = { compact: 4, cozy: 7, comfortable: 10 };

const STYLE = `
:host { display:block; width:100%; height:100%; position:relative; overflow:hidden; }
* { box-sizing:border-box; }
.wrap { position:absolute; inset:0; display:flex; flex-direction:column; }
.head { display:none; padding:6px 10px 2px; }
.head.on { display:block; }
.title { font-weight:bold; }
.subtitle { opacity:.75; }
.bar { display:flex; align-items:center; gap:6px; padding:6px 8px; flex-wrap:wrap; }
.bar.off { display:none; }
.bar .spacer { flex:1 1 auto; }
.bar input { height:26px; min-width:120px; max-width:240px; flex:0 1 220px; border:1px solid #B0B7BF; border-radius:4px; padding:0 8px; font:inherit; }
.bar input.off { display:none; }
.bar button { font:600 11px/1 Arial,sans-serif; color:#0A6ED1; background:#fff; border:1px solid #BCCEE4; border-radius:4px; padding:6px 8px; cursor:pointer; }
.bar button:hover { background:#EBF5FE; border-color:#0A6ED1; }
.bar button.off { display:none; }
.scroller { flex:1 1 auto; overflow:auto; position:relative; }
table { border-collapse:separate; border-spacing:0; width:100%; min-width:max-content; }
th, td { white-space:nowrap; text-align:right; }
th { font-weight:bold; vertical-align:bottom; cursor:default; user-select:none; }
th.sortable { cursor:pointer; }
th .ind { font-size:10px; margin-left:4px; opacity:.7; }
th.dim, td.dim { text-align:left; }
th.mh { white-space:normal; min-width:70px; max-width:160px; }
tbody tr { cursor:pointer; }
tr.total td { font-weight:bold; cursor:default; }
.tog { display:inline-block; width:14px; text-align:center; cursor:pointer; color:#0A6ED1; margin-right:4px; font-size:10px; }
.tog.leaf { visibility:hidden; }
.pct { display:inline-flex; align-items:center; gap:6px; justify-content:flex-end; }
.mini { display:inline-block; width:46px; height:8px; background:#EEF0F2; position:relative; border-radius:2px; overflow:hidden; }
.mini i { position:absolute; top:0; bottom:0; }
.mini b { position:absolute; left:50%; top:0; bottom:0; width:1px; background:#9AA5B1; }
.msg { position:absolute; inset:0; display:none; align-items:center; justify-content:center; text-align:center; padding:16px; opacity:.8; }
.msg.on { display:flex; }
.toast { position:absolute; right:10px; bottom:10px; background:#1D2D3E; color:#fff; padding:6px 10px; border-radius:4px; font-size:12px; opacity:0; transition:opacity .2s; pointer-events:none; }
.toast.on { opacity:.92; }
`;

const template = document.createElement("template");
template.innerHTML = `<style>${STYLE}</style><style class="dyn"></style>
<div class="wrap">
  <div class="head"><div class="title"></div><div class="subtitle"></div></div>
  <div class="bar">
    <input class="search" type="search" placeholder="Search members…" aria-label="Search members">
    <span class="spacer"></span>
    <button type="button" data-cmd="expand" title="Expand all">Expand</button>
    <button type="button" data-cmd="collapse" title="Collapse to top level">Collapse</button>
    <button type="button" data-export="xlsx" title="Excel workbook with number formats">XLSX</button>
    <button type="button" data-export="csv" title="CSV (raw numbers)">CSV</button>
    <button type="button" data-export="copy" title="Copy visible rows (paste into Excel)">Copy</button>
  </div>
  <div class="scroller"><table role="grid"><thead></thead><tbody></tbody><tfoot></tfoot></table></div>
  <div class="msg"></div>
  <div class="toast" role="status"></div>
</div>`;

function clampIndex(i, n) {
  const k = Number.isFinite(Number(i)) ? Math.floor(Number(i)) : 0;
  return Math.max(0, Math.min(Math.max(0, n - 1), k));
}

// --------------------------------------------------------------------------
// Pure table model (no DOM) — exposed as a static for testing.
// --------------------------------------------------------------------------
function buildTable(parsed, p) {
  const nD = parsed.dims.length;
  const nM = parsed.measures.length;
  if (!nD && !nM) return { error: "Bind dimensions (rows) and measures (columns) in the Builder panel." };
  const isHidden = SacKit.memberMatcher(p.hiddenColumns);
  const isInverted = SacKit.memberMatcher(p.invertedMembers);
  const parentIds = new Set(parsed.rows.map((r) => (r.dims[0] ? r.dims[0].parentId : "")).filter(Boolean));
  const tree = p.hierarchyDisplay !== "flat" && nD === 1 && parentIds.size > 0;
  const nodes = parsed.rows.map((r, i) => ({
    key: r.dims.map((d) => d.id).join("|") || `#${i}`,
    dims: r.dims,
    values: r.values.map((v) => v.raw),
    formatted: r.values.map((v) => v.formatted),
    parentId: r.dims[0] ? r.dims[0].parentId : "",
    children: [],
    depth: 0,
    index: i,
    isNode: !!(r.dims[0] && parentIds.has(r.dims[0].id)),
    selection: SacKit.rowSelection(parsed, r, p.selectionScope === "first" ? 1 : null),
    inverted: r.dims.some((d) => isInverted(d.id, d.label)),
  }));
  let roots = nodes;
  if (tree) {
    const byId = new Map(nodes.map((n) => [n.dims[0].id, n]));
    roots = [];
    nodes.forEach((n) => {
      const par = n.parentId ? byId.get(n.parentId) : null;
      if (par && par !== n) {
        par.children.push(n);
        n.parent = par;
      } else roots.push(n);
    });
    const setDepth = (n, d) => {
      if (d > 64) return;
      n.depth = d;
      n.children.forEach((c) => setDepth(c, d + 1));
    };
    roots.forEach((n) => setDepth(n, 0));
  }
  const cols = [];
  if (tree) cols.push({ type: "dim", key: parsed.dims[0].id, label: parsed.dims[0].label, di: 0 });
  else parsed.dims.forEach((d, di) => cols.push({ type: "dim", key: d.id, label: d.label, di }));
  parsed.measures.forEach((m, mi) => {
    if (!isHidden(m.id, m.label)) cols.push({ type: "measure", key: m.id, label: m.label, mi, unit: m.unit });
  });
  const ai = clampIndex(p.varianceActualIndex, nM);
  const bi = clampIndex(p.varianceBaseIndex, nM);
  const variance = !!p.showVariance && nM >= 2 && ai !== bi;
  if (variance) {
    cols.push({ type: "var", key: "__var", label: p.varianceLabel || "Δ" });
    cols.push({ type: "varpct", key: "__varpct", label: p.variancePctLabel || "Δ %" });
  }
  const varOf = (values, inverted) => {
    const a = values[ai];
    const b = values[bi];
    if (a == null && b == null) return { v: null, pct: null, good: null };
    const v = (a || 0) - (b || 0);
    const pct = b ? v / Math.abs(b) : null;
    let good = v === 0 ? null : v > 0 ? !!p.increaseIsGood : !p.increaseIsGood;
    if (good != null && inverted) good = !good;
    return { v, pct, good };
  };
  if (variance) nodes.forEach((n) => (n.var = varOf(n.values, n.inverted)));
  // grand totals: tree -> roots (parents aggregate children); flat -> leaves only (avoid double counting)
  const totalSource = tree ? roots : nodes.filter((n) => !n.isNode);
  const totals = parsed.measures.map((m, mi) => totalSource.reduce((s, n) => s + (n.values[mi] == null ? 0 : n.values[mi]), 0));
  const totalVar = variance ? varOf(totals, false) : null;
  return { tree, nodes, roots, cols, totals, totalVar, variance, ai, bi, parsed };
}

// --------------------------------------------------------------------------
class ExportTable extends HTMLElement {
  constructor() {
    super();
    this._shadow = this.attachShadow({ mode: "open" });
    this._shadow.appendChild(template.content.cloneNode(true));
    const $ = (s) => this._shadow.querySelector(s);
    this._el = {
      wrap: $(".wrap"),
      dyn: $("style.dyn"),
      head: $(".head"),
      title: $(".title"),
      subtitle: $(".subtitle"),
      bar: $(".bar"),
      search: $(".search"),
      scroller: $(".scroller"),
      thead: $("thead"),
      tbody: $("tbody"),
      tfoot: $("tfoot"),
      msg: $(".msg"),
      toast: $(".toast"),
    };
    this._props = Object.assign({}, PROPS_DEFAULTS);
    this._selected = new Set();
    this._collapsed = new Set();
    this._signature = "";
    this._model = null;
    this._visible = [];
    this._timer = null;
    this._initialized = false;
    this._seen = { exportToken: 0, clearSelectionToken: 0, expandToken: 0 };

    this._el.tbody.addEventListener("click", (e) => this._onBodyClick(e));
    this._el.thead.addEventListener("click", (e) => this._onHeadClick(e));
    this._el.bar.addEventListener("click", (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      if (b.dataset.export) this.exportAs(b.dataset.export);
      if (b.dataset.cmd) this._expandAll(b.dataset.cmd === "expand");
    });
    let t = null;
    this._el.search.addEventListener("input", () => {
      clearTimeout(t);
      t = setTimeout(() => {
        this._props.searchText = this._el.search.value;
        SacKit.dispatchProps(this, { searchText: this._el.search.value });
        this._paint();
      }, 220);
    });
    this._el.scroller.addEventListener("keydown", (e) => {
      if (e.key === "Escape") this._clearSelection(true);
    });
  }

  // ---------------------------------------------------------------- lifecycle
  connectedCallback() {
    this._schedule();
  }
  onCustomWidgetBeforeUpdate(changedProps) {
    this._props = Object.assign(this._props, changedProps || {});
  }
  onCustomWidgetAfterUpdate(changedProps) {
    const c = changedProps || {};
    const keys = Object.keys(c);
    const bulk = keys.length > 12;
    if (!this._initialized || bulk) {
      this._seen.exportToken = this._props.exportToken;
      this._seen.clearSelectionToken = this._props.clearSelectionToken;
      this._seen.expandToken = this._props.expandToken;
      this._initialized = true;
    } else {
      if ("clearSelectionToken" in c && c.clearSelectionToken !== this._seen.clearSelectionToken) {
        this._seen.clearSelectionToken = c.clearSelectionToken;
        this._clearSelection(false);
      }
      if ("expandToken" in c && c.expandToken !== this._seen.expandToken) {
        this._seen.expandToken = c.expandToken;
        this._expandAll(this._props.expandCommand !== "collapse");
      }
      if ("exportToken" in c && c.exportToken !== this._seen.exportToken) {
        this._seen.exportToken = c.exportToken;
        this.exportAs(this._props.exportFormat, this._props.exportRequestFileName);
      }
    }
    if (keys.length && keys.every((k) => NON_RENDER_KEYS.has(k))) return;
    this._schedule();
  }
  onCustomWidgetResize() {
    /* the table scrolls; nothing to recompute */
  }
  onCustomWidgetDestroy() {
    clearTimeout(this._timer);
  }

  _binding() {
    return this._props[BINDING_ID] || this[BINDING_ID];
  }
  _schedule() {
    clearTimeout(this._timer);
    this._timer = setTimeout(() => this._render(), 0);
  }

  // ---------------------------------------------------------------- formatting
  _fmt() {
    const p = this._props;
    const m = this._model;
    let scale = p.scale;
    if (!scale || scale === "auto") {
      const vals = [];
      if (m) m.nodes.forEach((n) => n.values.forEach((v) => v != null && vals.push(v)));
      scale = SacKit.autoScaleFor(vals);
    }
    const base = {
      scale,
      decimals: p.decimals,
      prefix: p.prefix,
      suffix: p.suffix,
      negativeStyle: p.negativeStyle,
      locale: p.locale,
      symbols: SacKit.parseSymbols(p.scaleSymbols),
    };
    return {
      value: base,
      delta: Object.assign({}, base, { plusSign: true }),
      pct: { percent: true, decimals: p.percentDecimals, plusSign: true, negativeStyle: p.negativeStyle, locale: p.locale },
    };
  }

  _memberText(cell) {
    const p = this._props;
    if (!cell) return "";
    const id = SacKit.plainMemberId(cell.id);
    if (p.dimensionDisplay === "id") return id;
    if (p.dimensionDisplay === "idLabel") return id && id !== cell.label ? `${id} – ${cell.label}` : cell.label;
    return cell.label;
  }

  // ---------------------------------------------------------------- render
  _render() {
    if (!this.isConnected) return;
    const p = this._props;
    const el = this._el;
    el.wrap.style.fontFamily = p.fontFamily;
    el.wrap.style.fontSize = `${p.fontSize}px`;
    el.wrap.style.color = p.textColor;
    el.wrap.style.background = p.backgroundColor || "transparent";
    const showHead = !!(p.showTitle && (p.tableTitle || p.tableSubtitle));
    el.head.classList.toggle("on", showHead);
    el.title.textContent = p.tableTitle || "";
    el.title.style.fontSize = `${Math.round(p.fontSize * 1.25)}px`;
    el.subtitle.textContent = p.tableSubtitle || "";
    const pad = DENSITY[p.rowDensity] || 7;
    const grid = p.showGridLines ? `1px solid ${p.borderColor}` : "none";
    el.dyn.textContent = `
      th { background:${p.headerBackground}; color:${p.headerTextColor}; padding:${pad + 1}px 10px; border-bottom:2px solid ${p.borderColor}; }
      td { padding:${pad}px 10px; border-bottom:${grid}; }
      ${p.stickyHeader ? "thead th { position:sticky; top:0; z-index:3; }" : ""}
      ${p.freezeFirstColumn ? `tr > :first-child { position:sticky; left:0; z-index:2; } thead th:first-child { z-index:4; }` : ""}
      tbody tr td { background:${p.backgroundColor || "#fff"}; }
      ${p.zebra ? `tbody tr:nth-child(even) td { background:${p.zebraColor}; }` : ""}
      tbody tr:hover td { filter:brightness(0.97); }
      tbody tr.sel td { background:${p.selectionColor} !important; }
      tr.total td { background:${p.totalBackground}; border-top:2px solid ${p.borderColor}; }
      .neg { color:${p.negativeRed ? p.negativeColor : "inherit"}; }
      .good { color:${p.positiveColor}; }
      .bad { color:${p.negativeColor}; }
    `;
    el.search.classList.toggle("off", !p.showSearch);
    if (el.search.value !== (p.searchText || "") && this._shadow.activeElement !== el.search) el.search.value = p.searchText || "";

    const parsed = SacKit.parseDataBinding(this._binding());
    if (parsed.state !== "success") {
      this._message(parsed.state === "loading" ? "Loading…" : "Bind data in the Builder panel: dimensions for the rows and measures for the columns.");
      return;
    }
    const model = buildTable(parsed, p);
    if (model.error) {
      this._message(model.error);
      return;
    }
    this._model = model;
    // reset expand state when the result set structure changes
    const sig = `${model.tree}|${model.nodes.length}|${model.nodes.slice(0, 3).map((n) => n.key).join(",")}|${p.expandLevel}`;
    if (sig !== this._signature) {
      this._signature = sig;
      this._collapsed.clear();
      if (model.tree) model.nodes.forEach((n) => n.children.length && n.depth >= p.expandLevel && this._collapsed.add(n.key));
    }
    const keys = new Set(model.nodes.map((n) => n.key));
    [...this._selected].forEach((k) => !keys.has(k) && this._selected.delete(k));
    const hasTree = model.tree;
    el.bar.querySelector('[data-cmd="expand"]').classList.toggle("off", !hasTree);
    el.bar.querySelector('[data-cmd="collapse"]').classList.toggle("off", !hasTree);
    el.bar.querySelectorAll("button[data-export]").forEach((b) => b.classList.toggle("off", !p.showToolbar));
    el.bar.classList.toggle("off", !p.showToolbar && !p.showSearch && !hasTree);
    el.msg.classList.remove("on");
    this._paint();
  }

  _message(text) {
    this._model = null;
    this._el.thead.innerHTML = "";
    this._el.tbody.innerHTML = "";
    this._el.tfoot.innerHTML = "";
    this._el.msg.textContent = text;
    this._el.msg.classList.add("on");
    SacKit.renderComplete(this);
  }

  _sortValue(n, col) {
    if (col.type === "dim") return (n.dims[col.di] && n.dims[col.di].label) || "";
    if (col.type === "measure") return n.values[col.mi];
    if (col.type === "var") return n.var ? n.var.v : null;
    if (col.type === "varpct") return n.var ? n.var.pct : null;
    return null;
  }

  /** Rows in display order. forceExpand=true ignores the collapse state (used by exports). */
  _rows(forceExpand) {
    const m = this._model;
    const p = this._props;
    const q = String(p.searchText || "").trim().toLowerCase();
    const match = (n) => !q || n.dims.some((d) => d.label.toLowerCase().includes(q) || SacKit.plainMemberId(d.id).toLowerCase().includes(q));
    const col = m.cols.find((c) => c.key === p.sortKey);
    const dir = p.sortDir === "desc" ? -1 : p.sortDir === "asc" ? 1 : 0;
    const cmp =
      col && dir
        ? (a, b) => {
            const x = this._sortValue(a, col);
            const y = this._sortValue(b, col);
            if (x == null && y == null) return 0;
            if (x == null) return 1;
            if (y == null) return -1;
            return dir * (typeof x === "string" ? x.localeCompare(y, undefined, { numeric: true }) : x - y);
          }
        : null;
    if (!m.tree) {
      let list = m.nodes.filter(match);
      if (cmp) list = [...list].sort(cmp);
      return list.map((n) => ({ n, depth: 0 }));
    }
    const keep = new Map();
    const visit = (n) => {
      let k = match(n);
      n.children.forEach((c) => {
        if (visit(c)) k = true;
      });
      keep.set(n, k);
      return k;
    };
    m.roots.forEach(visit);
    const out = [];
    const walk = (list, depth) => {
      let l = list.filter((n) => keep.get(n));
      if (cmp) l = [...l].sort(cmp);
      l.forEach((n) => {
        out.push({ n, depth });
        const open = forceExpand || q || !this._collapsed.has(n.key);
        if (n.children.length && open) walk(n.children, depth + 1);
      });
    };
    walk(m.roots, 0);
    return out;
  }

  _headerLabel(col, f) {
    const p = this._props;
    if (col.type !== "measure" && col.type !== "var") return col.label;
    const sym = f.value.scale !== "none" && p.showScaleInHeader ? f.value.symbols[f.value.scale] || f.value.scale : "";
    const unit = col.unit ? ` ${col.unit}` : "";
    return sym || unit ? `${col.label} (${[sym, unit.trim()].filter(Boolean).join(" ")})` : col.label;
  }

  _paint() {
    const m = this._model;
    if (!m) return;
    const p = this._props;
    const f = this._fmt();
    const esc = SacKit.escapeHtml;
    const rows = this._rows(false);
    const shown = rows.slice(0, Math.max(1, p.maxRows || 3000));
    this._visible = shown;
    // header
    let h = "<tr>";
    m.cols.forEach((c, i) => {
      const sortable = p.enableSorting;
      const ind = p.sortKey === c.key ? (p.sortDir === "asc" ? "▲" : p.sortDir === "desc" ? "▼" : "") : "";
      const cls = [c.type === "dim" ? "dim" : "mh", sortable ? "sortable" : ""].join(" ");
      h += `<th class="${cls}" data-col="${i}" scope="col"${ind ? ` aria-sort="${p.sortDir === "asc" ? "ascending" : "descending"}"` : ""}>${esc(
        this._headerLabel(c, f)
      )}${ind ? `<span class="ind">${ind}</span>` : ""}</th>`;
    });
    this._el.thead.innerHTML = h + "</tr>";
    // body
    const dbCol = p.showDataBars ? m.cols.find((c) => c.type === "measure" && c.mi === clampIndex(p.dataBarMeasureIndex, m.parsed.measures.length)) : null;
    const dbMax = dbCol ? Math.max(1e-12, ...shown.map((r) => Math.abs(r.n.values[dbCol.mi] || 0))) : 1;
    const pctMax = m.variance ? Math.max(0.05, ...shown.map((r) => Math.abs((r.n.var && r.n.var.pct) || 0))) : 1;
    const parts = [];
    let prevDims = [];
    shown.forEach((r, ri) => {
      const n = r.n;
      const sel = this._selected.has(n.key);
      let tr = `<tr data-r="${ri}" class="${sel ? "sel" : ""}" aria-selected="${sel}">`;
      m.cols.forEach((c) => {
        if (c.type === "dim") {
          let text = this._memberText(n.dims[c.di]);
          if (m.tree) {
            const open = !this._collapsed.has(n.key) || String(p.searchText || "").trim();
            const tog = n.children.length ? `<span class="tog" data-tog="1">${open ? "▾" : "▸"}</span>` : '<span class="tog leaf">•</span>';
            tr += `<td class="dim" style="padding-left:${8 + r.depth * 16}px"${n.children.length ? ' data-bold="1"' : ""}>${tog}${
              n.children.length ? `<b>${esc(text)}</b>` : esc(text)
            }</td>`;
          } else {
            const repeat = p.repeatMemberNames || c.di === m.parsed.dims.length - 1 || p.sortKey;
            const same = !repeat && prevDims.length > c.di && prevDims.slice(0, c.di + 1).every((d, k) => d === (n.dims[k] && n.dims[k].id));
            tr += `<td class="dim">${same ? "" : esc(text)}</td>`;
          }
        } else if (c.type === "measure") {
          const v = n.values[c.mi];
          const txt = p.useSacFormatting && n.formatted[c.mi] ? n.formatted[c.mi] : SacKit.formatNumber(v, f.value);
          let style = "";
          if (dbCol && c === dbCol && v != null) {
            const w = Math.round((Math.abs(v) / dbMax) * 100);
            const color = v < 0 ? p.negativeColor : p.dataBarColor;
            style = ` style="background-image:linear-gradient(90deg, ${color}55 ${w}%, transparent ${w}%)"`;
          }
          tr += `<td class="${v != null && v < 0 ? "neg" : ""}"${style}>${esc(txt)}</td>`;
        } else if (c.type === "var") {
          const vv = n.var || {};
          tr += `<td class="${vv.good == null ? "" : vv.good ? "good" : "bad"}">${esc(SacKit.formatNumber(vv.v, f.delta))}</td>`;
        } else if (c.type === "varpct") {
          const vv = n.var || {};
          let bar = "";
          if (p.showVarianceBars && vv.pct != null) {
            const w = Math.min(50, (Math.abs(vv.pct) / pctMax) * 50);
            const color = vv.good == null ? "#9AA5B1" : vv.good ? p.positiveColor : p.negativeColor;
            bar = `<span class="mini"><b></b><i style="background:${color};${vv.pct >= 0 ? `left:50%;width:${w}%` : `right:50%;width:${w}%`}"></i></span>`;
          }
          tr += `<td class="${vv.good == null ? "" : vv.good ? "good" : "bad"}"><span class="pct">${esc(SacKit.formatNumber(vv.pct, f.pct))}${bar}</span></td>`;
        }
      });
      parts.push(tr + "</tr>");
      prevDims = n.dims.map((d) => d.id);
    });
    if (rows.length > shown.length)
      parts.push(`<tr><td class="dim" colspan="${m.cols.length}" style="opacity:.7">… ${rows.length - shown.length} more rows (all rows are included in exports)</td></tr>`);
    // totals
    let totalHtml = "";
    if (p.showTotals && m.parsed.measures.length) {
      totalHtml = '<tr class="total">';
      let labelDone = false;
      m.cols.forEach((c) => {
        if (c.type === "dim") {
          totalHtml += `<td class="dim">${labelDone ? "" : esc(p.totalLabel || "Total")}</td>`;
          labelDone = true;
        } else if (c.type === "measure") {
          const v = m.totals[c.mi];
          totalHtml += `<td class="${v < 0 ? "neg" : ""}">${esc(SacKit.formatNumber(v, f.value))}</td>`;
        } else if (c.type === "var") {
          const tv = m.totalVar || {};
          totalHtml += `<td class="${tv.good == null ? "" : tv.good ? "good" : "bad"}">${esc(SacKit.formatNumber(tv.v, f.delta))}</td>`;
        } else if (c.type === "varpct") {
          const tv = m.totalVar || {};
          totalHtml += `<td class="${tv.good == null ? "" : tv.good ? "good" : "bad"}">${esc(SacKit.formatNumber(tv.pct, f.pct))}</td>`;
        }
      });
      totalHtml += "</tr>";
    }
    if (p.totalPosition === "top" && totalHtml) {
      this._el.tbody.innerHTML = totalHtml + parts.join("");
      this._el.tfoot.innerHTML = "";
    } else {
      this._el.tbody.innerHTML = parts.join("");
      this._el.tfoot.innerHTML = totalHtml;
    }
    SacKit.renderComplete(this);
  }

  // ---------------------------------------------------------------- interaction
  _onHeadClick(e) {
    const th = e.target.closest("th[data-col]");
    if (!th || !this._props.enableSorting || !this._model) return;
    const col = this._model.cols[Number(th.dataset.col)];
    let dir = "asc";
    if (this._props.sortKey === col.key) dir = this._props.sortDir === "asc" ? "desc" : this._props.sortDir === "desc" ? "" : "asc";
    this._props.sortKey = dir ? col.key : "";
    this._props.sortDir = dir;
    SacKit.dispatchProps(this, { sortKey: this._props.sortKey, sortDir: dir });
    this._paint();
  }

  _onBodyClick(e) {
    const tr = e.target.closest("tr[data-r]");
    if (!tr) return;
    const r = this._visible[Number(tr.dataset.r)];
    if (!r) return;
    if (e.target.closest("[data-tog]")) {
      if (this._collapsed.has(r.n.key)) this._collapsed.delete(r.n.key);
      else this._collapsed.add(r.n.key);
      this._paint();
      return;
    }
    const key = r.n.key;
    if (e.ctrlKey || e.metaKey || e.shiftKey || this._props.multiSelect) {
      if (this._selected.has(key)) this._selected.delete(key);
      else this._selected.add(key);
    } else if (this._selected.size === 1 && this._selected.has(key)) this._selected.clear();
    else {
      this._selected.clear();
      this._selected.add(key);
    }
    this._paint();
    this._publishSelection(true);
  }

  _expandAll(expand) {
    if (!this._model || !this._model.tree) return;
    this._collapsed.clear();
    if (!expand) this._model.nodes.forEach((n) => n.children.length && this._collapsed.add(n.key));
    this._paint();
  }

  _clearSelection(byUser) {
    const had = this._selected.size > 0;
    this._selected.clear();
    if (this._model) this._paint();
    if (had || !byUser) this._publishSelection(byUser);
  }

  async _publishSelection(byUser) {
    const p = this._props;
    const m = this._model;
    const nodes = m ? m.nodes.filter((n) => this._selected.has(n.key)) : [];
    const la = SacKit.linkedAnalysis(this, BINDING_ID, p);
    if (!nodes.length) {
      if (p.enableLinkedAnalysis) await la.removeFilters();
      SacKit.dispatchProps(this, { selectedMemberId: "", selectedMemberLabel: "", selectedDimensionId: "", selectedRowJson: "" });
      if (byUser) SacKit.fireEvent(this, "onClear");
      return;
    }
    const sels = nodes.map((n) => n.selection).filter((s) => s && Object.keys(s).length);
    if (p.enableLinkedAnalysis && sels.length) await la.setFilters(sels.length === 1 ? sels[0] : sels);
    SacKit.dispatchProps(this, {
      selectedMemberId: nodes.map((n) => n.dims.map((d) => d.id).join("|")).join(","),
      selectedMemberLabel: nodes.map((n) => n.dims.map((d) => d.label).join(" / ")).join(", "),
      selectedDimensionId: m.parsed.dims[0] ? m.parsed.dims[0].id : "",
      selectedRowJson: JSON.stringify(sels),
    });
    if (byUser) SacKit.fireEvent(this, "onSelect");
  }

  _toast(text) {
    const t = this._el.toast;
    t.textContent = text;
    t.classList.add("on");
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => t.classList.remove("on"), 1800);
  }

  // ---------------------------------------------------------------- export
  _fileBase(name) {
    const p = this._props;
    return SacKit.sanitizeFileName(name || p.exportFileName || p.widgetName || "Table", "Table");
  }

  async _withTimeout(promise, ms) {
    return Promise.race([promise, new Promise((res) => setTimeout(() => res(undefined), ms))]);
  }

  /** Best effort: read the active dimension filters through the data binding's DataSource API. */
  async _readFilters() {
    try {
      const dbs = this._props.dataBindings || this.dataBindings;
      if (!dbs || typeof dbs.getDataBinding !== "function") return [];
      const b = await Promise.resolve(dbs.getDataBinding(BINDING_ID));
      const ds = b && typeof b.getDataSource === "function" ? await this._withTimeout(Promise.resolve(b.getDataSource()), 1500) : null;
      if (!ds || typeof ds.getDimensionFilters !== "function") return [];
      let dims = this._model.parsed.dims.map((d) => ({ id: d.id, description: d.label }));
      if (typeof ds.getDimensions === "function") {
        const all = await this._withTimeout(Promise.resolve(ds.getDimensions()), 1500);
        if (Array.isArray(all) && all.length) dims = all.slice(0, 60);
      }
      const out = [];
      for (const d of dims) {
        const fl = await this._withTimeout(Promise.resolve(ds.getDimensionFilters(d.id)), 1500);
        if (Array.isArray(fl) && fl.length) {
          const text = fl
            .map((x) => {
              if (!x) return "";
              if (x.values) return x.values.join(", ");
              if (x.value != null) return `${x.exclude ? "NOT " : ""}${x.value}`;
              if (x.from != null || x.to != null) return `${x.from || ""} … ${x.to || ""}`;
              return JSON.stringify(x);
            })
            .join("; ");
          out.push([`${d.description || d.id} [${d.id}]`, text]);
        }
      }
      return out;
    } catch (e) {
      return [];
    }
  }

  async _xlsxBlob() {
    const p = this._props;
    const m = this._model;
    const f = this._fmt();
    const rows = this._rows(true);
    const wb = new XlsxLite.Workbook({ title: p.tableTitle || "Table", creator: `${WIDGET_NAME} ${WIDGET_VERSION}` });
    const ws = wb.addSheet(p.tableTitle || "Data", { showGridLines: false });
    const nf = (o, extra) => SacKit.excelNumFmt(o, extra);
    const fmtValue = nf(f.value, { redNegatives: p.negativeRed });
    const fmtDelta = nf(f.delta);
    const fmtPct = nf(f.pct);
    const sTitle = { bold: true, fontSize: 14, fontColor: "#1D2D3E" };
    const sSub = { italic: true, fontColor: "#6A6D70" };
    const sHead = { bold: true, fill: p.headerBackground, fontColor: p.headerTextColor, border: "bottom", borderColor: "#89919A", wrap: true, valign: "center" };
    const dimCols = m.cols.filter((c) => c.type === "dim");
    const idCols = m.parsed.dims.map((d) => ({ type: "id", label: `${d.label} ID`, di: m.parsed.dims.indexOf(d) }));
    const cols = [...m.cols, ...idCols];
    let r = 0;
    if (p.exportIncludeTitle) {
      ws.set(0, 0, p.tableTitle || p.widgetName || "Table", sTitle);
      ws.set(1, 0, `${p.tableSubtitle ? p.tableSubtitle + " · " : ""}Exported ${SacKit.stamp()} · ${rows.length} rows`, sSub);
      r = 3;
    }
    const headerRow = r;
    cols.forEach((c, ci) => ws.set(headerRow, ci, c.type === "id" ? c.label : this._headerLabel(c, f), Object.assign({}, sHead, c.type === "dim" || c.type === "id" ? {} : { align: "right" })));
    const outline = m.tree && p.exportOutline;
    rows.forEach((row, i) => {
      const n = row.n;
      const rr = headerRow + 1 + i;
      const node = n.children.length > 0;
      cols.forEach((c, ci) => {
        const st = node ? { bold: true } : {};
        if (c.type === "dim") {
          if (m.tree) st.indent = Math.min(15, row.depth);
          ws.set(rr, ci, this._memberText(n.dims[c.di]), Object.keys(st).length ? st : null);
        } else if (c.type === "id") {
          ws.set(rr, ci, SacKit.plainMemberId(n.dims[c.di] && n.dims[c.di].id), { fontColor: "#6A6D70" });
        } else if (c.type === "measure") {
          ws.set(rr, ci, n.values[c.mi], Object.assign(st, { numFmt: fmtValue }));
        } else if (c.type === "var" || c.type === "varpct") {
          const vv = n.var || {};
          const color = vv.good == null ? null : vv.good ? p.positiveColor : p.negativeColor;
          ws.set(rr, ci, c.type === "var" ? vv.v : vv.pct, Object.assign(st, { numFmt: c.type === "var" ? fmtDelta : fmtPct }, color ? { fontColor: color } : {}));
        }
      });
      if (outline && row.depth > 0) ws.rowOptions(rr, { outlineLevel: Math.min(7, row.depth) });
    });
    let last = headerRow + rows.length;
    if (p.showTotals && m.parsed.measures.length) {
      const tr = last + 1;
      const st = { bold: true, fill: p.totalBackground, border: "top", borderColor: "#89919A" };
      cols.forEach((c, ci) => {
        if (c.type === "dim" && c === dimCols[0]) ws.set(tr, ci, p.totalLabel || "Total", st);
        else if (c.type === "measure") ws.set(tr, ci, m.totals[c.mi], Object.assign({}, st, { numFmt: fmtValue }));
        else if (c.type === "var" || c.type === "varpct") {
          const tv = m.totalVar || {};
          const color = tv.good == null ? null : tv.good ? p.positiveColor : p.negativeColor;
          ws.set(tr, ci, c.type === "var" ? tv.v : tv.pct, Object.assign({}, st, { numFmt: c.type === "var" ? fmtDelta : fmtPct }, color ? { fontColor: color } : {}));
        } else ws.set(tr, ci, null, st);
      });
    }
    ws.opts.frozenRows = headerRow + 1;
    ws.opts.frozenCols = dimCols.length;
    ws.opts.autoFilter = `A${headerRow + 1}:${XlsxLite.colName(cols.length - 1)}${last + 1}`;
    ws.opts.colWidths = cols.map((c) => {
      if (c.type === "dim") return XlsxLite.fitWidth(rows.map((x) => " ".repeat(m.tree ? x.depth * 2 : 0) + this._memberText(x.n.dims[c.di])).concat([c.label]), 14, 60);
      if (c.type === "id") return XlsxLite.fitWidth(rows.map((x) => SacKit.plainMemberId(x.n.dims[c.di] && x.n.dims[c.di].id)), 10, 40);
      return Math.max(12, Math.min(24, this._headerLabel(c, f).length * 0.9 + 2));
    });

    if (p.exportInfoSheet) {
      const info = wb.addSheet("Info", { showGridLines: false });
      info.set(0, 0, "Export information", sTitle);
      const kv = [
        ["Widget", `${WIDGET_NAME} ${WIDGET_VERSION}`],
        ["Widget instance", p.widgetName || ""],
        ["Exported at", SacKit.stamp()],
        ["Rows exported", rows.length],
        ["Display", m.tree ? "Hierarchy (tree), Excel grouping " + (outline ? "on" : "off") : "Flat"],
        ["Number scale (display)", f.value.scale],
        ["Search filter", p.searchText || "—"],
        ["Sort", p.sortKey ? `${p.sortKey} ${p.sortDir}` : "model order"],
      ];
      let r2 = 2;
      kv.forEach(([k, v]) => {
        info.set(r2, 0, k, { bold: true, fontColor: "#556B82" });
        info.set(r2++, 1, v, { wrap: true });
      });
      r2++;
      info.set(r2++, 0, "Dimensions", { bold: true });
      m.parsed.dims.forEach((d) => {
        info.set(r2, 0, d.label);
        info.set(r2++, 1, d.id, { fontColor: "#6A6D70" });
      });
      r2++;
      info.set(r2++, 0, "Measures", { bold: true });
      m.parsed.measures.forEach((x) => {
        info.set(r2, 0, x.label);
        info.set(r2++, 1, x.id, { fontColor: "#6A6D70" });
      });
      const filters = await this._readFilters();
      r2++;
      info.set(r2++, 0, "Active filters (data source)", { bold: true });
      if (!filters.length) info.set(r2++, 0, "— none read (or not available to custom widgets)", { italic: true, fontColor: "#6A6D70" });
      filters.forEach(([k, v]) => {
        info.set(r2, 0, k);
        info.set(r2++, 1, v, { wrap: true });
      });
      r2++;
      info.set(r2, 0, "Note", { bold: true, fontColor: "#556B82" });
      info.set(r2, 1, "Values are true numbers; scaling is applied with Excel number formats only (no rounding).", { wrap: true });
      info.opts.colWidths = [34, 90];
    }

    if (p.exportAddinSheet) this._addinSheet(wb, rows);
    return wb.toBlob();
  }

  /** ID grid + SAP.GETDATA template for the SAP Analytics Cloud add-in for Microsoft Excel. */
  _addinSheet(wb, rows) {
    const p = this._props;
    const m = this._model;
    const ws = wb.addSheet("AddIn_Grid", { showGridLines: true, tabColor: "#0A6ED1" });
    const dims = m.parsed.dims;
    const meas = m.parsed.measures;
    const nD = dims.length;
    const firstRow = 8; // 1-based row of the first data line
    const pairs = SacKit.parseList(p.addinFixedFilters.replace(/;/g, ","))
      .map((x) => x.split("="))
      .filter((x) => x.length === 2)
      .map(([d, v]) => `,"${d.trim()}","${v.trim()}"`)
      .join("");
    const dimArgs = dims.map((d, i) => `,"${d.id}",$${XlsxLite.colName(i)}${firstRow}`).join("");
    const mCol = XlsxLite.colName(nD);
    const formula = `=SAP.GETDATA($B$2${dimArgs},"${p.addinMeasureDimension || "Measures"}",${mCol}$7${pairs})`;
    ws.set(0, 0, "SAP Analytics Cloud add-in for Microsoft Excel — ID grid", { bold: true, fontSize: 13 });
    ws.set(1, 0, "Data source alias", { bold: true });
    ws.set(1, 1, p.addinDataSource || "DS_1", { fill: "#FFF4CE", border: "thin" });
    ws.set(
      2,
      0,
      "1) In Excel: SAP Analytics Cloud ribbon → insert a data source for formulas on the same model and put its alias in B2.  2) Paste the template below into the first value cell (" +
        `${mCol}${firstRow}` +
        ") as a formula and fill right/down.  3) Verify dimension/measure IDs against the add-in (Designer panel) — live models can expose different technical IDs.",
      { wrap: true, fontColor: "#556B82" }
    );
    ws.merge(2, 0, 2, Math.max(3, nD + meas.length - 1));
    ws.rowOptions(2, { height: 48 });
    ws.set(3, 0, "Template formula:", { bold: true });
    ws.set(4, 0, formula, { fontName: "Consolas", fontColor: "#0A6ED1" });
    ws.merge(4, 0, 4, Math.max(3, nD + meas.length - 1));
    dims.forEach((d, i) => {
      ws.set(5, i, d.label, { bold: true, fill: "#EFF1F2" });
      ws.set(6, i, d.id, { fontColor: "#6A6D70", fill: "#EFF1F2" });
    });
    meas.forEach((x, j) => {
      ws.set(5, nD + j, x.label, { bold: true, fill: "#EFF1F2", align: "right" });
      ws.set(6, nD + j, x.id, { fontColor: "#6A6D70", fill: "#EFF1F2", align: "right" });
    });
    rows.forEach((row, i) => {
      const rr = firstRow - 1 + i;
      dims.forEach((d, k) => ws.set(rr, k, SacKit.plainMemberId(row.n.dims[k] && row.n.dims[k].id)));
      meas.forEach((x, j) => ws.set(rr, nD + j, row.n.values[j], { numFmt: "#,##0.00" }));
    });
    ws.opts.frozenRows = 7;
    ws.opts.colWidths = [...dims.map(() => 22), ...meas.map(() => 18)];
  }

  _csv() {
    const p = this._props;
    const m = this._model;
    const rows = this._rows(true);
    const header = [];
    m.cols.forEach((c) => {
      if (c.type === "dim") header.push(c.label);
    });
    if (m.tree) header.push("Level", "Parent ID");
    m.parsed.dims.forEach((d) => header.push(`${d.label} ID`));
    m.cols.forEach((c) => {
      if (c.type !== "dim") header.push(c.label);
    });
    const data = rows.map((row) => {
      const n = row.n;
      const out = [];
      m.cols.forEach((c) => {
        if (c.type === "dim") out.push(n.dims[c.di] ? n.dims[c.di].label : "");
      });
      if (m.tree) out.push(row.depth, SacKit.plainMemberId(n.parentId));
      m.parsed.dims.forEach((d, k) => out.push(SacKit.plainMemberId(n.dims[k] && n.dims[k].id)));
      m.cols.forEach((c) => {
        if (c.type === "measure") out.push(n.values[c.mi]);
        else if (c.type === "var") out.push(n.var ? n.var.v : "");
        else if (c.type === "varpct") out.push(n.var ? n.var.pct : "");
      });
      return out;
    });
    let delim = p.csvDelimiter === "tab" ? "\t" : p.csvDelimiter;
    if (!delim || delim === "auto") delim = /^(de|fr|es|it|pt|nl|ru|tr|pl|da|fi|sv|nb|cs|id)/i.test(p.locale || navigator.language || "") ? ";" : ",";
    return SacKit.toCsv([header, ...data], delim);
  }

  _tsvVisible() {
    const m = this._model;
    const f = this._fmt();
    const lines = [m.cols.map((c) => this._headerLabel(c, f)).join("\t")];
    this._visible.forEach((r) => {
      const n = r.n;
      lines.push(
        m.cols
          .map((c) => {
            if (c.type === "dim") return (m.tree ? "  ".repeat(r.depth) : "") + this._memberText(n.dims[c.di]);
            if (c.type === "measure") return n.values[c.mi] == null ? "" : String(SacKit.cleanNumber(n.values[c.mi]));
            if (c.type === "var") return n.var && n.var.v != null ? String(SacKit.cleanNumber(n.var.v)) : "";
            if (c.type === "varpct") return n.var && n.var.pct != null ? String(SacKit.cleanNumber(n.var.pct)) : "";
            return "";
          })
          .join("\t")
      );
    });
    return lines.join("\r\n");
  }

  /** Public: export (xlsx | csv | copy). */
  async exportAs(format, fileName) {
    if (!this._model) return false;
    const fmt = String(format || "xlsx").toLowerCase();
    const base = `${this._fileBase(fileName)}_${SacKit.fileStamp()}`;
    try {
      if (fmt === "csv") {
        SacKit.download(new Blob([this._csv()], { type: "text/csv;charset=utf-8" }), `${base}.csv`);
        this._toast("CSV downloaded");
      } else if (fmt === "copy" || fmt === "clipboard") {
        const ok = await SacKit.copyText(this._tsvVisible());
        this._toast(ok ? "Copied — paste into Excel" : "Copy blocked by the browser");
      } else {
        SacKit.download(await this._xlsxBlob(), `${base}.xlsx`);
        this._toast("Excel file downloaded");
      }
      SacKit.fireEvent(this, "onExported");
      return true;
    } catch (err) {
      console.error(`[${WIDGET_NAME}] export failed`, err);
      this._toast("Export failed — see console");
      return false;
    }
  }
}

ExportTable.buildTable = buildTable;
ExportTable.version = WIDGET_VERSION;

if (!customElements.get(WIDGET_TAG)) customElements.define(WIDGET_TAG, ExportTable);
