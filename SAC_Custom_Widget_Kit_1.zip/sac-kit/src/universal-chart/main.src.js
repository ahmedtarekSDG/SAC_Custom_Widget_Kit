/* ==========================================================================
 * Universal Chart (Apache ECharts) — SAP Analytics Cloud custom widget
 * Injected by build: WIDGET_TAG, WIDGET_NAME, WIDGET_VERSION, PROPS_DEFAULTS,
 *                    echarts (bundled privately — no window.echarts, AMD-safe)
 * ========================================================================== */
const BINDING_ID = "dataBinding";
const OUTPUT_KEYS = ["selectedMemberId", "selectedMemberLabel", "selectedDimensionId", "selectedRowJson"];
const COMMAND_KEYS = ["exportFormat", "exportRequestFileName", "exportToken", "clearSelectionToken"];
const NON_RENDER_KEYS = new Set([...OUTPUT_KEYS, ...COMMAND_KEYS, "widgetName"]);

const STYLE = `
:host { display:block; width:100%; height:100%; position:relative; overflow:hidden; }
.root { position:absolute; inset:0; }
.chart { position:absolute; inset:0; }
.msg { position:absolute; inset:0; display:none; align-items:center; justify-content:center; text-align:center; padding:16px; opacity:.8; }
.msg.on { display:flex; }
.toolbar { position:absolute; top:4px; right:6px; z-index:6; display:flex; gap:4px; opacity:0; transition:opacity .15s; }
:host(:hover) .toolbar, .toolbar:focus-within { opacity:1; }
@media (hover:none) { .toolbar { opacity:1; } }
.toolbar.off { display:none; }
.toolbar button { font:600 10px/1 Arial,sans-serif; color:#0A6ED1; background:rgba(255,255,255,.92); border:1px solid #BCCEE4; border-radius:4px; padding:4px 6px; cursor:pointer; }
.toolbar button:hover { background:#EBF5FE; border-color:#0A6ED1; }
`;
const template = document.createElement("template");
template.innerHTML = `<style>${STYLE}</style>
<div class="root"><div class="chart"></div><div class="msg"></div>
<div class="toolbar"><button type="button" data-export="png" title="PNG image">PNG</button><button type="button" data-export="xlsx" title="Data as Excel">XLSX</button><button type="button" data-export="csv" title="Data as CSV">CSV</button></div></div>`;

const isObj = (o) => o && typeof o === "object" && !Array.isArray(o);
function deepMerge(target, src) {
  if (Array.isArray(target) && Array.isArray(src)) {
    // arrays (e.g. series): merge element-wise so overrides can target series[0], series[1] …
    src.forEach((s, i) => {
      target[i] = isObj(target[i]) && isObj(s) ? deepMerge(target[i], s) : s;
    });
    return target;
  }
  Object.keys(src || {}).forEach((k) => {
    if (isObj(target[k]) && isObj(src[k])) deepMerge(target[k], src[k]);
    else if (Array.isArray(target[k]) && Array.isArray(src[k])) deepMerge(target[k], src[k]);
    else target[k] = src[k];
  });
  return target;
}

class UniversalChart extends HTMLElement {
  constructor() {
    super();
    this._shadow = this.attachShadow({ mode: "open" });
    this._shadow.appendChild(template.content.cloneNode(true));
    this._el = { chart: this._shadow.querySelector(".chart"), msg: this._shadow.querySelector(".msg"), toolbar: this._shadow.querySelector(".toolbar"), root: this._shadow.querySelector(".root") };
    this._props = Object.assign({}, PROPS_DEFAULTS);
    this._selected = new Map(); // key -> { sel, label }
    this._chart = null;
    this._renderer = null;
    this._timer = null;
    this._initialized = false;
    this._seen = { exportToken: 0, clearSelectionToken: 0 };
    this._el.toolbar.addEventListener("click", (e) => {
      const b = e.target.closest("button[data-export]");
      if (b) this.exportAs(b.dataset.export);
    });
  }

  connectedCallback() {
    if (typeof ResizeObserver !== "undefined" && !this._ro) {
      this._ro = new ResizeObserver(() => this._chart && this._chart.resize());
      this._ro.observe(this);
    }
    this._schedule();
  }
  disconnectedCallback() {
    if (this._ro) this._ro.disconnect();
    this._ro = null;
  }
  onCustomWidgetBeforeUpdate(changedProps) {
    this._props = Object.assign(this._props, changedProps || {});
  }
  onCustomWidgetAfterUpdate(changedProps) {
    const c = changedProps || {};
    const keys = Object.keys(c);
    if (!this._initialized || keys.length > 12) {
      this._seen.exportToken = this._props.exportToken;
      this._seen.clearSelectionToken = this._props.clearSelectionToken;
      this._initialized = true;
    } else {
      if ("clearSelectionToken" in c && c.clearSelectionToken !== this._seen.clearSelectionToken) {
        this._seen.clearSelectionToken = c.clearSelectionToken;
        this._clearSelection(false);
      }
      if ("exportToken" in c && c.exportToken !== this._seen.exportToken) {
        this._seen.exportToken = c.exportToken;
        this.exportAs(this._props.exportFormat, this._props.exportRequestFileName);
      }
    }
    if (keys.length && keys.every((k) => NON_RENDER_KEYS.has(k))) return;
    this._schedule();
  }
  onCustomWidgetResize() {
    if (this._chart) this._chart.resize();
  }
  onCustomWidgetDestroy() {
    this.disconnectedCallback();
    if (this._chart) this._chart.dispose();
    this._chart = null;
  }

  _binding() {
    return this._props[BINDING_ID] || this[BINDING_ID];
  }
  _schedule() {
    clearTimeout(this._timer);
    this._timer = setTimeout(() => this._render(), 0);
  }

  _fmt(values) {
    const p = this._props;
    const scale = !p.scale || p.scale === "auto" ? SacKit.autoScaleFor(values) : p.scale;
    return { scale, decimals: p.decimals, prefix: p.prefix, suffix: p.suffix, negativeStyle: p.negativeStyle, locale: p.locale, symbols: SacKit.parseSymbols(p.scaleSymbols) };
  }

  _message(text) {
    if (this._chart) this._chart.clear();
    this._el.msg.textContent = text;
    this._el.msg.classList.add("on");
    SacKit.renderComplete(this);
  }

  // ---------------------------------------------------------------- data shaping
  _categories(parsed, mi) {
    // unique members of the first dimension, values summed per measure
    const p = this._props;
    const map = new Map();
    parsed.rows.forEach((r) => {
      const d = r.dims[0] || { id: "", label: "" };
      const key = d.id || d.label;
      if (!map.has(key)) map.set(key, { key, label: d.label, id: d.id, sel: d.id ? { [parsed.dims[0].id]: d.id } : null, values: parsed.measures.map(() => 0) });
      const c = map.get(key);
      r.values.forEach((v, i) => (c.values[i] += v.raw || 0));
    });
    let cats = [...map.values()];
    if (p.sortMode === "desc") cats.sort((a, b) => b.values[mi] - a.values[mi]);
    else if (p.sortMode === "asc") cats.sort((a, b) => a.values[mi] - b.values[mi]);
    else if (p.sortMode === "label") cats.sort((a, b) => a.label.localeCompare(b.label, undefined, { numeric: true }));
    const n = Math.max(0, Math.floor(p.topN || 0));
    if (n > 0 && cats.length > n) {
      const ranked = [...cats].sort((a, b) => Math.abs(b.values[mi]) - Math.abs(a.values[mi]));
      const keep = new Set(ranked.slice(0, n));
      const rest = cats.filter((c) => !keep.has(c));
      cats = cats.filter((c) => keep.has(c));
      cats.push({
        key: "__others",
        label: `${p.othersLabel || "Others"} (${rest.length})`,
        id: "",
        sel: rest.map((c) => c.sel).filter(Boolean),
        values: parsed.measures.map((_, i) => rest.reduce((s, c) => s + c.values[i], 0)),
      });
    }
    return cats;
  }

  _hierarchy(parsed, mi) {
    // nested tree from parentId (single hierarchical dimension) or from dimension 1 > dimension 2
    const d0 = parsed.dims[0];
    const hasParent = parsed.dims.length === 1 && parsed.rows.some((r) => r.dims[0].parentId);
    if (hasParent) {
      const nodes = new Map();
      parsed.rows.forEach((r) => {
        const d = r.dims[0];
        nodes.set(d.id, { name: d.label, value: r.values[mi] ? r.values[mi].raw : null, __key: d.id, __sel: { [d0.id]: d.id }, children: [], __parent: d.parentId });
      });
      const roots = [];
      nodes.forEach((n) => {
        const par = n.__parent && nodes.get(n.__parent);
        if (par && par !== n) par.children.push(n);
        else roots.push(n);
      });
      const clean = (n) => {
        if (n.children.length) {
          n.children.forEach(clean);
          delete n.value; // parents: area = sum of children
        } else delete n.children;
        delete n.__parent;
        return n;
      };
      return roots.map(clean);
    }
    if (parsed.dims.length >= 2) {
      const d1 = parsed.dims[1];
      const map = new Map();
      parsed.rows.forEach((r) => {
        const a = r.dims[0];
        const b = r.dims[1];
        if (!map.has(a.id)) map.set(a.id, { name: a.label, __key: a.id, __sel: { [d0.id]: a.id }, children: [] });
        map.get(a.id).children.push({ name: b.label, value: r.values[mi] ? r.values[mi].raw : 0, __key: `${a.id}|${b.id}`, __sel: { [d0.id]: a.id, [d1.id]: b.id } });
      });
      return [...map.values()];
    }
    return this._categories(parsed, mi).map((c) => ({ name: c.label, value: c.values[mi], __key: c.key, __sel: c.sel }));
  }

  // ---------------------------------------------------------------- option
  _option(parsed) {
    const p = this._props;
    const type = p.chartType || "bar";
    const ms = parsed.measures;
    const mi = 0;
    const palette = SacKit.parseList(p.palette).filter((c) => /^#?[0-9a-f]{3,8}$/i.test(c) || /^rgb/i.test(c));
    const allValues = [];
    parsed.rows.forEach((r) => r.values.forEach((v) => v.raw != null && allValues.push(v.raw)));
    const fmt = this._fmt(allValues);
    const num = (v) => SacKit.formatNumber(v, fmt);
    const pctFmt = { percent: true, decimals: 1, locale: p.locale };
    const text = { color: p.textColor, fontFamily: p.fontFamily, fontSize: p.fontSize };
    const legendPos = p.legendPosition || "top";
    let legend;
    if (legendPos === "none") legend = { show: false };
    else if (legendPos === "right") legend = { show: true, type: "scroll", orient: "vertical", right: 4, top: "middle", textStyle: text };
    else if (legendPos === "left") legend = { show: true, type: "scroll", orient: "vertical", left: 4, top: "middle", textStyle: text };
    else if (legendPos === "bottom") legend = { show: true, type: "scroll", bottom: 0, left: "center", textStyle: text };
    else legend = { show: true, type: "scroll", top: p.showTitle ? 44 : 4, left: "center", textStyle: text };
    const top = (p.showTitle ? 44 : 10) + (legendPos === "top" ? 26 : 0);
    const grid = { left: legendPos === "left" ? 120 : 12, right: legendPos === "right" ? 140 : 16, top, bottom: legendPos === "bottom" ? 34 : 10, containLabel: true };
    const isSel = (key) => this._selected.size === 0 || this._selected.has(key);
    const item = (value, key, sel, label, extra) => Object.assign({ value, __key: key, __sel: sel, __label: label, itemStyle: { opacity: isSel(key) ? 1 : 0.3 } }, extra || {});
    const totalOf = (arr) => arr.reduce((s, v) => s + (Number(v) || 0), 0);
    const labelFormatter = (params) => {
      const v = Array.isArray(params.value) ? params.value[params.value.length - 1] : params.value;
      if (p.labelContent === "percent" && params.percent != null) return `${params.percent.toFixed(1)}%`;
      if (p.labelContent === "name") return params.name;
      if (p.labelContent === "nameValue") return `${params.name}: ${num(v)}`;
      return num(v);
    };
    const tooltip = {
      confine: true,
      textStyle: { fontFamily: p.fontFamily, fontSize: p.fontSize },
      valueFormatter: (v) => (typeof v === "number" ? num(v) : v),
    };
    const base = {
      animation: !!p.animation,
      color: palette.length ? palette : undefined,
      backgroundColor: p.backgroundColor && p.backgroundColor !== "transparent" ? p.backgroundColor : "transparent",
      textStyle: text,
      title: p.showTitle ? { text: p.chartTitle || "", subtext: p.chartSubtitle || "", left: 8, top: 4, textStyle: Object.assign({}, text, { fontSize: Math.round(p.fontSize * 1.25), fontWeight: "bold" }), subtextStyle: text } : { show: false },
      tooltip,
      legend,
    };
    const valueAxis = (extra) =>
      Object.assign(
        { type: "value", scale: !p.axisStartAtZero, axisLabel: { formatter: (v) => SacKit.formatNumber(v, Object.assign({}, fmt, { decimals: 0 })), color: p.textColor }, splitLine: { show: !!p.showGridlines, lineStyle: { color: "#E5E5E5" } } },
        extra || {}
      );
    const catAxis = (data, extra) => Object.assign({ type: "category", data, axisLabel: { rotate: p.rotateLabels || 0, color: p.textColor, hideOverlap: true }, axisTick: { alignWithLabel: true } }, extra || {});
    const lbl = (pos) => ({ show: !!p.showDataLabels, position: pos || "top", formatter: labelFormatter, color: p.textColor, fontSize: Math.max(8, p.fontSize - 1) });

    // ----- category / series charts
    const catTypes = ["bar", "barHorizontal", "stackedBar", "stackedPercent", "line", "area", "combo", "pareto"];
    if (catTypes.includes(type)) {
      const cats = this._categories(parsed, mi);
      const labels = cats.map((c) => c.label);
      let series = [];
      const d1 = parsed.dims[1];
      const pivot = !!d1 && type !== "combo" && type !== "pareto";
      if (pivot) {
        // series per member of the 2nd dimension (first measure)
        const sMembers = new Map();
        parsed.rows.forEach((r) => {
          const b = r.dims[1];
          if (!sMembers.has(b.id)) sMembers.set(b.id, { id: b.id, label: b.label, vals: new Map() });
          const a = r.dims[0];
          const m = sMembers.get(b.id).vals;
          m.set(a.id || a.label, (m.get(a.id || a.label) || 0) + (r.values[mi] ? r.values[mi].raw || 0 : 0));
        });
        series = [...sMembers.values()].map((s) => ({
          name: s.label,
          data: cats.map((c) => {
            const v = c.key === "__others" ? null : s.vals.get(c.key) || 0;
            const sel = c.sel && !Array.isArray(c.sel) ? Object.assign({ [d1.id]: s.id }, c.sel) : c.sel;
            return item(v, `${c.key}|${s.id}`, sel, `${c.label} / ${s.label}`);
          }),
        }));
      } else {
        series = ms.map((m, i) => ({ name: m.label, data: cats.map((c) => item(c.values[i], `${c.key}|${m.id}`, c.sel, `${c.label} / ${m.label}`)) }));
      }
      const horizontal = type === "barHorizontal";
      const stacked = type === "stackedBar" || type === "stackedPercent";
      if (type === "stackedPercent") {
        const totals = labels.map((_, ci) => totalOf(series.map((s) => Math.abs(s.data[ci].value || 0))));
        series.forEach((s) => s.data.forEach((d, ci) => (d.value = totals[ci] ? (d.value || 0) / totals[ci] : 0)));
      }
      let out;
      if (type === "pareto") {
        const sorted = [...cats].sort((a, b) => b.values[mi] - a.values[mi]);
        const tot = totalOf(sorted.map((c) => c.values[mi]));
        let run = 0;
        out = Object.assign(base, {
          grid,
          xAxis: catAxis(sorted.map((c) => c.label)),
          yAxis: [valueAxis(), { type: "value", min: 0, max: 1, axisLabel: { formatter: (v) => `${Math.round(v * 100)}%`, color: p.textColor }, splitLine: { show: false } }],
          series: [
            { name: ms[mi].label, type: "bar", data: sorted.map((c) => item(c.values[mi], c.key, c.sel, c.label)), label: lbl("top") },
            {
              name: "Cumulative %",
              type: "line",
              yAxisIndex: 1,
              smooth: !!p.smooth,
              data: sorted.map((c) => {
                run += c.values[mi];
                return tot ? run / tot : 0;
              }),
              tooltip: { valueFormatter: (v) => SacKit.formatNumber(v, pctFmt) },
              markLine: { silent: true, symbol: "none", lineStyle: { type: "dashed", color: "#9AA5B1" }, data: [{ yAxis: 0.8 }], label: { formatter: "80%" } },
            },
          ],
        });
      } else if (type === "combo") {
        out = Object.assign(base, {
          grid,
          tooltip: Object.assign({}, tooltip, { trigger: "axis" }),
          xAxis: catAxis(labels),
          yAxis: [valueAxis(), valueAxis({ splitLine: { show: false } })],
          series: series.map((s, i) => Object.assign(s, i === 0 ? { type: "bar", label: lbl("top") } : { type: "line", yAxisIndex: ms.length > 1 ? 1 : 0, smooth: !!p.smooth, showSymbol: !!p.showSymbols, label: lbl("top") })),
        });
      } else {
        const t = type === "line" || type === "area" ? "line" : "bar";
        out = Object.assign(base, {
          grid,
          tooltip: Object.assign({}, tooltip, { trigger: "axis", axisPointer: { type: t === "bar" ? "shadow" : "line" } }, type === "stackedPercent" ? { valueFormatter: (v) => SacKit.formatNumber(v, pctFmt) } : {}),
          xAxis: horizontal ? valueAxis() : catAxis(labels),
          yAxis: horizontal ? catAxis(labels, { inverse: true }) : type === "stackedPercent" ? { type: "value", max: 1, axisLabel: { formatter: (v) => `${Math.round(v * 100)}%` } } : valueAxis(),
          series: series.map((s) =>
            Object.assign(s, {
              type: t,
              stack: stacked || type === "area" ? (stacked ? "total" : undefined) : undefined,
              areaStyle: type === "area" ? { opacity: 0.25 } : undefined,
              smooth: t === "line" ? !!p.smooth : undefined,
              showSymbol: t === "line" ? !!p.showSymbols : undefined,
              label: lbl(horizontal ? "right" : stacked ? "inside" : "top"),
              emphasis: { focus: "series" },
            })
          ),
        });
      }
      return out;
    }

    // ----- part-of-whole
    if (["pie", "donut", "rose", "funnel"].includes(type)) {
      const cats = this._categories(parsed, mi);
      const data = cats.map((c) => Object.assign(item(c.values[mi], c.key, c.sel, c.label), { name: c.label }));
      const s =
        type === "funnel"
          ? { type: "funnel", left: "10%", width: "80%", top: top + 6, bottom: 10, sort: "descending", gap: 2, label: { show: true, position: "inside", formatter: labelFormatter, color: "#fff" }, data }
          : {
              type: "pie",
              radius: type === "donut" ? [`${p.donutInnerRadius}%`, "75%"] : type === "rose" ? ["15%", "75%"] : [0, "75%"],
              center: ["50%", legendPos === "top" ? "56%" : "50%"],
              roseType: type === "rose" ? "area" : undefined,
              itemStyle: { borderColor: "#fff", borderWidth: 1 },
              label: { show: p.showDataLabels || true, formatter: p.showDataLabels ? labelFormatter : "{b}", color: p.textColor },
              data,
            };
      return Object.assign(base, { tooltip: Object.assign({}, tooltip, { trigger: "item" }), series: [Object.assign({ name: ms[mi].label }, s)] });
    }

    if (type === "gauge") {
      const value = totalOf(parsed.rows.map((r) => r.values[mi].raw));
      const ti = Math.max(0, Math.min(ms.length - 1, p.gaugeTargetIndex | 0));
      const hasTarget = ms.length > 1 && ti !== mi;
      const target = hasTarget ? totalOf(parsed.rows.map((r) => r.values[ti].raw)) : null;
      const max = p.gaugeMax > 0 ? p.gaugeMax : SacKit.niceTicks(0, Math.max(value, target || 0) * 1.15, 5).max;
      const ratio = hasTarget && target ? value / target : null;
      const data = [{ value, name: ms[mi].label, title: { offsetCenter: [0, "68%"] }, detail: { offsetCenter: [0, "40%"] } }];
      const targetSeries = hasTarget
        ? [{ type: "gauge", min: 0, max, center: ["50%", "60%"], radius: "88%", axisLine: { show: false }, axisTick: { show: false }, splitLine: { show: false }, axisLabel: { show: false }, progress: { show: false }, anchor: { show: false }, title: { show: false }, detail: { show: false }, pointer: { width: 3, length: "92%", itemStyle: { color: p.textColor } }, tooltip: { valueFormatter: (v) => `Target ${num(v)}` }, data: [{ value: target, name: "Target" }] }]
        : [];
      return Object.assign(base, {
        series: [
          {
            type: "gauge",
            min: 0,
            max,
            center: ["50%", "60%"],
            radius: "88%",
            progress: { show: true, width: 14, itemStyle: { color: ratio == null ? palette[0] || "#5899DA" : ratio >= 1 ? "#2E7D32" : ratio >= 0.9 ? "#E9730C" : "#C62828" } },
            axisLine: { lineStyle: { width: 14, color: [[1, "#E5E8EB"]] } },
            axisLabel: { formatter: (v) => SacKit.formatNumber(v, Object.assign({}, fmt, { decimals: 0 })), color: p.textColor, distance: 18 },
            splitLine: { length: 8 },
            axisTick: { show: false },
            pointer: { width: 5 },
            detail: { formatter: (v) => `${num(v)}${ratio != null ? `\n${SacKit.formatNumber(ratio, pctFmt)} of target ${num(target)}` : ""}`, fontSize: Math.round(p.fontSize * 1.4), lineHeight: Math.round(p.fontSize * 1.8), color: p.textColor },
            data,
          },
          ...targetSeries,
        ],
      });
    }

    if (type === "radar") {
      const cats = this._categories(parsed, mi).slice(0, 30);
      const maxPer = cats.map((c) => Math.max(...c.values.map((v) => Math.abs(v))) * 1.1 || 1);
      return Object.assign(base, {
        tooltip: Object.assign({}, tooltip, { trigger: "item" }),
        radar: { indicator: cats.map((c, i) => ({ name: c.label, max: maxPer[i] })), center: ["50%", "56%"], radius: "65%", axisName: { color: p.textColor } },
        series: [{ type: "radar", data: ms.map((m, i) => ({ name: m.label, value: cats.map((c) => c.values[i]), areaStyle: { opacity: 0.15 } })) }],
      });
    }

    if (type === "heatmap") {
      if (parsed.dims.length < 2) return { __error: "Heatmap needs two dimensions (x and y)." };
      const xs = [];
      const ys = [];
      const xi = new Map();
      const yi = new Map();
      const d0 = parsed.dims[0];
      const d1 = parsed.dims[1];
      const data = [];
      parsed.rows.forEach((r) => {
        const a = r.dims[0];
        const b = r.dims[1];
        if (!xi.has(a.id)) xi.set(a.id, xs.push(a.label) - 1);
        if (!yi.has(b.id)) yi.set(b.id, ys.push(b.label) - 1);
        const key = `${a.id}|${b.id}`;
        data.push(item([xi.get(a.id), yi.get(b.id), r.values[mi].raw], key, { [d0.id]: a.id, [d1.id]: b.id }, `${a.label} / ${b.label}`));
      });
      const vals = data.map((d) => d.value[2]).filter((v) => v != null);
      return Object.assign(base, {
        grid: Object.assign({}, grid, { bottom: 56 }),
        tooltip: Object.assign({}, tooltip, { trigger: "item", formatter: (q) => `${xs[q.value[0]]} / ${ys[q.value[1]]}<br><b>${num(q.value[2])}</b>` }),
        xAxis: catAxis(xs, { splitArea: { show: true } }),
        yAxis: { type: "category", data: ys, splitArea: { show: true }, axisLabel: { color: p.textColor } },
        visualMap: { min: Math.min(...vals), max: Math.max(...vals), calculable: true, orient: "horizontal", left: "center", bottom: 0, inRange: { color: [p.colorLow, p.colorHigh] }, formatter: (v) => SacKit.formatNumber(v, Object.assign({}, fmt, { decimals: 0 })) },
        series: [{ type: "heatmap", name: ms[mi].label, data, label: { show: !!p.showDataLabels, formatter: (q) => num(q.value[2]) }, emphasis: { itemStyle: { shadowBlur: 8, shadowColor: "rgba(0,0,0,.3)" } } }],
      });
    }

    if (type === "scatter") {
      if (ms.length < 2) return { __error: "Scatter needs at least two measures (x, y; optional 3rd = bubble size)." };
      const d0 = parsed.dims[0];
      const sizes = parsed.rows.map((r) => (r.values[2] ? Math.abs(r.values[2].raw || 0) : 0));
      const maxSize = Math.max(...sizes, 1);
      const groups = new Map();
      parsed.rows.forEach((r, i) => {
        const g = parsed.dims[1] ? r.dims[1].label : ms[1].label;
        if (!groups.has(g)) groups.set(g, []);
        const sel = d0 ? SacKit.rowSelection(parsed, r) : null;
        const label = r.dims.map((d) => d.label).join(" / ");
        groups.get(g).push(Object.assign(item([r.values[0].raw, r.values[1].raw, sizes[i]], r.dims.map((d) => d.id).join("|") || `#${i}`, sel, label), { name: label }));
      });
      return Object.assign(base, {
        grid,
        tooltip: Object.assign({}, tooltip, { trigger: "item", formatter: (q) => `<b>${SacKit.escapeHtml(q.name)}</b><br>${ms[0].label}: ${num(q.value[0])}<br>${ms[1].label}: ${num(q.value[1])}${ms[2] ? `<br>${ms[2].label}: ${num(q.value[2])}` : ""}` }),
        xAxis: valueAxis({ name: ms[0].label, nameLocation: "middle", nameGap: 26 }),
        yAxis: valueAxis({ name: ms[1].label }),
        series: [...groups.entries()].map(([name, data]) => ({ name, type: "scatter", data, symbolSize: (v) => (ms[2] ? 8 + 40 * Math.sqrt(v[2] / maxSize) : 12), label: { show: !!p.showDataLabels, formatter: "{b}", position: "top" } })),
      });
    }

    if (type === "treemap" || type === "sunburst" || type === "tree") {
      const roots = this._hierarchy(parsed, mi);
      const mark = (n) => {
        n.itemStyle = Object.assign({}, n.itemStyle, { opacity: isSel(n.__key) ? 1 : 0.35 });
        (n.children || []).forEach(mark);
      };
      roots.forEach(mark);
      if (type === "tree")
        return Object.assign(base, {
          tooltip: Object.assign({}, tooltip, { trigger: "item", formatter: (q) => `${SacKit.escapeHtml(q.name)}${q.value != null ? `: <b>${num(q.value)}</b>` : ""}` }),
          series: [{ type: "tree", data: roots.length === 1 ? roots : [{ name: parsed.dims[0] ? parsed.dims[0].label : "All", children: roots }], top: top, left: "12%", bottom: 10, right: "18%", symbolSize: 9, initialTreeDepth: 3, expandAndCollapse: true, label: { position: "left", verticalAlign: "middle", align: "right", color: p.textColor }, leaves: { label: { position: "right", align: "left" } } }],
        });
      return Object.assign(base, {
        tooltip: Object.assign({}, tooltip, { trigger: "item", formatter: (q) => `${SacKit.escapeHtml((q.treePathInfo || []).slice(1).map((x) => x.name).join(" › ") || q.name)}: <b>${num(q.value)}</b>` }),
        series: [
          type === "treemap"
            ? { type: "treemap", data: roots, top: top, bottom: 8, left: 8, right: 8, roam: false, nodeClick: false, breadcrumb: { show: false }, leafDepth: null, label: { show: true, formatter: (q) => `${q.name}\n${num(q.value)}` }, upperLabel: { show: true, height: 20, color: "#fff" }, levels: [{ itemStyle: { borderWidth: 2, gapWidth: 2 } }, { itemStyle: { gapWidth: 1 }, colorSaturation: [0.35, 0.6] }] }
            : { type: "sunburst", data: roots, radius: ["12%", "90%"], center: ["50%", "55%"], nodeClick: false, label: { rotate: "radial", color: "#fff", minAngle: 8 }, emphasis: { focus: "ancestor" } },
        ],
      });
    }

    if (type === "sankey") {
      const nodes = new Map();
      const links = new Map();
      const node = (key, label, sel) => {
        if (!nodes.has(key)) nodes.set(key, { name: key, __label: label, __key: key, __sel: sel, itemStyle: { opacity: isSel(key) ? 1 : 0.35 } });
        return key;
      };
      const d0 = parsed.dims[0];
      if (parsed.dims.length >= 2) {
        const d1 = parsed.dims[1];
        parsed.rows.forEach((r) => {
          const a = r.dims[0];
          const b = r.dims[1];
          const s = node(`0:${a.id}`, a.label, { [d0.id]: a.id });
          const t = node(`1:${b.id}`, b.label, { [d1.id]: b.id });
          const k = `${s}>${t}`;
          const v = Math.abs(r.values[mi].raw || 0);
          if (!links.has(k)) links.set(k, { source: s, target: t, value: 0, __key: k, __sel: { [d0.id]: a.id, [d1.id]: b.id } });
          links.get(k).value += v;
        });
      } else if (d0 && parsed.rows.some((r) => r.dims[0].parentId)) {
        const ids = new Set(parsed.rows.map((r) => r.dims[0].id));
        parsed.rows.forEach((r) => {
          const d = r.dims[0];
          node(d.id, d.label, { [d0.id]: d.id });
          if (d.parentId && ids.has(d.parentId)) links.set(`${d.parentId}>${d.id}`, { source: d.parentId, target: d.id, value: Math.abs(r.values[mi].raw || 0), __key: d.id, __sel: { [d0.id]: d.id } });
        });
      } else return { __error: "Sankey needs two dimensions (source → target) or a hierarchy." };
      return Object.assign(base, {
        tooltip: Object.assign({}, tooltip, { trigger: "item", formatter: (q) => (q.dataType === "edge" ? `${SacKit.escapeHtml(nodes.get(q.data.source).__label)} → ${SacKit.escapeHtml(nodes.get(q.data.target).__label)}: <b>${num(q.data.value)}</b>` : `${SacKit.escapeHtml(q.data.__label)}: <b>${num(q.value)}</b>`) }),
        series: [{ type: "sankey", top: top, bottom: 10, left: 10, right: 90, orient: p.sankeyOrient || "horizontal", emphasis: { focus: "adjacency" }, nodeGap: 10, data: [...nodes.values()], links: [...links.values()], lineStyle: { color: "source", curveness: 0.5, opacity: 0.35 }, label: { formatter: (q) => q.data.__label, color: p.textColor } }],
      });
    }
    return { __error: `Unknown chart type '${type}'.` };
  }

  // ---------------------------------------------------------------- render
  _render() {
    if (!this.isConnected) return;
    const p = this._props;
    this._el.toolbar.classList.toggle("off", !p.showToolbar);
    const parsed = SacKit.parseDataBinding(this._binding());
    this._parsed = parsed;
    if (parsed.state !== "success") return this._message(parsed.state === "loading" ? "Loading…" : "Bind data in the Builder panel: dimension(s) and measure(s).");
    if (!parsed.measures.length) return this._message("Add at least one measure.");
    if (!parsed.rows.length) return this._message("No data for the current filters.");
    let option = this._option(parsed);
    if (option.__error) return this._message(option.__error);
    if (p.optionOverride && String(p.optionOverride).trim()) {
      try {
        option = deepMerge(option, JSON.parse(p.optionOverride));
      } catch (e) {
        console.warn(`[${WIDGET_NAME}] optionOverride is not valid JSON — ignored`, e.message);
      }
    }
    this._el.msg.classList.remove("on");
    if (this._chart && this._renderer !== (p.renderer || "canvas")) {
      this._chart.dispose();
      this._chart = null;
    }
    if (!this._chart) {
      this._renderer = p.renderer || "canvas";
      this._chart = echarts.init(this._el.chart, null, { renderer: this._renderer });
      this._chart.on("click", (params) => this._onClick(params));
      this._chart.getZr().on("click", (e) => {
        if (!e.target && this._selected.size) this._clearSelection(true);
      });
      this._chart.on("finished", () => SacKit.renderComplete(this));
    }
    this._chart.setOption(option, true);
    this._chart.resize();
  }

  _onClick(params) {
    const d = params.data || {};
    const key = d.__key;
    if (!key) return;
    const additive = this._props.multiSelect || (params.event && params.event.event && (params.event.event.ctrlKey || params.event.event.metaKey || params.event.event.shiftKey));
    if (additive) {
      if (this._selected.has(key)) this._selected.delete(key);
      else this._selected.set(key, { sel: d.__sel, label: d.__label || params.name });
    } else if (this._selected.size === 1 && this._selected.has(key)) this._selected.clear();
    else {
      this._selected.clear();
      this._selected.set(key, { sel: d.__sel, label: d.__label || params.name });
    }
    this._render();
    this._publish(true);
  }

  _clearSelection(byUser) {
    const had = this._selected.size > 0;
    this._selected.clear();
    this._render();
    if (had || !byUser) this._publish(byUser);
  }

  async _publish(byUser) {
    const p = this._props;
    const la = SacKit.linkedAnalysis(this, BINDING_ID, p);
    const entries = [...this._selected.values()];
    if (!entries.length) {
      if (p.enableLinkedAnalysis) await la.removeFilters();
      SacKit.dispatchProps(this, { selectedMemberId: "", selectedMemberLabel: "", selectedDimensionId: "", selectedRowJson: "" });
      if (byUser) SacKit.fireEvent(this, "onClear");
      return;
    }
    const sels = [];
    entries.forEach((e) => {
      if (Array.isArray(e.sel)) sels.push(...e.sel);
      else if (e.sel && Object.keys(e.sel).length) sels.push(e.sel);
    });
    if (p.enableLinkedAnalysis) {
      if (sels.length) await la.setFilters(sels.length === 1 ? sels[0] : sels);
      else await la.removeFilters();
    }
    SacKit.dispatchProps(this, {
      selectedMemberId: sels.map((s) => Object.values(s).join("|")).join(","),
      selectedMemberLabel: entries.map((e) => e.label).join(", "),
      selectedDimensionId: this._parsed && this._parsed.dims[0] ? this._parsed.dims[0].id : "",
      selectedRowJson: JSON.stringify(sels),
    });
    if (byUser) SacKit.fireEvent(this, "onSelect");
  }

  // ---------------------------------------------------------------- export
  /** SAC story export (PDF / PowerPoint / Google Slides), Developer Guide ch. 9: returns the chart as a Base64 PNG. */
  async serializeCustomWidgetToImage() {
    const p = this._props;
    const bg = p.backgroundColor && p.backgroundColor !== "transparent" ? p.backgroundColor : "#FFFFFF";
    try {
      if (this._chart) return this._chart.getDataURL({ type: "png", pixelRatio: 2, backgroundColor: bg });
    } catch (e) {
      console.warn("[UniversalChart] export image failed", e);
    }
    return SacKit.blankPngDataUrl(this.clientWidth, this.clientHeight, bg);
  }

  async exportAs(format, fileName) {
    const p = this._props;
    const parsed = this._parsed;
    if (!parsed || parsed.state !== "success") return false;
    const base = `${SacKit.sanitizeFileName(fileName || p.exportFileName || p.widgetName || "Chart", "Chart")}_${SacKit.fileStamp()}`;
    const fmt = String(format || "png").toLowerCase();
    try {
      if (fmt === "png") {
        if (!this._chart) return false;
        const url = this._chart.getDataURL({ type: "png", pixelRatio: 2, backgroundColor: p.backgroundColor && p.backgroundColor !== "transparent" ? p.backgroundColor : "#FFFFFF" });
        const blob = await (await fetch(url)).blob();
        SacKit.download(blob, `${base}.png`);
        return true;
      }
      const header = [...parsed.dims.map((d) => d.label), ...parsed.dims.map((d) => `${d.label} ID`), ...parsed.measures.map((m) => m.label)];
      const rows = parsed.rows.map((r) => [...r.dims.map((d) => d.label), ...r.dims.map((d) => SacKit.plainMemberId(d.id)), ...r.values.map((v) => v.raw)]);
      if (fmt === "csv") {
        SacKit.download(new Blob([SacKit.toCsv([header, ...rows], ",")], { type: "text/csv;charset=utf-8" }), `${base}.csv`);
        return true;
      }
      const all = [];
      parsed.rows.forEach((r) => r.values.forEach((v) => v.raw != null && all.push(v.raw)));
      const numFmt = SacKit.excelNumFmt(this._fmt(all), { redNegatives: true });
      const wb = new XlsxLite.Workbook({ title: p.chartTitle || "Chart data", creator: `${WIDGET_NAME} ${WIDGET_VERSION}` });
      const ws = wb.addSheet("Data", { frozenRows: 1, autoFilter: `A1:${XlsxLite.colName(header.length - 1)}${rows.length + 1}` });
      header.forEach((h, c) => ws.set(0, c, h, { bold: true, fill: "#EFF1F2", border: "bottom" }));
      rows.forEach((r, i) => r.forEach((v, c) => ws.set(i + 1, c, v, c >= parsed.dims.length * 2 ? { numFmt } : null)));
      ws.opts.colWidths = header.map((h, c) => (c < parsed.dims.length * 2 ? XlsxLite.fitWidth(rows.map((r) => r[c]).concat([h]), 12, 50) : 16));
      SacKit.download(await wb.toBlob(), `${base}.xlsx`);
      return true;
    } catch (e) {
      console.error(`[${WIDGET_NAME}] export failed`, e);
      return false;
    }
  }
}

UniversalChart.version = WIDGET_VERSION;
if (!customElements.get(WIDGET_TAG)) customElements.define(WIDGET_TAG, UniversalChart);
