/* ==========================================================================
 * SacKit — shared runtime helpers for SAP Analytics Cloud custom widgets
 * (data binding parsing, number formatting, linked analysis, export utils)
 * Bundled into every widget file by tools/build.py — no globals are leaked.
 * ========================================================================== */
const SacKit = (() => {
  "use strict";

  const norm = (s) => String(s == null ? "" : s).trim().toLowerCase();

  /** Split "A, B; C\nD" into ["A","B","C","D"]. Arrays are passed through. */
  function parseList(value) {
    if (Array.isArray(value)) return value.map((v) => String(v).trim()).filter(Boolean);
    return String(value == null ? "" : value)
      .split(/[,;\n]/)
      .map((t) => t.trim())
      .filter(Boolean);
  }

  /** "[Dim].[Hier].&[SA2]" -> "SA2"; plain ids are returned unchanged. */
  function plainMemberId(id) {
    if (id == null) return "";
    const s = String(id);
    const amp = s.match(/&\[([^\]]*)\]\s*$/);
    if (amp) return amp[1];
    if (s.startsWith("[")) {
      const last = s.match(/\[([^\]]*)\]\s*$/);
      if (last) return last[1];
    }
    return s;
  }

  /** Build a matcher for a user-entered member list (ids, unique names or labels). */
  function memberMatcher(listValue) {
    const set = new Set(parseList(listValue).map(norm));
    return (id, label) =>
      set.size > 0 && (set.has(norm(id)) || set.has(norm(plainMemberId(id))) || set.has(norm(label)));
  }

  const feedIndex = (key) => {
    const m = String(key).match(/_(\d+)$/);
    return m ? Number(m[1]) : 0;
  };

  /**
   * Normalise the SAC data binding result set.
   * SAC delivers: binding.state ('success' | ...), binding.data (rows), binding.metadata
   *   metadata.dimensions          { dimensions_0: { id, description, ... }, ... }
   *   metadata.mainStructureMembers{ measures_0:   { id, label, ... }, ... }
   *   row.dimensions_0 = { id, label, parentId? }   row.measures_0 = { raw, formatted }
   */
  function parseDataBinding(binding) {
    if (!binding || typeof binding !== "object") return { state: "empty", dims: [], measures: [], rows: [] };
    const state = binding.state || (Array.isArray(binding.data) ? "success" : "empty");
    const md = binding.metadata || {};
    const dimMap = md.dimensions || {};
    const meaMap = md.mainStructureMembers || {};
    const dims = Object.keys(dimMap)
      .map((key) => {
        const d = dimMap[key] || {};
        return { key, id: String(d.id != null ? d.id : key), label: String(d.description || d.label || d.id || key) };
      })
      .sort((a, b) => feedIndex(a.key) - feedIndex(b.key));
    const measures = Object.keys(meaMap)
      .map((key) => {
        const m = meaMap[key] || {};
        return {
          key,
          id: String(m.id != null ? m.id : key),
          label: String(m.label || m.description || m.id || key),
          unit: String(m.unitOfMeasure || m.unit || m.currency || ""),
        };
      })
      .sort((a, b) => feedIndex(a.key) - feedIndex(b.key));
    const data = Array.isArray(binding.data) ? binding.data : [];
    const rows = data.map((r, index) => ({
      index,
      dims: dims.map((d) => {
        const c = (r && r[d.key]) || {};
        const id = c.id != null ? String(c.id) : "";
        return {
          id,
          label: c.label != null && c.label !== "" ? String(c.label) : id,
          parentId: c.parentId != null && c.parentId !== "" ? String(c.parentId) : "",
        };
      }),
      values: measures.map((m) => {
        const c = (r && r[m.key]) || {};
        let raw = null;
        if (typeof c.raw === "number" && isFinite(c.raw)) raw = c.raw;
        else if (c.raw != null && c.raw !== "" && isFinite(Number(c.raw))) raw = Number(c.raw);
        return { raw, formatted: c.formatted != null ? String(c.formatted) : "", unit: String(c.unit || "") };
      }),
    }));
    // BW Live can send parentId on one occurrence of a member and omit it on repeated rows (e.g. when a period
    // dimension is also bound). Build one parent map per dimension and fill the gaps, so trees and subtotals
    // don't depend on row order.
    dims.forEach((d, i) => {
      const parentOf = new Map();
      rows.forEach((r) => {
        const c = r.dims[i];
        if (c.id && c.parentId && !parentOf.has(c.id)) parentOf.set(c.id, c.parentId);
      });
      if (parentOf.size) rows.forEach((r) => {
        const c = r.dims[i];
        if (c.id && !c.parentId && parentOf.has(c.id)) c.parentId = parentOf.get(c.id);
      });
    });
    return { state, dims, measures, rows };
  }

  /** Selection object for linked analysis: { <dimensionId>: <memberId>, ... } */
  function rowSelection(parsed, row, dimCount) {
    const sel = {};
    const n = dimCount == null ? parsed.dims.length : Math.min(dimCount, parsed.dims.length);
    for (let i = 0; i < n; i++) {
      const cell = row.dims[i];
      if (cell && cell.id !== "") sel[parsed.dims[i].id] = cell.id;
    }
    return sel;
  }

  // ------------------------------------------------------------------ numbers
  const SCALE_FACTORS = { none: 1, K: 1e3, M: 1e6, B: 1e9 };

  function autoScale(maxAbs) {
    const a = Math.abs(maxAbs || 0);
    if (a >= 1e9) return "B";
    if (a >= 1e6) return "M";
    if (a >= 1e4) return "K";
    return "none";
  }

  /** Pick K/M/B so that the median non-zero magnitude shows at least one significant integer digit. */
  function autoScaleFor(values) {
    const mags = (values || []).map((v) => Math.abs(Number(v) || 0)).filter((v) => v > 0).sort((a, b) => a - b);
    if (!mags.length) return "none";
    const median = mags[Math.floor(mags.length / 2)];
    for (const s of ["B", "M", "K"]) if (median / SCALE_FACTORS[s] >= 1) return s;
    return "none";
  }

  /**
   * fmt = { scale: 'none'|'K'|'M'|'B', decimals, prefix, suffix, plusSign,
   *         negativeStyle: 'minus'|'parentheses', locale, symbols: {K,M,B}, percent }
   */
  function formatNumber(value, fmt) {
    if (value == null || !isFinite(value)) return "–";
    const f = fmt || {};
    const decimals = Math.max(0, Math.min(10, Number(f.decimals) || 0));
    if (f.percent) {
      const pct = new Intl.NumberFormat(f.locale || undefined, {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
      }).format(Math.abs(value * 100));
      const sign = value < 0 ? (f.negativeStyle === "parentheses" ? "" : "−") : f.plusSign && value > 0 ? "+" : "";
      const body = `${sign}${pct}%`;
      return value < 0 && f.negativeStyle === "parentheses" ? `(${body})` : body;
    }
    const scale = SCALE_FACTORS[f.scale] ? f.scale : "none";
    const scaled = Math.abs(value) / SCALE_FACTORS[scale];
    let num;
    try {
      num = new Intl.NumberFormat(f.locale || undefined, {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
      }).format(scaled);
    } catch (e) {
      num = scaled.toFixed(decimals);
    }
    const symbols = f.symbols || {};
    const sym = scale === "none" ? "" : symbols[scale] != null ? symbols[scale] : scale;
    const isZero = Number(num.replace(/[^0-9]/g, "")) === 0;
    const body = `${f.prefix || ""}${num}${sym}${f.suffix || ""}`;
    if (value < 0 && !isZero) return f.negativeStyle === "parentheses" ? `(${body})` : `−${body}`;
    if (value > 0 && f.plusSign && !isZero) return `+${body}`;
    return body;
  }

  /** Excel number format equivalent to formatNumber (values stay true numbers in Excel). */
  function excelNumFmt(fmt, opts) {
    const f = fmt || {};
    const o = opts || {};
    const decimals = Math.max(0, Math.min(10, Number(f.decimals) || 0));
    const q = (s) => (s ? `"${String(s).replace(/"/g, "")}"` : "");
    const base = "#,##0" + (decimals > 0 ? "." + "0".repeat(decimals) : "");
    if (f.percent) {
      const p = base + "%";
      const neg = f.negativeStyle === "parentheses" ? `(${p})` : `-${p}`;
      return `${f.plusSign ? "+" : ""}${p};${o.redNegatives ? "[Red]" : ""}${neg};${p}`;
    }
    const scale = SCALE_FACTORS[f.scale] ? f.scale : "none";
    const commas = { none: "", K: ",", M: ",,", B: ",,," }[scale];
    const symbols = f.symbols || {};
    const sym = scale === "none" ? "" : q(symbols[scale] != null ? symbols[scale] : scale);
    const core = `${q(f.prefix)}${base}${commas}${sym}${q(f.suffix)}`;
    const pos = `${f.plusSign ? "+" : ""}${core}`;
    const neg = f.negativeStyle === "parentheses" ? `(${core})` : `-${core}`;
    const posColor = o.greenPositives ? "[Color10]" : "";
    return `${posColor}${pos};${o.redNegatives ? "[Red]" : ""}${neg};${core}`;
  }

  function parseSymbols(s) {
    const parts = parseList(s);
    return { K: parts[0] != null ? parts[0] : "K", M: parts[1] != null ? parts[1] : "M", B: parts[2] != null ? parts[2] : "B" };
  }

  /** "nice" axis ticks */
  function niceTicks(min, max, count) {
    if (!isFinite(min) || !isFinite(max)) return { min: 0, max: 1, step: 1, ticks: [0, 1] };
    if (min === max) {
      const pad = Math.abs(min) * 0.1 || 1;
      min -= pad;
      max += pad;
    }
    const niceNum = (range, round) => {
      const exp = Math.floor(Math.log10(range));
      const frac = range / Math.pow(10, exp);
      let nf;
      if (round) nf = frac < 1.5 ? 1 : frac < 3 ? 2 : frac < 7 ? 5 : 10;
      else nf = frac <= 1 ? 1 : frac <= 2 ? 2 : frac <= 5 ? 5 : 10;
      return nf * Math.pow(10, exp);
    };
    const range = niceNum(max - min, false);
    const step = niceNum(range / Math.max(1, (count || 5) - 1), true);
    const nMin = Math.floor(min / step) * step;
    const nMax = Math.ceil(max / step) * step;
    const ticks = [];
    for (let v = nMin; v <= nMax + step * 0.5; v += step) ticks.push(Math.abs(v) < step * 1e-9 ? 0 : v);
    return { min: nMin, max: nMax, step, ticks };
  }

  // -------------------------------------------------------------- text & DOM
  const escapeHtml = (s) =>
    String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");

  let _measureCtx = null;
  function measureText(text, font) {
    if (!_measureCtx) {
      try {
        _measureCtx = document.createElement("canvas").getContext("2d");
      } catch (e) {
        _measureCtx = null;
      }
    }
    if (!_measureCtx) return String(text).length * 7;
    _measureCtx.font = font;
    return _measureCtx.measureText(String(text)).width;
  }

  /** Greedy word wrap; returns at most maxLines lines (last line ellipsised). */
  function wrapText(text, maxWidth, font, maxLines) {
    const words = String(text == null ? "" : text).split(/\s+/).filter(Boolean);
    const lines = [];
    let line = "";
    const fits = (t) => measureText(t, font) <= maxWidth;
    for (let i = 0; i < words.length; i++) {
      const candidate = line ? `${line} ${words[i]}` : words[i];
      if (fits(candidate) || !line) {
        line = candidate;
      } else {
        lines.push(line);
        line = words[i];
      }
    }
    if (line) lines.push(line);
    const limit = Math.max(1, maxLines || 1);
    const out = lines.slice(0, limit);
    const truncated = lines.length > limit;
    for (let i = 0; i < out.length; i++) {
      const isLast = i === out.length - 1;
      let t = out[i];
      if (!fits(t) || (isLast && truncated)) {
        while (t.length > 1 && !fits(t + "…")) t = t.slice(0, -1);
        out[i] = t + "…";
      }
    }
    return out.length ? out : [""];
  }

  function truncateText(text, maxWidth, font) {
    let t = String(text == null ? "" : text);
    if (measureText(t, font) <= maxWidth) return t;
    while (t.length > 1 && measureText(t + "…", font) > maxWidth) t = t.slice(0, -1);
    return t + "…";
  }

  function sanitizeFileName(name, fallback) {
    const s = String(name == null ? "" : name)
      .replace(/[\\/:*?"<>|]+/g, "_")
      .replace(/\s+/g, "_")
      .slice(0, 120);
    return s || fallback || "export";
  }

  function stamp(d) {
    const x = d || new Date();
    const p = (n) => String(n).padStart(2, "0");
    return `${x.getFullYear()}-${p(x.getMonth() + 1)}-${p(x.getDate())} ${p(x.getHours())}:${p(x.getMinutes())}`;
  }

  function fileStamp(d) {
    return stamp(d).replace(/[-: ]/g, "").slice(0, 12);
  }

  /** Trigger a browser download. Works inside shadow DOM (anchor is attached to document.body). */
  function download(blob, fileName) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    a.rel = "noopener";
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      URL.revokeObjectURL(url);
      a.remove();
    }, 1500);
  }

  async function copyText(text) {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (e) {
      /* fall through to legacy path */
    }
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      return ok;
    } catch (e) {
      return false;
    }
  }

  /**
   * Removes floating-point noise before a number leaves the widget (Excel, CSV, clipboard):
   * 9600000.000000002 − 9500000 → 100000, 0.1 + 0.2 → 0.3, 41000000.00000001 − 41000000 → 0.
   * Values below 1e9 are rounded to 6 decimals, larger values to 15 significant digits.
   */
  function cleanNumber(v) {
    if (typeof v !== "number" || !isFinite(v)) return v;
    if (Math.abs(v) < 1e9) {
      const r = Math.round(v * 1e6) / 1e6;
      return r === 0 ? 0 : r;
    }
    return Number(v.toPrecision(15));
  }

  function csvEscape(v, delim, decimalComma) {
    if (v == null) return "";
    let s;
    if (typeof v === "number") {
      if (!isFinite(v)) return "";
      s = String(cleanNumber(v));
      if (decimalComma) s = s.replace(".", ",");
    } else s = String(v);
    return /["\r\n]/.test(s) || s.includes(delim) ? `"${s.replace(/"/g, '""')}"` : s;
  }

  /** CSV with BOM. With ";" as delimiter numbers use a decimal comma (Excel convention in decimal-comma locales). */
  function toCsv(rows, delim, opts) {
    const d = delim || ",";
    const decimalComma = opts && opts.decimalComma != null ? !!opts.decimalComma : d === ";";
    return "\ufeff" + rows.map((r) => r.map((v) => csvEscape(v, d, decimalComma)).join(d)).join("\r\n");
  }

  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(String(r.result));
      r.onerror = () => reject(r.error);
      r.readAsDataURL(blob);
    });
  }

  /** White PNG of the given size, used when a widget has nothing to draw yet (story export placeholder). */
  function blankPngDataUrl(width, height, background) {
    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(width || 1));
    c.height = Math.max(1, Math.round(height || 1));
    const ctx = c.getContext("2d");
    ctx.fillStyle = background || "#FFFFFF";
    ctx.fillRect(0, 0, c.width, c.height);
    return c.toDataURL("image/png");
  }

  /** Render an <svg> string to a PNG blob (2x for crisp output). */
  function svgStringToPngBlob(svgString, width, height, scale, background) {
    return new Promise((resolve, reject) => {
      const s = scale || 2;
      const img = new Image();
      const url = URL.createObjectURL(new Blob([svgString], { type: "image/svg+xml;charset=utf-8" }));
      img.onload = () => {
        try {
          const canvas = document.createElement("canvas");
          canvas.width = Math.ceil(width * s);
          canvas.height = Math.ceil(height * s);
          const ctx = canvas.getContext("2d");
          ctx.fillStyle = background || "#FFFFFF";
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.scale(s, s);
          ctx.drawImage(img, 0, 0, width, height);
          URL.revokeObjectURL(url);
          canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("PNG encoding failed"))), "image/png");
        } catch (e) {
          URL.revokeObjectURL(url);
          reject(e);
        }
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error("SVG could not be rasterised"));
      };
      img.src = url;
    });
  }

  // ------------------------------------------------------ SAC framework glue
  /** Notify SAC that widget properties changed (persisted + visible to scripts). */
  // The Developer Guide (Best Practices 14.1) says not to dispatch propertiesChanged inside the constructor,
  // onCustomWidgetBeforeUpdate/AfterUpdate/Destroy or connected/disconnectedCallback (endless-loop risk).
  // Widgets publish outputs from render paths too (KPI status, selections cleared by script), so every
  // property change and event is queued and dispatched right after the current call stack, in order:
  // properties first, then the event that announces them.
  const _outbox = [];
  let _flushScheduled = false;
  function _enqueue(fn) {
    _outbox.push(fn);
    if (_flushScheduled) return;
    _flushScheduled = true;
    setTimeout(() => {
      _flushScheduled = false;
      const batch = _outbox.splice(0);
      batch.forEach((f) => {
        try {
          f();
        } catch (e) {
          console.warn("[SacKit] dispatch failed", e);
        }
      });
    }, 0);
  }

  function dispatchProps(el, properties) {
    _enqueue(() => el.dispatchEvent(new CustomEvent("propertiesChanged", { detail: { properties } })));
  }

  /** Fire a widget event declared in the JSON "events" section (e.g. onSelect), after pending property changes. */
  function fireEvent(el, name) {
    _enqueue(() => el.dispatchEvent(new Event(name)));
  }

  /**
   * Robust access to the Data Binding linked-analysis API:
   *   dataBinding.getLinkedAnalysis().setFilters(selection | selection[])
   *   dataBinding.getLinkedAnalysis().removeFilters()
   *   dataBinding.getLinkedAnalysis().isDataPointSelectionEnabled()
   * Works whether SAC returns objects or promises (script API calls from web
   * components can be asynchronous) and never throws into the render loop.
   */
  function linkedAnalysis(widget, bindingId, props) {
    const resolveBinding = () => {
      const dbs = (props && props.dataBindings) || widget.dataBindings;
      if (!dbs || typeof dbs.getDataBinding !== "function") return null;
      try {
        return dbs.getDataBinding(bindingId);
      } catch (e) {
        return null;
      }
    };
    const getLA = async () => {
      const binding = await Promise.resolve(resolveBinding());
      if (!binding || typeof binding.getLinkedAnalysis !== "function") return null;
      return Promise.resolve(binding.getLinkedAnalysis());
    };
    return {
      async isEnabled() {
        try {
          const la = await getLA();
          if (!la) return false;
          if (typeof la.isDataPointSelectionEnabled !== "function") return true;
          return (await Promise.resolve(la.isDataPointSelectionEnabled())) !== false;
        } catch (e) {
          return false;
        }
      },
      async setFilters(selection) {
        try {
          const la = await getLA();
          if (!la || typeof la.setFilters !== "function") return false;
          if (typeof la.isDataPointSelectionEnabled === "function") {
            const on = await Promise.resolve(la.isDataPointSelectionEnabled());
            if (on === false) return false;
          }
          await Promise.resolve(la.setFilters(selection));
          return true;
        } catch (e) {
          console.warn("[SacKit] linked analysis setFilters failed", e);
          return false;
        }
      },
      async removeFilters() {
        try {
          const la = await getLA();
          if (!la || typeof la.removeFilters !== "function") return false;
          await Promise.resolve(la.removeFilters());
          return true;
        } catch (e) {
          console.warn("[SacKit] linked analysis removeFilters failed", e);
          return false;
        }
      },
    };
  }

  /** Tell the SAC export / viewport framework that rendering finished. */
  function renderComplete(el) {
    try {
      el.dispatchEvent(new Event("customWidgetRenderComplete"));
    } catch (e) {
      /* ignore */
    }
  }

  return {
    norm,
    parseList,
    plainMemberId,
    memberMatcher,
    parseDataBinding,
    rowSelection,
    autoScale,
    autoScaleFor,
    formatNumber,
    excelNumFmt,
    parseSymbols,
    niceTicks,
    escapeHtml,
    measureText,
    wrapText,
    truncateText,
    sanitizeFileName,
    stamp,
    fileStamp,
    download,
    copyText,
    toCsv,
    cleanNumber,
    svgStringToPngBlob,
    blobToDataUrl,
    blankPngDataUrl,
    dispatchProps,
    fireEvent,
    linkedAnalysis,
    renderComplete,
  };
})();
