/* ==========================================================================
 * XlsxLite — dependency-free XLSX (Office Open XML) writer for the browser.
 * Features: multiple sheets, numbers / strings / booleans, cell styles
 * (font, fill, border, number format, alignment + indent + wrap), merged
 * cells, column widths, frozen panes, autofilter, row outline levels
 * (Excel grouping, e.g. for hierarchies), hidden rows, row heights.
 * Zip container: DEFLATE via CompressionStream('deflate-raw') when the
 * browser supports it, otherwise STORE — both are valid .xlsx files.
 * ========================================================================== */
const XlsxLite = (() => {
  "use strict";
  const enc = new TextEncoder();

  const CRC_TABLE = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  })();

  /** Floating-point noise removal (same rule as SacKit.cleanNumber, kept local so xlsx-lite has no dependency). */
  function cleanNum(v) {
    if (Math.abs(v) < 1e9) {
      const r = Math.round(v * 1e6) / 1e6;
      return r === 0 ? 0 : r;
    }
    return Number(v.toPrecision(15));
  }

  function crc32(bytes) {
    let c = 0xffffffff;
    for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  }

  const xmlEsc = (s) =>
    String(s == null ? "" : s)
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F￾￿]/g, "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");

  function colName(c) {
    let s = "";
    let n = c + 1;
    while (n > 0) {
      const m = (n - 1) % 26;
      s = String.fromCharCode(65 + m) + s;
      n = Math.floor((n - 1) / 26);
    }
    return s;
  }
  const cellRef = (r, c) => colName(c) + (r + 1);

  function argb(color) {
    if (!color) return null;
    let s = String(color).trim().replace(/^#/, "");
    if (/^[0-9a-f]{3}$/i.test(s)) s = s.split("").map((ch) => ch + ch).join("");
    if (/^[0-9a-f]{6}$/i.test(s)) return ("FF" + s).toUpperCase();
    if (/^[0-9a-f]{8}$/i.test(s)) return s.toUpperCase();
    return null;
  }

  // ------------------------------------------------------------ styles
  class StyleRegistry {
    constructor() {
      this.numFmts = new Map(); // code -> id
      this.fonts = ['<font><sz val="11"/><color theme="1"/><name val="Calibri"/><family val="2"/><scheme val="minor"/></font>'];
      this.fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>'];
      this.borders = ["<border><left/><right/><top/><bottom/><diagonal/></border>"];
      this.xfs = ['<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'];
      this.cache = new Map();
    }
    _idx(list, xml) {
      let i = list.indexOf(xml);
      if (i < 0) {
        list.push(xml);
        i = list.length - 1;
      }
      return i;
    }
    _numFmtId(code) {
      if (!code || code === "General") return 0;
      const builtin = { "0": 1, "0.00": 2, "#,##0": 3, "#,##0.00": 4, "0%": 9, "0.00%": 10, "@": 49 };
      if (builtin[code] != null) return builtin[code];
      if (!this.numFmts.has(code)) this.numFmts.set(code, 164 + this.numFmts.size);
      return this.numFmts.get(code);
    }
    /**
     * style = { bold, italic, underline, fontSize, fontColor, fontName, fill,
     *           border: 'thin'|'bottom'|'top'|'topBottom'|'medium-bottom'|..., borderColor,
     *           numFmt, align: 'left'|'center'|'right', valign, indent, wrap }
     */
    id(style) {
      if (!style) return 0;
      const key = JSON.stringify(style);
      if (this.cache.has(key)) return this.cache.get(key);
      const s = style;
      // font
      let fontId = 0;
      if (s.bold || s.italic || s.underline || s.fontSize || s.fontColor || s.fontName) {
        const col = argb(s.fontColor);
        const xml =
          "<font>" +
          (s.bold ? "<b/>" : "") +
          (s.italic ? "<i/>" : "") +
          (s.underline ? "<u/>" : "") +
          `<sz val="${Number(s.fontSize) || 11}"/>` +
          (col ? `<color rgb="${col}"/>` : '<color theme="1"/>') +
          `<name val="${xmlEsc(s.fontName || "Calibri")}"/><family val="2"/>` +
          (s.fontName ? "" : '<scheme val="minor"/>') +
          "</font>";
        fontId = this._idx(this.fonts, xml);
      }
      // fill
      let fillId = 0;
      const fill = argb(s.fill);
      if (fill) {
        fillId = this._idx(
          this.fills,
          `<fill><patternFill patternType="solid"><fgColor rgb="${fill}"/><bgColor indexed="64"/></patternFill></fill>`
        );
      }
      // border
      let borderId = 0;
      if (s.border) {
        const bc = argb(s.borderColor) || "FFBFBFBF";
        const parts = String(s.border).split("-");
        const weight = parts.length > 1 ? parts[0] : "thin";
        const where = parts.length > 1 ? parts[1] : parts[0];
        const side = (name, on) => (on ? `<${name} style="${weight}"><color rgb="${bc}"/></${name}>` : `<${name}/>`);
        const all = where === "thin" || where === "all" || where === "box";
        const top = all || where === "top" || where === "topBottom";
        const bottom = all || where === "bottom" || where === "topBottom";
        const xml = `<border>${side("left", all)}${side("right", all)}${side("top", top)}${side("bottom", bottom)}<diagonal/></border>`;
        borderId = this._idx(this.borders, xml);
      }
      const numFmtId = this._numFmtId(s.numFmt);
      let align = "";
      if (s.align || s.valign || s.indent || s.wrap) {
        align =
          "<alignment" +
          (s.align ? ` horizontal="${s.align}"` : s.indent ? ' horizontal="left"' : "") +
          (s.valign ? ` vertical="${s.valign}"` : "") +
          (s.indent ? ` indent="${Math.min(15, Math.max(0, Math.round(s.indent)))}"` : "") +
          (s.wrap ? ' wrapText="1"' : "") +
          "/>";
      }
      const xf =
        `<xf numFmtId="${numFmtId}" fontId="${fontId}" fillId="${fillId}" borderId="${borderId}" xfId="0"` +
        (numFmtId ? ' applyNumberFormat="1"' : "") +
        (fontId ? ' applyFont="1"' : "") +
        (fillId ? ' applyFill="1"' : "") +
        (borderId ? ' applyBorder="1"' : "") +
        (align ? ' applyAlignment="1">' + align + "</xf>" : "/>");
      const id = this._idx(this.xfs, xf);
      this.cache.set(key, id);
      return id;
    }
    xml() {
      const nf = [...this.numFmts.entries()]
        .map(([code, id]) => `<numFmt numFmtId="${id}" formatCode="${xmlEsc(code)}"/>`)
        .join("");
      return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
        '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
        (this.numFmts.size ? `<numFmts count="${this.numFmts.size}">${nf}</numFmts>` : "") +
        `<fonts count="${this.fonts.length}">${this.fonts.join("")}</fonts>` +
        `<fills count="${this.fills.length}">${this.fills.join("")}</fills>` +
        `<borders count="${this.borders.length}">${this.borders.join("")}</borders>` +
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
        `<cellXfs count="${this.xfs.length}">${this.xfs.join("")}</cellXfs>` +
        '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>' +
        '<dxfs count="0"/><tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/>' +
        "</styleSheet>"
      );
    }
  }

  // ------------------------------------------------------------- sheets
  class Sheet {
    constructor(wb, name, opts) {
      this.wb = wb;
      this.name = Sheet.safeName(name, wb.sheets.length + 1, wb.sheets.map((s) => s.name));
      this.opts = Object.assign(
        { frozenRows: 0, frozenCols: 0, showGridLines: true, autoFilter: null, colWidths: [], outlineSummaryBelow: false, tabColor: null },
        opts || {}
      );
      this.rows = new Map(); // r -> { cells: Map(c -> {v, s, t}), opts }
      this.merges = [];
      this.maxRow = -1;
      this.maxCol = -1;
    }
    static safeName(name, n, existing) {
      let s = String(name || `Sheet${n}`).replace(/[\[\]:*?\/\\]/g, " ").trim().slice(0, 31) || `Sheet${n}`;
      let candidate = s;
      let i = 2;
      while (existing.includes(candidate)) candidate = `${s.slice(0, 28)} (${i++})`;
      return candidate;
    }
    _row(r) {
      if (!this.rows.has(r)) this.rows.set(r, { cells: new Map(), opts: {} });
      return this.rows.get(r);
    }
    /** value: number | string | boolean | null | { f: 'FORMULA', v: cached } */
    set(r, c, value, style) {
      const row = this._row(r);
      row.cells.set(c, { v: value, s: this.wb.styles.id(style) });
      if (r > this.maxRow) this.maxRow = r;
      if (c > this.maxCol) this.maxCol = c;
      return this;
    }
    /** append at next free row; returns row index */
    addRow(values, styles, rowOpts) {
      const r = this.maxRow + 1;
      (values || []).forEach((v, c) => {
        const st = Array.isArray(styles) ? styles[c] : styles;
        if (v !== undefined) this.set(r, c, v, st);
      });
      if (r > this.maxRow) this.maxRow = r;
      if (rowOpts) this.rowOptions(r, rowOpts);
      return r;
    }
    /** { outlineLevel, hidden, collapsed, height } */
    rowOptions(r, o) {
      Object.assign(this._row(r).opts, o);
      if (r > this.maxRow) this.maxRow = r;
      return this;
    }
    merge(r1, c1, r2, c2) {
      this.merges.push(`${cellRef(r1, c1)}:${cellRef(r2, c2)}`);
      return this;
    }
    xml() {
      const o = this.opts;
      const maxOutline = [...this.rows.values()].reduce((m, r) => Math.max(m, r.opts.outlineLevel || 0), 0);
      let x = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
      x +=
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">';
      const tab = argb(o.tabColor);
      if (maxOutline > 0 || tab) {
        x += "<sheetPr>";
        if (tab) x += `<tabColor rgb="${tab}"/>`;
        if (maxOutline > 0) x += `<outlinePr summaryBelow="${o.outlineSummaryBelow ? 1 : 0}" summaryRight="1"/>`;
        x += "</sheetPr>";
      }
      const dimRef = this.maxRow >= 0 && this.maxCol >= 0 ? `A1:${cellRef(this.maxRow, this.maxCol)}` : "A1";
      x += `<dimension ref="${dimRef}"/>`;
      x += `<sheetViews><sheetView workbookViewId="0"${o.showGridLines ? "" : ' showGridLines="0"'}${
        this.wb.sheets[0] === this ? ' tabSelected="1"' : ""
      }>`;
      const fr = o.frozenRows | 0;
      const fc = o.frozenCols | 0;
      if (fr > 0 || fc > 0) {
        const pane = fr > 0 && fc > 0 ? "bottomRight" : fr > 0 ? "bottomLeft" : "topRight";
        x += `<pane${fc > 0 ? ` xSplit="${fc}"` : ""}${fr > 0 ? ` ySplit="${fr}"` : ""} topLeftCell="${cellRef(fr, fc)}" activePane="${pane}" state="frozen"/>`;
        x += `<selection pane="${pane}" activeCell="${cellRef(fr, fc)}" sqref="${cellRef(fr, fc)}"/>`;
      }
      x += "</sheetView></sheetViews>";
      x += `<sheetFormatPr defaultRowHeight="15"${maxOutline > 0 ? ` outlineLevelRow="${maxOutline}"` : ""}/>`;
      if (o.colWidths && o.colWidths.length) {
        x += "<cols>";
        o.colWidths.forEach((w, i) => {
          if (w) x += `<col min="${i + 1}" max="${i + 1}" width="${Math.max(2, Math.min(255, w)).toFixed(2)}" customWidth="1"/>`;
        });
        x += "</cols>";
      }
      x += "<sheetData>";
      const rowIdx = [...this.rows.keys()].sort((a, b) => a - b);
      for (const r of rowIdx) {
        const row = this.rows.get(r);
        const ro = row.opts;
        let attrs = ` r="${r + 1}"`;
        if (ro.height) attrs += ` ht="${ro.height}" customHeight="1"`;
        if (ro.hidden) attrs += ' hidden="1"';
        if (ro.outlineLevel) attrs += ` outlineLevel="${Math.min(7, ro.outlineLevel)}"`;
        if (ro.collapsed) attrs += ' collapsed="1"';
        x += `<row${attrs}>`;
        const cols = [...row.cells.keys()].sort((a, b) => a - b);
        for (const c of cols) {
          const cell = row.cells.get(c);
          const ref = cellRef(r, c);
          const s = cell.s ? ` s="${cell.s}"` : "";
          const v = cell.v;
          if (v == null || v === "") {
            x += `<c r="${ref}"${s}/>`;
          } else if (typeof v === "number") {
            x += isFinite(v) ? `<c r="${ref}"${s}><v>${cleanNum(v)}</v></c>` : `<c r="${ref}"${s}/>`;
          } else if (typeof v === "boolean") {
            x += `<c r="${ref}"${s} t="b"><v>${v ? 1 : 0}</v></c>`;
          } else if (typeof v === "object" && v.f) {
            const cached = v.v;
            const t = typeof cached === "string" ? ' t="str"' : "";
            x += `<c r="${ref}"${s}${t}><f>${xmlEsc(v.f)}</f>${cached != null ? `<v>${xmlEsc(cached)}</v>` : ""}</c>`;
          } else {
            x += `<c r="${ref}"${s} t="inlineStr"><is><t xml:space="preserve">${xmlEsc(v)}</t></is></c>`;
          }
        }
        x += "</row>";
      }
      x += "</sheetData>";
      if (o.autoFilter) x += `<autoFilter ref="${o.autoFilter}"/>`;
      if (this.merges.length) x += `<mergeCells count="${this.merges.length}">${this.merges.map((m) => `<mergeCell ref="${m}"/>`).join("")}</mergeCells>`;
      x += '<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>';
      x += "</worksheet>";
      return x;
    }
  }

  // ------------------------------------------------------------ zip
  async function deflateRaw(bytes) {
    if (typeof CompressionStream === "undefined") return null;
    try {
      const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream("deflate-raw"));
      return new Uint8Array(await new Response(stream).arrayBuffer());
    } catch (e) {
      return null;
    }
  }

  function dosDateTime(d) {
    const time = ((d.getHours() & 31) << 11) | ((d.getMinutes() & 63) << 5) | ((d.getSeconds() / 2) & 31);
    const date = (((d.getFullYear() - 1980) & 127) << 9) | (((d.getMonth() + 1) & 15) << 5) | (d.getDate() & 31);
    return { time, date };
  }

  /** files: [{ name, data: Uint8Array }] -> Uint8Array (zip) */
  async function zip(files, compress) {
    const now = dosDateTime(new Date());
    const chunks = [];
    const central = [];
    let offset = 0;
    for (const f of files) {
      const nameBytes = enc.encode(f.name);
      const crc = crc32(f.data);
      let method = 0;
      let payload = f.data;
      if (compress !== false && f.data.length > 64) {
        const d = await deflateRaw(f.data);
        if (d && d.length < f.data.length) {
          method = 8;
          payload = d;
        }
      }
      const lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true);
      lh.setUint16(4, 20, true);
      lh.setUint16(6, 0x0800, true); // UTF-8 names
      lh.setUint16(8, method, true);
      lh.setUint16(10, now.time, true);
      lh.setUint16(12, now.date, true);
      lh.setUint32(14, crc, true);
      lh.setUint32(18, payload.length, true);
      lh.setUint32(22, f.data.length, true);
      lh.setUint16(26, nameBytes.length, true);
      lh.setUint16(28, 0, true);
      chunks.push(new Uint8Array(lh.buffer), nameBytes, payload);
      const ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true);
      ch.setUint16(4, 20, true);
      ch.setUint16(6, 20, true);
      ch.setUint16(8, 0x0800, true);
      ch.setUint16(10, method, true);
      ch.setUint16(12, now.time, true);
      ch.setUint16(14, now.date, true);
      ch.setUint32(16, crc, true);
      ch.setUint32(20, payload.length, true);
      ch.setUint32(24, f.data.length, true);
      ch.setUint16(28, nameBytes.length, true);
      ch.setUint16(30, 0, true);
      ch.setUint16(32, 0, true);
      ch.setUint16(34, 0, true);
      ch.setUint16(36, 0, true);
      ch.setUint32(38, 0, true);
      ch.setUint32(42, offset, true);
      central.push(new Uint8Array(ch.buffer), nameBytes);
      offset += 30 + nameBytes.length + payload.length;
    }
    const cdSize = central.reduce((n, c) => n + c.length, 0);
    const end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true);
    end.setUint16(4, 0, true);
    end.setUint16(6, 0, true);
    end.setUint16(8, files.length, true);
    end.setUint16(10, files.length, true);
    end.setUint32(12, cdSize, true);
    end.setUint32(16, offset, true);
    end.setUint16(20, 0, true);
    const all = [...chunks, ...central, new Uint8Array(end.buffer)];
    const total = all.reduce((n, c) => n + c.length, 0);
    const out = new Uint8Array(total);
    let p = 0;
    for (const c of all) {
      out.set(c, p);
      p += c.length;
    }
    return out;
  }

  // ------------------------------------------------------------ workbook
  class Workbook {
    constructor(props) {
      this.props = Object.assign({ creator: "SAP Analytics Cloud custom widget", title: "" }, props || {});
      this.styles = new StyleRegistry();
      this.sheets = [];
    }
    addSheet(name, opts) {
      const s = new Sheet(this, name, opts);
      this.sheets.push(s);
      return s;
    }
    _files() {
      const files = [];
      const add = (name, text) => files.push({ name, data: enc.encode(text) });
      const n = this.sheets.length;
      add(
        "[Content_Types].xml",
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
          '<Default Extension="xml" ContentType="application/xml"/>' +
          '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
          this.sheets
            .map(
              (s, i) =>
                `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`
            )
            .join("") +
          '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' +
          '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>' +
          '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>' +
          "</Types>"
      );
      add(
        "_rels/.rels",
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
          '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>' +
          '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>' +
          '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>' +
          "</Relationships>"
      );
      const iso = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
      add(
        "docProps/core.xml",
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' +
          `<dc:title>${xmlEsc(this.props.title)}</dc:title><dc:creator>${xmlEsc(this.props.creator)}</dc:creator>` +
          `<dcterms:created xsi:type="dcterms:W3CDTF">${iso}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${iso}</dcterms:modified>` +
          "</cp:coreProperties>"
      );
      add(
        "docProps/app.xml",
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Microsoft Excel</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop></Properties>'
      );
      const defined = this.sheets
        .map((s, i) =>
          s.opts.autoFilter
            ? `<definedName name="_xlnm._FilterDatabase" localSheetId="${i}" hidden="1">'${s.name.replace(/'/g, "''")}'!${s.opts.autoFilter
                .split(":")
                .map((p) => p.replace(/^([A-Z]+)(\d+)$/, "$$$1$$$2"))
                .join(":")}</definedName>`
            : ""
        )
        .join("");
      add(
        "xl/workbook.xml",
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
          '<workbookPr defaultThemeVersion="164011"/><bookViews><workbookView xWindow="0" yWindow="0" windowWidth="28800" windowHeight="12300" activeTab="0"/></bookViews><sheets>' +
          this.sheets.map((s, i) => `<sheet name="${xmlEsc(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join("") +
          "</sheets>" +
          (defined ? `<definedNames>${defined}</definedNames>` : "") +
          '<calcPr calcId="191029"/></workbook>'
      );
      add(
        "xl/_rels/workbook.xml.rels",
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
          this.sheets
            .map(
              (s, i) =>
                `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`
            )
            .join("") +
          `<Relationship Id="rId${n + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>` +
          "</Relationships>"
      );
      // sheets first so that every style is registered before styles.xml is written
      const sheetXml = this.sheets.map((s) => s.xml());
      sheetXml.forEach((xml, i) => add(`xl/worksheets/sheet${i + 1}.xml`, xml));
      add("xl/styles.xml", this.styles.xml());
      return files;
    }
    async toUint8Array(compress) {
      return zip(this._files(), compress);
    }
    async toBlob(compress) {
      const bytes = await this.toUint8Array(compress);
      return new Blob([bytes], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    }
  }

  /** Approximate Excel column width (characters) for a list of values. */
  function fitWidth(values, min, max) {
    let w = min || 8;
    for (const v of values) {
      const len = v == null ? 0 : String(v).length;
      if (len + 2 > w) w = len + 2;
    }
    return Math.min(max || 60, w);
  }

  return { Workbook, colName, cellRef, crc32, zip, fitWidth };
})();
