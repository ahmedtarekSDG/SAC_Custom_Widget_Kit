/* ==========================================================================
 * PanelKit — schema-driven Styling Panel web component for SAC custom widgets.
 * Injected constants (by tools/build.py): PANEL_TAG, PANEL_SCHEMA, PROPS_DEFAULTS
 * SAC calls onCustomWidgetBeforeUpdate(changedProps) with the widget's current
 * property values; every edit is sent back with a "propertiesChanged" event.
 * ========================================================================== */
const PANEL_CSS = `
:host { display:block; font-family: '72','72full',Arial,Helvetica,sans-serif; font-size:12px; color:#32363A; }
* { box-sizing:border-box; }
details { border-bottom:1px solid #E4E4E4; padding:4px 0; }
summary { cursor:pointer; font-weight:bold; font-size:13px; padding:6px 2px; list-style:none; display:flex; align-items:center; gap:6px; }
summary::-webkit-details-marker { display:none; }
summary::before { content:'▸'; color:#0A6ED1; font-size:11px; transition:transform .15s; }
details[open] > summary::before { transform:rotate(90deg); }
.field { margin:6px 2px 8px; }
.field > label { display:block; margin-bottom:3px; color:#556B82; }
.row { display:flex; align-items:center; gap:6px; }
input[type=text], input[type=number], select, textarea {
  width:100%; height:26px; padding:2px 6px; border:1px solid #89919A; border-radius:4px; font:inherit; color:#32363A; background:#fff; }
textarea { height:56px; resize:vertical; }
input:focus, select:focus, textarea:focus { outline:2px solid #0A6ED1; outline-offset:-1px; border-color:#0A6ED1; }
input[type=color] { width:30px; height:26px; padding:0; border:1px solid #89919A; border-radius:4px; background:#fff; flex:none; }
.check { display:flex; align-items:center; gap:8px; cursor:pointer; color:#32363A; }
.check input { width:16px; height:16px; margin:0; }
.help { color:#6A6D70; font-size:11px; margin-top:2px; line-height:1.3; }
.footer { margin-top:10px; display:flex; justify-content:flex-end; }
button { font:inherit; border:1px solid #0A6ED1; color:#0A6ED1; background:#fff; border-radius:4px; padding:4px 10px; cursor:pointer; }
button:hover { background:#EBF5FE; }
.badge { font-weight:normal; color:#6A6D70; font-size:11px; margin-left:auto; }
`;

class SacKitStylingPanel extends HTMLElement {
  constructor() {
    super();
    this._shadow = this.attachShadow({ mode: "open" });
    this._props = Object.assign({}, PROPS_DEFAULTS);
    this._inputs = new Map();
    this._silent = false;
    this._build();
  }

  _build() {
    const style = document.createElement("style");
    style.textContent = PANEL_CSS;
    this._shadow.appendChild(style);
    const root = document.createElement("div");
    PANEL_SCHEMA.forEach((section, si) => {
      const det = document.createElement("details");
      if (section.open || si === 0) det.open = true;
      const sum = document.createElement("summary");
      sum.textContent = section.title;
      const badge = document.createElement("span");
      badge.className = "badge";
      badge.textContent = `${section.props.length}`;
      sum.appendChild(badge);
      det.appendChild(sum);
      section.props.forEach((p) => det.appendChild(this._field(p)));
      root.appendChild(det);
    });
    const footer = document.createElement("div");
    footer.className = "footer";
    const reset = document.createElement("button");
    reset.type = "button";
    reset.textContent = "Reset all to defaults";
    reset.addEventListener("click", () => {
      const props = {};
      PANEL_SCHEMA.forEach((s) => s.props.forEach((p) => (props[p.name] = PROPS_DEFAULTS[p.name])));
      this._apply(props);
      this._emit(props);
    });
    footer.appendChild(reset);
    root.appendChild(footer);
    this._shadow.appendChild(root);
  }

  _field(p) {
    const wrap = document.createElement("div");
    wrap.className = "field";
    const id = `f_${p.name}`;
    const control = p.control || (p.type === "boolean" ? "checkbox" : p.type === "integer" || p.type === "number" ? "number" : "text");
    let input;
    if (control === "checkbox") {
      const lab = document.createElement("label");
      lab.className = "check";
      input = document.createElement("input");
      input.type = "checkbox";
      input.id = id;
      lab.appendChild(input);
      lab.appendChild(document.createTextNode(p.label || p.name));
      wrap.appendChild(lab);
      input.addEventListener("change", () => this._emit({ [p.name]: input.checked }));
    } else {
      const lab = document.createElement("label");
      lab.htmlFor = id;
      lab.textContent = p.label || p.name;
      wrap.appendChild(lab);
      if (control === "select") {
        input = document.createElement("select");
        (p.options || []).forEach(([value, text]) => {
          const o = document.createElement("option");
          o.value = String(value);
          o.textContent = text;
          input.appendChild(o);
        });
        input.addEventListener("change", () => this._emit({ [p.name]: this._coerce(p, input.value) }));
        wrap.appendChild(input);
      } else if (control === "color") {
        const row = document.createElement("div");
        row.className = "row";
        const picker = document.createElement("input");
        picker.type = "color";
        input = document.createElement("input");
        input.type = "text";
        input.id = id;
        input.placeholder = "#RRGGBB";
        picker.addEventListener("input", () => {
          input.value = picker.value.toUpperCase();
        });
        picker.addEventListener("change", () => this._emit({ [p.name]: picker.value.toUpperCase() }));
        input.addEventListener("change", () => {
          if (/^#[0-9a-f]{6}$/i.test(input.value)) picker.value = input.value;
          this._emit({ [p.name]: input.value.trim() });
        });
        input._picker = picker;
        row.appendChild(picker);
        row.appendChild(input);
        wrap.appendChild(row);
      } else if (control === "textarea") {
        input = document.createElement("textarea");
        input.id = id;
        if (p.placeholder) input.placeholder = p.placeholder;
        input.addEventListener("change", () => this._emit({ [p.name]: input.value }));
        wrap.appendChild(input);
      } else {
        input = document.createElement("input");
        input.type = control === "number" ? "number" : "text";
        input.id = id;
        if (p.min != null) input.min = p.min;
        if (p.max != null) input.max = p.max;
        if (p.step != null) input.step = p.step;
        if (p.placeholder) input.placeholder = p.placeholder;
        input.addEventListener("change", () => this._emit({ [p.name]: this._coerce(p, input.value) }));
        wrap.appendChild(input);
      }
    }
    if (p.help) {
      const h = document.createElement("div");
      h.className = "help";
      h.textContent = p.help;
      wrap.appendChild(h);
    }
    this._inputs.set(p.name, { p, input });
    this._setValue(p.name, this._props[p.name]);
    return wrap;
  }

  _coerce(p, raw) {
    if (p.type === "integer") {
      let n = parseInt(raw, 10);
      if (!isFinite(n)) n = PROPS_DEFAULTS[p.name];
      if (p.min != null) n = Math.max(p.min, n);
      if (p.max != null) n = Math.min(p.max, n);
      return n;
    }
    if (p.type === "number") {
      let n = parseFloat(raw);
      if (!isFinite(n)) n = PROPS_DEFAULTS[p.name];
      if (p.min != null) n = Math.max(p.min, n);
      if (p.max != null) n = Math.min(p.max, n);
      return n;
    }
    if (p.type === "boolean") return raw === true || raw === "true";
    return raw;
  }

  _setValue(name, value) {
    const entry = this._inputs.get(name);
    if (!entry) return;
    const { input } = entry;
    if (input.type === "checkbox") input.checked = !!value;
    else {
      input.value = value == null ? "" : String(value);
      if (input._picker && /^#[0-9a-f]{6}$/i.test(input.value)) input._picker.value = input.value;
    }
  }

  _apply(props) {
    Object.keys(props).forEach((k) => {
      this._props[k] = props[k];
      this._setValue(k, props[k]);
    });
  }

  _emit(properties) {
    Object.assign(this._props, properties);
    this.dispatchEvent(new CustomEvent("propertiesChanged", { detail: { properties } }));
  }

  // ---- SAC lifecycle -------------------------------------------------------
  onCustomWidgetBeforeUpdate(changedProps) {
    this._apply(changedProps || {});
  }
  onCustomWidgetAfterUpdate() {}
  onCustomWidgetDestroy() {}
}

if (!customElements.get(PANEL_TAG)) customElements.define(PANEL_TAG, SacKitStylingPanel);
