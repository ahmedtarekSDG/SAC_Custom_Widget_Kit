/* ==========================================================================
 * Member Selector — custom filter control (SAP Analytics Cloud custom widget)
 * Selection drives other widgets through linked analysis (setFilters) and is
 * exposed to scripts (getSelectedMembers) for cross-model setDimensionFilter.
 * ========================================================================== */
const BINDING_ID = "dataBinding";
const NON_RENDER_KEYS = new Set(["selectedLabels", "dimensionId", "widgetName"]);

const STYLE = `
:host { display:block; width:100%; height:100%; position:relative; overflow:hidden; }
* { box-sizing:border-box; }
.root { position:absolute; inset:0; display:flex; flex-direction:column; padding:6px; gap:6px; }
.chips { display:flex; flex-wrap:wrap; gap:6px; overflow:auto; align-content:flex-start; }
.chip { border:1px solid #B0B7BF; border-radius:999px; padding:5px 12px; cursor:pointer; background:#fff; white-space:nowrap; user-select:none; font:inherit; color:inherit; }
.chip small { opacity:.65; margin-left:6px; }
.chip.on { color:#fff; }
.seg { display:flex; border:1px solid #B0B7BF; border-radius:6px; overflow:hidden; width:max-content; max-width:100%; }
.seg button { border:0; border-right:1px solid #B0B7BF; padding:6px 12px; background:#fff; cursor:pointer; font:inherit; color:inherit; white-space:nowrap; }
.seg button:last-child { border-right:0; }
.seg button.on { color:#fff; }
.search { height:28px; border:1px solid #B0B7BF; border-radius:4px; padding:0 8px; font:inherit; flex:none; }
.list { overflow:auto; flex:1 1 auto; }
.item { display:grid; grid-template-columns:18px 1fr auto; align-items:center; gap:6px; padding:4px 4px; border-radius:4px; cursor:pointer; position:relative; }
.item:hover { background:rgba(10,110,209,.06); }
.item .bar { position:absolute; left:28px; bottom:1px; height:3px; border-radius:2px; opacity:.5; }
.item input { margin:0; pointer-events:none; }
.item span { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.item small { opacity:.7; }
.msg { opacity:.75; font-size:12px; padding:8px; }
`;
const template = document.createElement("template");
template.innerHTML = `<style>${STYLE}</style><div class="root" role="group" aria-label="Member selector"></div>`;

class MemberSelector extends HTMLElement {
  constructor() {
    super();
    this._shadow = this.attachShadow({ mode: "open" });
    this._shadow.appendChild(template.content.cloneNode(true));
    this._root = this._shadow.querySelector(".root");
    this._props = Object.assign({}, PROPS_DEFAULTS);
    this._appliedOnLoad = false;
    this._root.addEventListener("click", (e) => {
      const t = e.target.closest("[data-id]");
      if (t) this._toggle(t.getAttribute("data-id"), e.ctrlKey || e.metaKey);
    });
    this._root.addEventListener("input", (e) => {
      if (e.target.classList.contains("search")) {
        this._props.searchText = e.target.value;
        clearTimeout(this._st);
        this._st = setTimeout(() => this._render(true), 150);
      }
    });
  }
  connectedCallback() {
    this._schedule();
  }
  onCustomWidgetBeforeUpdate(c) {
    this._props = Object.assign(this._props, c || {});
  }
  onCustomWidgetAfterUpdate(c) {
    const ch = c || {};
    const keys = Object.keys(ch);
    // selectedMembers changed by a script (setSelectedMembers / clearSelection): apply it
    if ("selectedMembers" in ch && this._ready && keys.length < 6 && ch.selectedMembers !== this._lastPublished) {
      this._publish(false);
    }
    if (keys.length && keys.every((k) => NON_RENDER_KEYS.has(k))) return;
    this._schedule();
  }
  onCustomWidgetResize() {}
  onCustomWidgetDestroy() {}
  _schedule() {
    clearTimeout(this._t);
    this._t = setTimeout(() => this._render(), 0);
  }
  _binding() {
    return this._props[BINDING_ID] || this[BINDING_ID];
  }
  _selected() {
    return new Set(SacKit.parseList(this._props.selectedMembers));
  }

  _members(parsed) {
    const p = this._props;
    const map = new Map();
    parsed.rows.forEach((r) => {
      const d = r.dims[0];
      if (!d) return;
      if (!map.has(d.id)) map.set(d.id, { id: d.id, label: d.label, value: 0, has: false });
      const m = map.get(d.id);
      if (r.values[0] && r.values[0].raw != null) {
        m.value += r.values[0].raw;
        m.has = true;
      }
    });
    let list = [...map.values()];
    if (p.sortBy === "label") list.sort((a, b) => a.label.localeCompare(b.label, undefined, { numeric: true }));
    else if (p.sortBy === "valueDesc") list.sort((a, b) => b.value - a.value);
    else if (p.sortBy === "valueAsc") list.sort((a, b) => a.value - b.value);
    return list.slice(0, Math.max(1, p.maxMembers || 200));
  }

  _render(keepSearchFocus) {
    if (!this.isConnected) return;
    const p = this._props;
    const esc = SacKit.escapeHtml;
    const r = this._root;
    r.style.fontFamily = p.fontFamily;
    r.style.fontSize = `${p.fontSize}px`;
    r.style.color = p.textColor;
    r.style.background = p.backgroundColor || "transparent";
    const parsed = SacKit.parseDataBinding(this._binding());
    this._parsed = parsed;
    if (parsed.state !== "success" || !parsed.dims.length) {
      r.innerHTML = `<div class="msg">${parsed.state === "loading" ? "Loading…" : "Bind a dimension (optional: a measure for values)."}</div>`;
      SacKit.renderComplete(this);
      return;
    }
    const dimId = parsed.dims[0].id;
    if (p.dimensionId !== dimId) {
      this._props.dimensionId = dimId;
      SacKit.dispatchProps(this, { dimensionId: dimId });
    }
    this._ready = true;
    const members = this._members(parsed);
    this._membersCache = members;
    const sel = this._selected();
    const fmt = { scale: !p.scale || p.scale === "auto" ? SacKit.autoScaleFor(members.map((m) => m.value)) : p.scale, decimals: p.decimals, symbols: { K: "K", M: "M", B: "B" } };
    const val = (m) => (p.showValues && parsed.measures.length && m.has ? SacKit.formatNumber(m.value, fmt) : "");
    const onStyle = `background:${p.accentColor};border-color:${p.accentColor};`;
    let html = "";
    if (p.displayMode === "segmented") {
      html += '<div class="seg" role="radiogroup">';
      if (p.showAllOption) html += `<button type="button" data-id="__all" class="${sel.size ? "" : "on"}" style="${sel.size ? "" : onStyle}">${esc(p.allLabel)}</button>`;
      members.forEach((m) => {
        const on = sel.has(m.id);
        html += `<button type="button" data-id="${esc(m.id)}" class="${on ? "on" : ""}" style="${on ? onStyle : ""}" aria-pressed="${on}">${esc(m.label)}</button>`;
      });
      html += "</div>";
    } else if (p.displayMode === "list") {
      const q = String(p.searchText || "").toLowerCase();
      const max = Math.max(1e-12, ...members.map((m) => Math.abs(m.value)));
      html += `<input class="search" type="search" placeholder="Search…" value="${esc(p.searchText || "")}">`;
      html += '<div class="list" role="listbox" aria-multiselectable="' + (p.selectionMode !== "single") + '">';
      if (p.showAllOption && !q) html += `<div class="item" data-id="__all"><input type="checkbox" ${sel.size ? "" : "checked"}><span><b>${esc(p.allLabel)}</b></span><small></small></div>`;
      members
        .filter((m) => !q || m.label.toLowerCase().includes(q) || SacKit.plainMemberId(m.id).toLowerCase().includes(q))
        .forEach((m) => {
          const on = sel.has(m.id);
          const bar = p.showBars && m.has ? `<i class="bar" style="width:calc((100% - 90px) * ${Math.abs(m.value) / max});background:${p.accentColor}"></i>` : "";
          html += `<div class="item" data-id="${esc(m.id)}" role="option" aria-selected="${on}"><input type="${p.selectionMode === "single" ? "radio" : "checkbox"}" ${on ? "checked" : ""}><span>${esc(m.label)}</span><small>${esc(val(m))}</small>${bar}</div>`;
        });
      html += "</div>";
    } else {
      html += '<div class="chips">';
      if (p.showAllOption) html += `<button type="button" class="chip ${sel.size ? "" : "on"}" data-id="__all" style="${sel.size ? "" : onStyle}">${esc(p.allLabel)}</button>`;
      members.forEach((m) => {
        const on = sel.has(m.id);
        const v = val(m);
        html += `<button type="button" class="chip ${on ? "on" : ""}" data-id="${esc(m.id)}" style="${on ? onStyle : ""}" aria-pressed="${on}">${esc(m.label)}${v ? `<small>${esc(v)}</small>` : ""}</button>`;
      });
      html += "</div>";
    }
    const search = this._shadow.activeElement && this._shadow.activeElement.classList.contains("search");
    r.innerHTML = html;
    if (keepSearchFocus || search) {
      const s = r.querySelector(".search");
      if (s) {
        s.focus();
        s.setSelectionRange(s.value.length, s.value.length);
      }
    }
    // re-apply a persisted (bookmarked) selection once data is there
    if (!this._appliedOnLoad && p.applySelectionOnLoad && sel.size) {
      this._appliedOnLoad = true;
      this._publish(false);
    }
    this._appliedOnLoad = true;
    SacKit.renderComplete(this);
  }

  _toggle(id, additive) {
    const p = this._props;
    let sel = this._selected();
    if (id === "__all") sel = new Set();
    else if (p.selectionMode === "single") sel = sel.has(id) && sel.size === 1 ? new Set() : new Set([id]);
    else if (sel.has(id)) sel.delete(id);
    else sel.add(id);
    this._props.selectedMembers = [...sel].join(",");
    this._render();
    this._publish(true);
  }

  async _publish(byUser) {
    const p = this._props;
    const parsed = this._parsed;
    if (!parsed || !parsed.dims.length) return;
    const dimId = parsed.dims[0].id;
    const ids = SacKit.parseList(p.selectedMembers);
    const labels = ids.map((id) => {
      const m = (this._membersCache || []).find((x) => x.id === id);
      return m ? m.label : id;
    });
    this._lastPublished = p.selectedMembers;
    const la = SacKit.linkedAnalysis(this, BINDING_ID, p);
    if (p.enableLinkedAnalysis) {
      if (!ids.length) await la.removeFilters();
      else await la.setFilters(ids.length === 1 ? { [dimId]: ids[0] } : ids.map((id) => ({ [dimId]: id })));
    }
    const props = { selectedLabels: labels.join(", ") };
    if (byUser) props.selectedMembers = p.selectedMembers;
    SacKit.dispatchProps(this, props);
    SacKit.fireEvent(this, "onSelect"); // also fires when a script or a bookmark sets the selection
    if (!byUser) this._render();
  }
}
if (!customElements.get(WIDGET_TAG)) customElements.define(WIDGET_TAG, MemberSelector);
