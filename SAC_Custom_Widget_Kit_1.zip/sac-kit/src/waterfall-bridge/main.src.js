/* ==========================================================================
 * Waterfall / Bridge — SAP Analytics Cloud custom widget (main web component)
 * Injected by build: WIDGET_TAG, WIDGET_NAME, WIDGET_VERSION, PROPS_DEFAULTS
 * Uses: SacKit (shared helpers), XlsxLite (xlsx writer)
 * ========================================================================== */
const BINDING_ID = "dataBinding";
const OUTPUT_KEYS = ["selectedMemberId", "selectedMemberLabel", "selectedValue", "selectedDimensionId"];
const COMMAND_KEYS = ["exportToken", "clearSelectionToken", "exportFormat", "exportRequestFileName"];
const NON_RENDER_KEYS = new Set([...OUTPUT_KEYS, ...COMMAND_KEYS, "widgetName"]);

const KIND_TEXT = { start: "Start", end: "End", subtotal: "Subtotal", delta: "Step" };

const STYLE = `
:host { display:block; width:100%; height:100%; position:relative; overflow:hidden; }
.root { position:absolute; inset:0; display:flex; flex-direction:column; }
.head { flex:none; padding:4px 8px 0 8px; display:none; }
.head.on { display:block; }
.title { font-weight:bold; line-height:1.3; }
.subtitle { opacity:.75; line-height:1.3; }
.chart { flex:1 1 auto; position:relative; min-height:40px; }
.chart svg { display:block; width:100%; height:100%; overflow:visible; }
.bar { cursor:pointer; outline:none; }
.bar:focus-visible .shape { stroke:#0070F2; stroke-width:2; }
.msg { position:absolute; inset:0; display:none; align-items:center; justify-content:center; text-align:center; padding:16px; opacity:.8; }
.msg.on { display:flex; }
.tip { position:absolute; pointer-events:none; z-index:5; display:none; max-width:280px; background:#fff; color:#32363A;
  border:1px solid #D9D9D9; border-radius:6px; box-shadow:0 4px 14px rgba(0,0,0,.15); padding:8px 10px; font-size:12px; line-height:1.45; }
.tip b { display:block; margin-bottom:2px; }
.tip .k { color:#6A6D70; }
.tip .row { display:flex; justify-content:space-between; gap:14px; white-space:nowrap; }
.toolbar { position:absolute; top:4px; right:6px; z-index:6; display:flex; gap:4px; opacity:0; transition:opacity .15s; }
:host(:hover) .toolbar, .toolbar:focus-within { opacity:1; }
@media (hover:none) { .toolbar { opacity:1; } }
.toolbar button { font:600 10px/1 Arial,sans-serif; letter-spacing:.3px; color:#0A6ED1; background:rgba(255,255,255,.92);
  border:1px solid #BCCEE4; border-radius:4px; padding:4px 6px; cursor:pointer; }
.toolbar button:hover { background:#EBF5FE; border-color:#0A6ED1; }
.toolbar.off { display:none; }
`;

const template = document.createElement("template");
template.innerHTML = `<style>${STYLE}</style>
<div class="root" part="root">
  <div class="head"><div class="title"></div><div class="subtitle"></div></div>
  <div class="chart" role="img"></div>
  <div class="msg"></div>
  <div class="tip" role="tooltip"></div>
  <div class="toolbar" aria-label="Export">
    <button type="button" data-export="png" title="Download PNG image">PNG</button>
    <button type="button" data-export="svg" title="Download SVG vector image">SVG</button>
    <button type="button" data-export="xlsx" title="Download Excel workbook (values with number formats)">XLSX</button>
    <button type="button" data-export="csv" title="Download CSV">CSV</button>
  </div>
</div>`;

// --------------------------------------------------------------------------
// Pure bridge computation (no DOM) — exposed as a static for testing.
// --------------------------------------------------------------------------
function clampIndex(i, n) {
  const k = Number.isFinite(Number(i)) ? Math.floor(Number(i)) : 0;
  return Math.max(0, Math.min(n - 1, k));
}

function buildBridge(parsed, p) {
  const mode = ["dimension", "variance", "measures"].includes(p.bridgeMode) ? p.bridgeMode : "dimension";
  const nDims = parsed.dims.length;
  const nMeas = parsed.measures.length;
  if (!nMeas) return { error: "Add at least one measure to the widget in the Builder panel." };
  if (mode !== "measures" && !nDims) return { error: "Add a dimension (the bridge steps) in the Builder panel, or switch the bridge mode to 'Measures'." };

  const isExcluded = SacKit.memberMatcher(p.excludeMembers);
  const isTotal = SacKit.memberMatcher(p.totalMembers);
  const isInverted = SacKit.memberMatcher(p.invertedMembers);
  const rowLabel = (r) => r.dims.map((d) => d.label).filter(Boolean).join(" / ") || "(no label)";
  const rowKey = (r) => r.dims.map((d) => d.id).join("|");
  const rows = parsed.rows.filter((r) => !r.dims.some((d) => isExcluded(d.id, d.label)));
  const approx = (a, b) => Math.abs(a - b) <= Math.max(1e-6, 1e-3 * Math.max(Math.abs(a), Math.abs(b)));
  const num = (v) => (v == null || !isFinite(v) ? 0 : v);
  const mk = (o) =>
    Object.assign(
      { kind: "delta", value: 0, label: "", key: "", selection: null, memberIds: [], dimensionId: "", measureId: "", inverted: false, pinned: false },
      o
    );
  const warnings = [];

  // hierarchy (single bound dimension displayed as hierarchy: rows carry parentId)
  const hier = nDims === 1 && rows.some((r) => r.dims[0].parentId);
  let ordered = rows.map((r) => ({ row: r, isNode: false }));
  if (hier) {
    const ids = new Set(rows.map((r) => r.dims[0].id));
    const kids = new Map();
    const roots = [];
    rows.forEach((r) => {
      const pid = r.dims[0].parentId;
      if (pid && ids.has(pid) && pid !== r.dims[0].id) {
        if (!kids.has(pid)) kids.set(pid, []);
        kids.get(pid).push(r);
      } else roots.push(r);
    });
    const out = [];
    const seen = new Set();
    const visit = (r, depth) => {
      const id = r.dims[0].id;
      if (seen.has(id) || depth > 64) return;
      seen.add(id);
      const ch = kids.get(id) || [];
      ch.forEach((c) => visit(c, depth + 1));
      out.push({ row: r, isNode: ch.length > 0, depth });
    };
    roots.forEach((r) => visit(r, 0));
    rows.forEach((r) => {
      if (!seen.has(r.dims[0].id)) out.push({ row: r, isNode: false, depth: 0 });
    });
    ordered = out;
  }

  const rowBase = (r, mi) => ({
    key: rowKey(r),
    label: rowLabel(r),
    selection: SacKit.rowSelection(parsed, r),
    memberIds: r.dims.map((d) => d.id),
    dimensionId: parsed.dims[0] ? parsed.dims[0].id : "",
    inverted: isInverted(r.dims[0].id, r.dims[0].label) || isInverted(rowKey(r), rowLabel(r)),
    formatted: mi != null && r.values[mi] ? r.values[mi].formatted : "",
  });

  let steps = [];
  if (mode === "dimension") {
    const mi = clampIndex(p.measureIndex, nMeas);
    let running = 0;
    ordered.forEach((o) => {
      const r = o.row;
      const v = num(r.values[mi].raw);
      const base = rowBase(r, mi);
      const explicit = isTotal(r.dims[0].id, r.dims[0].label) || isTotal(base.key, base.label);
      if (explicit || (p.firstIsTotal && steps.length === 0)) {
        steps.push(mk(Object.assign(base, { kind: steps.length === 0 ? "start" : "subtotal", value: v })));
        running = v;
        return;
      }
      if (o.isNode && p.hierarchyMode !== "all") {
        if (p.hierarchyMode === "leaves") return;
        // auto: a parent node equal to the running total is a cumulative result (e.g. Gross Profit)
        if (steps.length > 0 && approx(v, running)) steps.push(mk(Object.assign(base, { kind: "subtotal", value: v, auto: true })));
        return; // otherwise a grouping node whose children are already counted
      }
      steps.push(mk(Object.assign(base, { kind: "delta", value: v })));
      running += v;
    });
    if (p.showEndTotal) {
      const last = steps[steps.length - 1];
      if (last && last.kind === "subtotal" && last.auto && approx(last.value, running)) last.kind = "end";
      else steps.push(mk({ key: "__end", kind: "end", label: p.endLabel || "Total", value: running }));
    }
  } else if (mode === "variance") {
    const bi = clampIndex(p.baseMeasureIndex, nMeas);
    const ci = clampIndex(p.compareMeasureIndex, nMeas);
    if (nMeas < 2 || bi === ci) return { error: "Variance mode needs two different measures (A = base, B = compare). Bind at least two measures." };
    const leafRows = hier && p.hierarchyMode !== "all" ? ordered.filter((o) => !o.isNode).map((o) => o.row) : rows;
    let sumA = 0;
    let sumB = 0;
    const deltas = leafRows.map((r) => {
      const a = num(r.values[bi].raw);
      const b = num(r.values[ci].raw);
      sumA += a;
      sumB += b;
      return mk(Object.assign(rowBase(r, null), { kind: "delta", value: b - a, baseValue: a, compareValue: b }));
    });
    steps.push(mk({ key: "__start", kind: "start", label: p.startLabel || parsed.measures[bi].label, value: sumA, measureId: parsed.measures[bi].id }));
    steps = steps.concat(deltas);
    steps.push(mk({ key: "__end", kind: "end", label: p.endLabel || parsed.measures[ci].label, value: sumB, measureId: parsed.measures[ci].id }));
  } else {
    // measures mode — every bound measure is a step; values are summed over the rows
    const totals = parsed.measures.map((m, i) => rows.reduce((s, r) => s + num(r.values[i].raw), 0));
    let running = 0;
    parsed.measures.forEach((m, i) => {
      const v = totals[i];
      const base = { key: `m:${m.id}`, label: m.label, measureId: m.id, inverted: isInverted(m.id, m.label) };
      const last = i === nMeas - 1;
      if (i === 0 && p.firstMeasureIsTotal) {
        steps.push(mk(Object.assign(base, { kind: "start", value: v })));
        running = v;
      } else if (last && p.lastMeasureIsTotal && nMeas > 1) {
        if (p.showResidual && !approx(v, running)) {
          steps.push(mk({ key: "__residual", kind: "delta", label: p.residualLabel || "Residual", value: v - running, residual: true, pinned: true }));
          warnings.push("Start + steps does not reconcile to the end measure: a residual step was added.");
        }
        steps.push(mk(Object.assign(base, { kind: "end", value: v })));
        running = v;
      } else if (isTotal(m.id, m.label)) {
        steps.push(mk(Object.assign(base, { kind: "subtotal", value: v })));
        running = v;
      } else {
        steps.push(mk(Object.assign(base, { kind: "delta", value: v })));
        running += v;
      }
    });
    if (!(p.lastMeasureIsTotal && nMeas > 1) && p.showEndTotal) steps.push(mk({ key: "__end", kind: "end", label: p.endLabel || "Total", value: running }));
  }

  // --- hide zero steps
  const maxAbsRaw = steps.reduce((m, s) => Math.max(m, Math.abs(s.value)), 0);
  const eps = Math.max(1e-12, maxAbsRaw * 1e-9);
  if (p.hideZeroSteps) steps = steps.filter((s) => s.kind !== "delta" || Math.abs(s.value) > eps || s.residual);

  // --- sort + Top N inside each segment between (sub)totals
  const sortMode = p.sortSteps === "auto" || !p.sortSteps ? (mode === "variance" ? "absDesc" : "none") : p.sortSteps;
  const cmp = {
    absDesc: (a, b) => Math.abs(b.value) - Math.abs(a.value),
    desc: (a, b) => b.value - a.value,
    asc: (a, b) => a.value - b.value,
  }[sortMode];
  const topN = Math.max(0, Math.floor(Number(p.topN) || 0));
  const result = [];
  let seg = [];
  let segNo = 0;
  const flush = () => {
    let normal = seg.filter((s) => !s.pinned);
    const pinned = seg.filter((s) => s.pinned);
    if (cmp) normal.sort(cmp);
    if (topN > 0 && normal.length > topN) {
      const keep = new Set([...normal].sort((a, b) => Math.abs(b.value) - Math.abs(a.value)).slice(0, topN));
      const rest = normal.filter((s) => !keep.has(s));
      normal = normal.filter((s) => keep.has(s));
      const sels = rest.map((s) => s.selection).filter((x) => x && !Array.isArray(x));
      pinned.unshift(
        mk({
          key: `__others_${segNo}`,
          kind: "delta",
          label: `${p.othersLabel || "Others"} (${rest.length})`,
          value: rest.reduce((t, s) => t + s.value, 0),
          others: true,
          count: rest.length,
          selection: sels.length ? sels : null,
          memberIds: rest.reduce((a, s) => a.concat(s.memberIds), []),
          dimensionId: rest[0] ? rest[0].dimensionId : "",
          pinned: true,
        })
      );
    }
    result.push(...normal, ...pinned);
    seg = [];
    segNo++;
  };
  steps.forEach((s) => {
    if (s.kind === "delta") seg.push(s);
    else {
      flush();
      result.push(s);
    }
  });
  flush();

  // --- positions, favourability, percentages
  let running = 0;
  result.forEach((s) => {
    if (s.kind === "delta") {
      s.from = running;
      s.to = running + s.value;
      running = s.to;
    } else {
      if (s.key === "__end") s.value = running;
      s.from = 0;
      s.to = s.value;
      running = s.value;
    }
    s.cumulative = running;
  });
  const start = result.find((s) => s.kind === "start");
  const end = result.find((s) => s.kind === "end");
  const firstBar = result.find((s) => Math.abs(s.value) > eps);
  const pctBase = start ? start.value : firstBar ? firstBar.value : end ? end.value : null;
  result.forEach((s) => {
    if (s.kind === "delta" && !s.others && !s.residual && Math.abs(s.value) > eps) {
      let good = s.value > 0 ? !!p.increaseIsGood : !p.increaseIsGood;
      if (s.inverted) good = !good;
      s.favorable = good;
    } else s.favorable = null;
    s.pct = pctBase ? s.value / Math.abs(pctBase) : null;
  });
  const maxAbs = result.reduce((m, s) => Math.max(m, Math.abs(s.from), Math.abs(s.to)), 0);
  return { mode, steps: result, pctBase, maxAbs, warnings, hierarchical: hier };
}

// --------------------------------------------------------------------------
class WaterfallBridge extends HTMLElement {
  constructor() {
    super();
    this._shadow = this.attachShadow({ mode: "open" });
    this._shadow.appendChild(template.content.cloneNode(true));
    this._el = {
      root: this._shadow.querySelector(".root"),
      head: this._shadow.querySelector(".head"),
      title: this._shadow.querySelector(".title"),
      subtitle: this._shadow.querySelector(".subtitle"),
      chart: this._shadow.querySelector(".chart"),
      msg: this._shadow.querySelector(".msg"),
      tip: this._shadow.querySelector(".tip"),
      toolbar: this._shadow.querySelector(".toolbar"),
    };
    this._props = Object.assign({}, PROPS_DEFAULTS);
    this._selected = new Set();
    this._model = null;
    this._timer = null;
    this._initialized = false;
    this._seen = { exportToken: 0, clearSelectionToken: 0 };
    this._lastSize = { w: 0, h: 0 };

    this._el.chart.addEventListener("click", (e) => this._onClick(e));
    this._el.chart.addEventListener("keydown", (e) => this._onKey(e));
    this._el.chart.addEventListener("pointermove", (e) => this._onMove(e));
    this._el.chart.addEventListener("pointerleave", () => this._hideTip());
    this._el.toolbar.addEventListener("click", (e) => {
      const b = e.target.closest("button[data-export]");
      if (b) {
        e.stopPropagation();
        this.exportAs(b.getAttribute("data-export"));
      }
    });
  }

  // ---------------------------------------------------------------- lifecycle
  connectedCallback() {
    if (typeof ResizeObserver !== "undefined" && !this._ro) {
      this._ro = new ResizeObserver(() => {
        const r = this._el.chart.getBoundingClientRect();
        if (Math.abs(r.width - this._lastSize.w) > 1 || Math.abs(r.height - this._lastSize.h) > 1) this._schedule();
      });
      this._ro.observe(this);
    }
    this._schedule();
  }

  disconnectedCallback() {
    if (this._ro) {
      this._ro.disconnect();
      this._ro = null;
    }
  }

  onCustomWidgetBeforeUpdate(changedProps) {
    this._props = Object.assign(this._props, changedProps || {});
  }

  onCustomWidgetAfterUpdate(changedProps) {
    const c = changedProps || {};
    const keys = Object.keys(c);
    const bulk = keys.length > 12; // initial hand-over of all persisted properties
    if (!this._initialized || bulk) {
      this._seen.exportToken = this._props.exportToken;
      this._seen.clearSelectionToken = this._props.clearSelectionToken;
      this._initialized = true;
    } else {
      if ("clearSelectionToken" in c && c.clearSelectionToken !== this._seen.clearSelectionToken) {
        this._seen.clearSelectionToken = c.clearSelectionToken;
        this._clearSelection(false);
      }
      if ("exportToken" in c && c.exportToken !== this._seen.exportToken) {
        this._seen.exportToken = c.exportToken;
        this.exportAs(this._props.exportFormat, this._props.exportRequestFileName);
      }
    }
    if (keys.length && keys.every((k) => NON_RENDER_KEYS.has(k))) return;
    this._schedule();
  }

  onCustomWidgetResize() {
    this._schedule();
  }

  onCustomWidgetDestroy() {
    this.disconnectedCallback();
    clearTimeout(this._timer);
  }

  // ---------------------------------------------------------------- data
  _binding() {
    return this._props[BINDING_ID] || this[BINDING_ID];
  }

  _schedule() {
    clearTimeout(this._timer);
    this._timer = setTimeout(() => this._render(), 0);
  }

  _fmt(model) {
    const p = this._props;
    const scale =
      p.scale === "auto" || !p.scale
        ? SacKit.autoScaleFor(model ? model.steps.map((s) => s.value) : [])
        : p.scale;
    const base = {
      scale,
      decimals: p.decimals,
      prefix: p.prefix,
      suffix: p.suffix,
      plusSign: false,
      negativeStyle: p.negativeStyle,
      locale: p.locale,
      symbols: SacKit.parseSymbols(p.scaleSymbols),
    };
    return {
      value: base,
      delta: Object.assign({}, base, { plusSign: !!p.showPlusSign }),
      pct: { percent: true, decimals: p.percentDecimals, plusSign: !!p.showPlusSign, negativeStyle: p.negativeStyle, locale: p.locale },
    };
  }

  // ---------------------------------------------------------------- render
  _render() {
    if (!this.isConnected) return;
    const p = this._props;
    const el = this._el;
    el.root.style.fontFamily = p.fontFamily;
    el.root.style.fontSize = `${p.fontSize}px`;
    el.root.style.color = p.textColor;
    el.root.style.background = p.backgroundColor || "transparent";
    el.toolbar.classList.toggle("off", !p.showToolbar);
    const showHead = !!(p.showTitle && (p.chartTitle || p.chartSubtitle));
    el.head.classList.toggle("on", showHead);
    el.title.textContent = p.chartTitle || "";
    el.title.style.fontSize = `${Math.round(p.fontSize * 1.25)}px`;
    el.subtitle.textContent = p.chartSubtitle || "";

    const parsed = SacKit.parseDataBinding(this._binding());
    if (parsed.state !== "success") {
      this._message(parsed.state === "loading" ? "Loading…" : "Bind data in the Builder panel: a dimension for the steps and one or more measures.");
      return;
    }
    const model = buildBridge(parsed, p);
    if (model.error) {
      this._message(model.error);
      return;
    }
    if (!model.steps.length) {
      this._message("No data for the current filters.");
      return;
    }
    this._model = model;
    this._parsed = parsed;
    // keep only selections that still exist
    const keys = new Set(model.steps.map((s) => s.key));
    [...this._selected].forEach((k) => {
      if (!keys.has(k)) this._selected.delete(k);
    });
    const rect = el.chart.getBoundingClientRect();
    const W = Math.max(120, Math.floor(rect.width || this.clientWidth || 600));
    const H = Math.max(80, Math.floor(rect.height || this.clientHeight || 360));
    this._lastSize = { w: rect.width, h: rect.height };
    const svg = p.orientation === "horizontal" ? this._svgHorizontal(model, W, H) : this._svgVertical(model, W, H);
    this._svgInner = svg;
    this._svgSize = { W, H };
    el.chart.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" font-family="${SacKit.escapeHtml(
      p.fontFamily
    )}" font-size="${p.fontSize}">${svg}</svg>`;
    el.chart.setAttribute("aria-label", this._ariaSummary(model));
    el.msg.classList.remove("on");
    this._applySelection();
    SacKit.renderComplete(this);
  }

  _message(text) {
    this._model = null;
    this._el.chart.innerHTML = "";
    this._el.msg.textContent = text;
    this._el.msg.classList.add("on");
    SacKit.renderComplete(this);
  }

  _ariaSummary(model) {
    const f = this._fmt(model);
    const first = model.steps[0];
    const last = model.steps[model.steps.length - 1];
    return `Bridge from ${first.label} ${SacKit.formatNumber(first.to, f.value)} to ${last.label} ${SacKit.formatNumber(
      last.cumulative,
      f.value
    )} in ${model.steps.length} steps`;
  }

  _fill(s) {
    const p = this._props;
    if (s.kind === "start" || s.kind === "end") return p.colorTotal;
    if (s.kind === "subtotal") return p.colorSubtotal;
    if (s.others || s.residual || s.favorable == null) return p.colorOthers;
    return s.favorable ? p.colorFavorable : p.colorUnfavorable;
  }

  _labelLines(s, f) {
    const p = this._props;
    if (p.labelContent === "none") return [];
    const isTotal = s.kind !== "delta";
    const val = isTotal ? SacKit.formatNumber(s.value, f.value) : SacKit.formatNumber(s.value, f.delta);
    const pct = s.pct == null ? "" : SacKit.formatNumber(s.pct, f.pct);
    if (p.labelContent === "percent") return [isTotal ? val : pct || val];
    if (p.labelContent === "valueAndPercent" && !isTotal && pct) return [val, pct];
    return [val];
  }

  /** "zero" | "zoom" — auto zooms when the totals dwarf the movement between them */
  _axisMode(model) {
    const p = this._props;
    if (p.axisScaling === "zero" || p.axisScaling === "zoom") return p.axisScaling;
    const deltas = model.steps.filter((s) => s.kind === "delta");
    const totals = model.steps.filter((s) => s.kind !== "delta");
    if (!deltas.length || !totals.length) return "zero";
    const signs = new Set(totals.map((s) => Math.sign(s.value)));
    if (signs.size > 1 || signs.has(0)) return "zero";
    const lo = Math.min(...deltas.map((s) => Math.min(s.from, s.to)));
    const hi = Math.max(...deltas.map((s) => Math.max(s.from, s.to)));
    const totalMax = Math.max(...totals.map((s) => Math.abs(s.value)));
    const crossesZero = lo < 0 && hi > 0;
    return !crossesZero && totalMax > 0 && (hi - lo) / totalMax < 0.25 ? "zoom" : "zero";
  }

  _domain(model, ticks) {
    const zoom = this._axisMode(model) === "zoom";
    let lo = Infinity;
    let hi = -Infinity;
    model.steps.forEach((s) => {
      if (s.kind === "delta" || !zoom) {
        lo = Math.min(lo, s.from, s.to);
        hi = Math.max(hi, s.from, s.to);
      } else {
        lo = Math.min(lo, s.to);
        hi = Math.max(hi, s.to);
      }
    });
    if (!zoom) {
      lo = Math.min(lo, 0);
      hi = Math.max(hi, 0);
    } else {
      const pad = (hi - lo) * 0.12 || Math.abs(hi) * 0.05 || 1;
      const allPositive = model.steps.every((s) => Math.min(s.from, s.to) >= 0 || s.kind !== "delta");
      lo -= pad;
      hi += pad * 0.25;
      if (allPositive && lo < 0) lo = 0;
    }
    const d = SacKit.niceTicks(lo, hi, ticks || 5);
    d.zoom = zoom;
    return d;
  }

  _axisFmt(f, step) {
    const factor = { none: 1, K: 1e3, M: 1e6, B: 1e9 }[f.value.scale] || 1;
    const scaledStep = Math.abs(step / factor);
    const decimals = scaledStep >= 1 ? 0 : scaledStep >= 0.1 ? 1 : 2;
    return Object.assign({}, f.value, { decimals });
  }

  _connectorDash() {
    const st = this._props.connectorStyle;
    return st === "solid" ? "" : st === "dotted" ? ' stroke-dasharray="1.5 3"' : ' stroke-dasharray="4 3"';
  }

  _isDark(hex) {
    const m = String(hex || "").match(/^#?([0-9a-f]{6})$/i);
    if (!m) return true;
    const n = parseInt(m[1], 16);
    const r = (n >> 16) & 255;
    const g = (n >> 8) & 255;
    const b = n & 255;
    return 0.299 * r + 0.587 * g + 0.114 * b < 150;
  }

  _breakMark(x, y, w, horizontal) {
    // small zig-zag "axis break" for truncated total bars
    const p = this._props;
    const bg = p.backgroundColor && p.backgroundColor !== "transparent" ? p.backgroundColor : "#FFFFFF";
    if (horizontal) {
      const h = w;
      return `<path d="M${x - 3},${y} l6,${h * 0.25} l-6,${h * 0.25} l6,${h * 0.25} l-6,${h * 0.25}" fill="none" stroke="${bg}" stroke-width="2.5"/>`;
    }
    return `<path d="M${x},${y + 3} l${w * 0.25},-6 l${w * 0.25},6 l${w * 0.25},-6 l${w * 0.25},6" fill="none" stroke="${bg}" stroke-width="2.5"/>`;
  }

  _svgVertical(model, W, H) {
    const p = this._props;
    const f = this._fmt(model);
    const esc = SacKit.escapeHtml;
    const fs = Number(p.fontSize) || 12;
    const font = `${fs}px ${p.fontFamily}`;
    const boldFont = `bold ${fs}px ${p.fontFamily}`;
    const steps = model.steps;
    const n = steps.length;
    const dom = this._domain(model, Math.max(3, Math.min(8, Math.round(H / 70))));
    const axisFmt = this._axisFmt(f, dom.step);
    const tickLabels = dom.ticks.map((t) => SacKit.formatNumber(t, axisFmt));
    const left = p.showValueAxis ? Math.ceil(Math.max(...tickLabels.map((t) => SacKit.measureText(t, font)))) + 12 : 6;
    const right = 8;
    const bandW = (W - left - right) / n;
    const lineH = Math.round(fs * 1.25);
    let catLines;
    let bottom;
    if (p.categoryLabelMode === "rotate") {
      const maxW = Math.min(H * 0.38, 160);
      catLines = steps.map((s) => [SacKit.truncateText(s.label, maxW, font)]);
      const longest = Math.max(...catLines.map((l) => SacKit.measureText(l[0], font)));
      bottom = Math.ceil(Math.min(maxW, longest) * 0.72) + fs + 10;
    } else if (p.categoryLabelMode === "truncate") {
      catLines = steps.map((s) => [SacKit.truncateText(s.label, bandW - 4, s.kind === "delta" ? font : boldFont)]);
      bottom = lineH + 10;
    } else {
      catLines = steps.map((s) => SacKit.wrapText(s.label, Math.max(16, bandW - 4), s.kind === "delta" ? font : boldFont, p.maxLabelLines));
      bottom = Math.max(...catLines.map((l) => l.length)) * lineH + 10;
    }
    const labelRows = p.labelContent === "valueAndPercent" ? 2 : p.labelContent === "none" ? 0 : 1;
    const padTop = labelRows * lineH + 6;
    const padBottom = labelRows * lineH + 4;
    const plotTop = 4 + padTop;
    const plotBottom = H - bottom - padBottom;
    const plotH = Math.max(10, plotBottom - plotTop);
    const y = (v) => plotTop + ((dom.max - v) / (dom.max - dom.min || 1)) * plotH;
    const baseline = dom.zoom ? Math.max(dom.min, Math.min(0, dom.max)) : 0;
    const ratio = Math.max(0.1, Math.min(0.95, Number(p.barWidthRatio) || 0.62));
    const bw = Math.max(2, Math.min(140, bandW * ratio));
    const rx = Math.max(0, Math.min(bw / 2, Number(p.cornerRadius) || 0));
    let out = "";
    // grid + axis
    dom.ticks.forEach((t, i) => {
      const yy = Math.round(y(t)) + 0.5;
      if (p.showGridlines) out += `<line x1="${left}" x2="${W - right}" y1="${yy}" y2="${yy}" stroke="${p.gridColor}" stroke-width="1"/>`;
      if (p.showValueAxis)
        out += `<text x="${left - 8}" y="${yy}" dy="0.32em" text-anchor="end" fill="${p.axisColor}">${esc(tickLabels[i])}</text>`;
    });
    if (dom.min <= 0 && dom.max >= 0) {
      const y0 = Math.round(y(0)) + 0.5;
      out += `<line x1="${left}" x2="${W - right}" y1="${y0}" y2="${y0}" stroke="${p.axisColor}" stroke-width="1"/>`;
    }
    // connectors
    if (p.showConnectors) {
      const dash = this._connectorDash();
      for (let i = 0; i < n - 1; i++) {
        const yy = Math.round(y(steps[i].cumulative)) + 0.5;
        const x1 = left + bandW * (i + 0.5) + bw / 2;
        const x2 = left + bandW * (i + 1.5) - bw / 2;
        out += `<line x1="${x1}" x2="${x2}" y1="${yy}" y2="${yy}" stroke="${p.colorConnector}" stroke-width="1"${dash}/>`;
      }
    }
    // bars
    steps.forEach((s, i) => {
      const cx = left + bandW * (i + 0.5);
      const from = s.kind === "delta" ? s.from : baseline;
      const top = y(Math.max(from, s.to));
      const bot = y(Math.min(from, s.to));
      const h = Math.max(1, bot - top);
      const x = cx - bw / 2;
      const fill = this._fill(s);
      const hatch = s.others || s.residual;
      const truncated = s.kind !== "delta" && dom.zoom && ((s.value > 0 && dom.min > 0) || (s.value < 0 && dom.max < 0));
      const lines = this._labelLines(s, f);
      let g = `<g class="bar" data-i="${i}" tabindex="0" role="button" aria-label="${esc(s.label)}: ${esc(lines.join(" "))}">`;
      g += `<rect class="shape" x="${x.toFixed(2)}" y="${top.toFixed(2)}" width="${bw.toFixed(2)}" height="${h.toFixed(
        2
      )}" rx="${rx}" fill="${fill}"${hatch ? ` fill-opacity="0.55" stroke="${fill}" stroke-dasharray="3 2"` : ""}/>`;
      if (truncated) g += this._breakMark(x, bot - 10, bw, false);
      // data labels
      if (lines.length) {
        const fitsInside =
          p.labelPosition === "inside" &&
          h >= lines.length * lineH + 4 &&
          Math.max(...lines.map((t) => SacKit.measureText(t, font))) <= bw - 4;
        const weight = s.kind === "delta" ? "" : ' font-weight="bold"';
        if (fitsInside) {
          const color = this._isDark(fill) ? "#FFFFFF" : p.textColor;
          const cy = top + h / 2 - ((lines.length - 1) * lineH) / 2;
          lines.forEach((t, k) => {
            g += `<text x="${cx}" y="${cy + k * lineH}" dy="0.32em" text-anchor="middle" fill="${color}"${weight}>${esc(t)}</text>`;
          });
        } else {
          const below = s.kind === "delta" ? s.value < 0 : s.value < 0;
          lines.forEach((t, k) => {
            const yy = below ? bot + 4 + (k + 1) * lineH - lineH * 0.25 : top - 5 - (lines.length - 1 - k) * lineH;
            g += `<text x="${cx}" y="${yy}" text-anchor="middle" fill="${p.textColor}"${weight}${k > 0 ? ' opacity="0.75"' : ""}>${esc(t)}</text>`;
          });
        }
      }
      g += "</g>";
      out += g;
    });
    // category labels
    const catY = H - bottom + 6;
    steps.forEach((s, i) => {
      const cx = left + bandW * (i + 0.5);
      const weight = s.kind === "delta" ? "" : ' font-weight="bold"';
      if (p.categoryLabelMode === "rotate") {
        out += `<text x="${cx}" y="${catY + fs * 0.6}" text-anchor="end" transform="rotate(-40 ${cx} ${catY + fs * 0.6})" fill="${p.textColor}"${weight}>${esc(
          catLines[i][0]
        )}</text>`;
      } else {
        catLines[i].forEach((t, k) => {
          out += `<text x="${cx}" y="${catY + lineH * (k + 0.8)}" text-anchor="middle" fill="${p.textColor}"${weight}>${esc(t)}</text>`;
        });
      }
    });
    return out;
  }

  _svgHorizontal(model, W, H) {
    const p = this._props;
    const f = this._fmt(model);
    const esc = SacKit.escapeHtml;
    const fs = Number(p.fontSize) || 12;
    const font = `${fs}px ${p.fontFamily}`;
    const boldFont = `bold ${fs}px ${p.fontFamily}`;
    const steps = model.steps;
    const n = steps.length;
    const dom = this._domain(model, Math.max(3, Math.min(8, Math.round(W / 140))));
    const axisFmt = this._axisFmt(f, dom.step);
    const lineH = Math.round(fs * 1.25);
    const labelW = Math.max(40, Math.min(Number(p.categoryLabelWidth) || 170, W * 0.45));
    const left = labelW + 12;
    const allLabels = steps.map((s) => this._labelLines(s, f).join("  "));
    const labelPad = p.labelContent === "none" ? 6 : Math.ceil(Math.max(0, ...allLabels.map((t) => SacKit.measureText(t, font)))) + 10;
    const top = 4;
    const bottom = p.showValueAxis ? lineH + 10 : 6;
    const plotL = left + (dom.min < 0 ? labelPad : 4);
    const plotR = W - labelPad;
    const plotW = Math.max(10, plotR - plotL);
    const bandH = (H - top - bottom) / n;
    const x = (v) => plotL + ((v - dom.min) / (dom.max - dom.min || 1)) * plotW;
    const baseline = dom.zoom ? Math.max(dom.min, Math.min(0, dom.max)) : 0;
    const ratio = Math.max(0.1, Math.min(0.95, Number(p.barWidthRatio) || 0.62));
    const bh = Math.max(2, Math.min(60, bandH * ratio));
    const rx = Math.max(0, Math.min(bh / 2, Number(p.cornerRadius) || 0));
    const maxLines = Math.max(1, Math.min(p.maxLabelLines || 2, Math.floor(bandH / lineH) || 1));
    let out = "";
    dom.ticks.forEach((t) => {
      const xx = Math.round(x(t)) + 0.5;
      if (p.showGridlines) out += `<line x1="${xx}" x2="${xx}" y1="${top}" y2="${H - bottom}" stroke="${p.gridColor}" stroke-width="1"/>`;
      if (p.showValueAxis)
        out += `<text x="${xx}" y="${H - bottom + lineH}" text-anchor="middle" fill="${p.axisColor}">${esc(SacKit.formatNumber(t, axisFmt))}</text>`;
    });
    if (dom.min <= 0 && dom.max >= 0) {
      const x0 = Math.round(x(0)) + 0.5;
      out += `<line x1="${x0}" x2="${x0}" y1="${top}" y2="${H - bottom}" stroke="${p.axisColor}" stroke-width="1"/>`;
    }
    if (p.showConnectors) {
      const dash = this._connectorDash();
      for (let i = 0; i < n - 1; i++) {
        const xx = Math.round(x(steps[i].cumulative)) + 0.5;
        const y1 = top + bandH * (i + 0.5) + bh / 2;
        const y2 = top + bandH * (i + 1.5) - bh / 2;
        out += `<line x1="${xx}" x2="${xx}" y1="${y1}" y2="${y2}" stroke="${p.colorConnector}" stroke-width="1"${dash}/>`;
      }
    }
    steps.forEach((s, i) => {
      const cy = top + bandH * (i + 0.5);
      const from = s.kind === "delta" ? s.from : baseline;
      const x1 = x(Math.min(from, s.to));
      const x2 = x(Math.max(from, s.to));
      const w = Math.max(1, x2 - x1);
      const fill = this._fill(s);
      const hatch = s.others || s.residual;
      const lines = this._labelLines(s, f);
      const weight = s.kind === "delta" ? "" : ' font-weight="bold"';
      let g = `<g class="bar" data-i="${i}" tabindex="0" role="button" aria-label="${esc(s.label)}: ${esc(lines.join(" "))}">`;
      g += `<rect class="shape" x="${x1.toFixed(2)}" y="${(cy - bh / 2).toFixed(2)}" width="${w.toFixed(2)}" height="${bh.toFixed(
        2
      )}" rx="${rx}" fill="${fill}"${hatch ? ` fill-opacity="0.55" stroke="${fill}" stroke-dasharray="3 2"` : ""}/>`;
      if (s.kind !== "delta" && dom.zoom && ((s.value > 0 && dom.min > 0) || (s.value < 0 && dom.max < 0)))
        g += this._breakMark(x1 + 10, cy - bh / 2, bh, true);
      if (lines.length) {
        const text = lines.join("  ");
        const tw = SacKit.measureText(text, font);
        if (p.labelPosition === "inside" && tw <= w - 6 && bh >= fs + 2) {
          const color = this._isDark(fill) ? "#FFFFFF" : p.textColor;
          g += `<text x="${x1 + w / 2}" y="${cy}" dy="0.32em" text-anchor="middle" fill="${color}"${weight}>${esc(text)}</text>`;
        } else if (s.value < 0) {
          g += `<text x="${x1 - 5}" y="${cy}" dy="0.32em" text-anchor="end" fill="${p.textColor}"${weight}>${esc(text)}</text>`;
        } else {
          g += `<text x="${x2 + 5}" y="${cy}" dy="0.32em" text-anchor="start" fill="${p.textColor}"${weight}>${esc(text)}</text>`;
        }
      }
      g += "</g>";
      out += g;
      // category label (wrapped, right aligned)
      const cl = SacKit.wrapText(s.label, labelW, s.kind === "delta" ? font : boldFont, maxLines);
      const y0 = cy - ((cl.length - 1) * lineH) / 2;
      cl.forEach((t, k) => {
        out += `<text x="${left - 8}" y="${y0 + k * lineH}" dy="0.32em" text-anchor="end" fill="${p.textColor}"${weight}>${esc(t)}</text>`;
      });
    });
    return out;
  }

  // ---------------------------------------------------------------- interaction
  _barIndex(target) {
    const g = target && target.closest ? target.closest("g.bar") : null;
    return g ? Number(g.getAttribute("data-i")) : -1;
  }

  _applySelection() {
    const p = this._props;
    const any = this._selected.size > 0;
    this._el.chart.querySelectorAll("g.bar").forEach((g) => {
      const s = this._model && this._model.steps[Number(g.getAttribute("data-i"))];
      const on = !!s && this._selected.has(s.key);
      g.setAttribute("opacity", any && !on ? "0.4" : "1");
      const shape = g.querySelector(".shape");
      if (shape) {
        if (on) {
          shape.setAttribute("stroke", p.colorSelection);
          shape.setAttribute("stroke-width", "2");
          shape.removeAttribute("stroke-dasharray");
        } else if (!(s && (s.others || s.residual))) {
          shape.removeAttribute("stroke");
          shape.removeAttribute("stroke-width");
        } else {
          shape.setAttribute("stroke", this._fill(s));
          shape.setAttribute("stroke-width", "1");
          shape.setAttribute("stroke-dasharray", "3 2");
        }
      }
      g.setAttribute("aria-pressed", on ? "true" : "false");
    });
  }

  _onClick(e) {
    const i = this._barIndex(e.target);
    if (i < 0) {
      if (this._selected.size) this._clearSelection(true);
      return;
    }
    this._toggle(i, e.ctrlKey || e.metaKey || e.shiftKey);
  }

  _onKey(e) {
    if (e.key === "Escape") {
      this._clearSelection(true);
      return;
    }
    if (e.key === "Enter" || e.key === " ") {
      const i = this._barIndex(e.target);
      if (i >= 0) {
        e.preventDefault();
        this._toggle(i, e.ctrlKey || e.metaKey || e.shiftKey);
      }
    }
  }

  _toggle(i, additive) {
    const s = this._model && this._model.steps[i];
    if (!s) return;
    if (additive || this._props.multiSelect) {
      if (this._selected.has(s.key)) this._selected.delete(s.key);
      else this._selected.add(s.key);
    } else if (this._selected.size === 1 && this._selected.has(s.key)) {
      this._selected.clear();
    } else {
      this._selected.clear();
      this._selected.add(s.key);
    }
    this._applySelection();
    this._publishSelection(true);
  }

  _clearSelection(byUser) {
    const had = this._selected.size > 0;
    this._selected.clear();
    this._applySelection();
    if (had || !byUser) this._publishSelection(byUser);
  }

  async _publishSelection(byUser) {
    const p = this._props;
    const steps = this._model ? this._model.steps.filter((s) => this._selected.has(s.key)) : [];
    const la = SacKit.linkedAnalysis(this, BINDING_ID, p);
    if (!steps.length) {
      if (p.enableLinkedAnalysis) await la.removeFilters();
      SacKit.dispatchProps(this, { selectedMemberId: "", selectedMemberLabel: "", selectedValue: 0, selectedDimensionId: "" });
      if (byUser) SacKit.fireEvent(this, "onClear");
      return;
    }
    const selections = [];
    steps.forEach((s) => {
      if (Array.isArray(s.selection)) selections.push(...s.selection);
      else if (s.selection && Object.keys(s.selection).length) selections.push(s.selection);
    });
    if (p.enableLinkedAnalysis) {
      if (selections.length) await la.setFilters(selections.length === 1 ? selections[0] : selections);
      else await la.removeFilters();
    }
    SacKit.dispatchProps(this, {
      selectedMemberId: steps.map((s) => (s.memberIds.length ? s.memberIds.join("|") : s.measureId || s.key)).join(","),
      selectedMemberLabel: steps.map((s) => s.label).join(", "),
      selectedValue: steps[0].value,
      selectedDimensionId: steps[0].dimensionId || "",
    });
    if (byUser) SacKit.fireEvent(this, "onSelect");
  }

  _onMove(e) {
    const p = this._props;
    if (!p.showTooltip || !this._model) return this._hideTip();
    const i = this._barIndex(e.target);
    if (i < 0) return this._hideTip();
    const s = this._model.steps[i];
    const f = this._fmt(this._model);
    const esc = SacKit.escapeHtml;
    const row = (k, v) => `<div class="row"><span class="k">${esc(k)}</span><span>${esc(v)}</span></div>`;
    let kind = KIND_TEXT[s.kind];
    if (s.kind === "delta") kind = s.others ? `Grouped (${s.count} members)` : s.residual ? "Residual" : s.value >= 0 ? "Increase" : "Decrease";
    let html = `<b>${esc(s.label)}</b>`;
    html += row("Type", kind + (s.favorable == null ? "" : s.favorable ? " · favourable" : " · unfavourable"));
    html += row(s.kind === "delta" ? "Impact" : "Value", SacKit.formatNumber(s.value, s.kind === "delta" ? f.delta : f.value));
    if (s.kind === "delta") html += row("Running total", SacKit.formatNumber(s.cumulative, f.value));
    if (s.pct != null && s.kind === "delta") html += row("% of start", SacKit.formatNumber(s.pct, f.pct));
    if (s.baseValue != null && this._parsed) {
      const ms = this._parsed.measures;
      html += row(ms[clampIndex(p.baseMeasureIndex, ms.length)].label, SacKit.formatNumber(s.baseValue, f.value));
      html += row(ms[clampIndex(p.compareMeasureIndex, ms.length)].label, SacKit.formatNumber(s.compareValue, f.value));
    }
    const tip = this._el.tip;
    tip.innerHTML = html;
    tip.style.display = "block";
    const box = this._el.root.getBoundingClientRect();
    let left = e.clientX - box.left + 14;
    let top = e.clientY - box.top + 14;
    const tw = tip.offsetWidth;
    const th = tip.offsetHeight;
    if (left + tw > box.width - 4) left = Math.max(4, e.clientX - box.left - tw - 14);
    if (top + th > box.height - 4) top = Math.max(4, e.clientY - box.top - th - 14);
    tip.style.left = `${left}px`;
    tip.style.top = `${top}px`;
  }

  _hideTip() {
    this._el.tip.style.display = "none";
  }

  // ---------------------------------------------------------------- export
  _fileBase(name) {
    const p = this._props;
    return SacKit.sanitizeFileName(name || p.exportFileName || p.widgetName || "Bridge", "Bridge");
  }

  _standaloneSvg() {
    const p = this._props;
    const { W, H } = this._svgSize || { W: 600, H: 360 };
    const showHead = !!(p.showTitle && (p.chartTitle || p.chartSubtitle));
    const fs = Number(p.fontSize) || 12;
    const headH = showHead ? Math.round(fs * 1.25 * 1.3) + (p.chartSubtitle ? Math.round(fs * 1.3) : 0) + 8 : 0;
    const bg = p.backgroundColor && p.backgroundColor !== "transparent" ? p.backgroundColor : "#FFFFFF";
    const esc = SacKit.escapeHtml;
    let head = "";
    if (showHead) {
      head += `<text x="8" y="${Math.round(fs * 1.4)}" font-size="${Math.round(fs * 1.25)}" font-weight="bold" fill="${p.textColor}">${esc(
        p.chartTitle
      )}</text>`;
      if (p.chartSubtitle)
        head += `<text x="8" y="${Math.round(fs * 1.4) + Math.round(fs * 1.35)}" fill="${p.textColor}" opacity="0.75">${esc(p.chartSubtitle)}</text>`;
    }
    const svg =
      `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H + headH}" viewBox="0 0 ${W} ${H + headH}" font-family="${esc(
        p.fontFamily
      )}" font-size="${fs}">` +
      `<rect width="100%" height="100%" fill="${bg}"/>${head}<g transform="translate(0 ${headH})">${this._svgInner || ""}</g></svg>`;
    return { svg, W, H: H + headH, bg };
  }

  _tableRows() {
    const m = this._model;
    const f = this._fmt(m);
    const ms = this._parsed ? this._parsed.measures : [];
    const p = this._props;
    const variance = m.mode === "variance";
    const header = ["Step", "Type", "Value", "Running total", "% of start"];
    if (variance) header.push(ms[clampIndex(p.baseMeasureIndex, ms.length)].label, ms[clampIndex(p.compareMeasureIndex, ms.length)].label);
    header.push("Member / measure ID");
    const rows = m.steps.map((s) => {
      let type = KIND_TEXT[s.kind];
      if (s.kind === "delta") type = s.others ? "Others" : s.residual ? "Residual" : s.favorable == null ? "Step" : s.favorable ? "Favourable" : "Unfavourable";
      const r = [s.label, type, s.value, s.cumulative, s.kind === "delta" ? s.pct : null];
      if (variance) r.push(s.baseValue != null ? s.baseValue : null, s.compareValue != null ? s.compareValue : null);
      r.push(s.memberIds.length ? s.memberIds.join(" | ") : s.measureId || "");
      return { r, s };
    });
    return { header, rows, f, variance };
  }

  async _xlsxBlob() {
    const p = this._props;
    const { header, rows, f, variance } = this._tableRows();
    const wb = new XlsxLite.Workbook({ title: p.chartTitle || "Bridge", creator: `${WIDGET_NAME} ${WIDGET_VERSION}` });
    const ws = wb.addSheet("Bridge", { frozenRows: 4, showGridLines: false });
    const nf = (o, extra) => SacKit.excelNumFmt(o, extra);
    const sTitle = { bold: true, fontSize: 14, fontColor: "#1D2D3E" };
    const sSub = { italic: true, fontColor: "#6A6D70" };
    const sHead = { bold: true, fill: "#EFF1F2", border: "bottom", borderColor: "#89919A", wrap: true, valign: "center" };
    const sHeadR = Object.assign({}, sHead, { align: "right" });
    const fmtValue = nf(f.value);
    const fmtDelta = nf(f.delta, { redNegatives: true });
    const fmtPct = nf(f.pct, { redNegatives: true });
    ws.set(0, 0, p.chartTitle || p.exportFileName || p.widgetName || "Bridge", sTitle);
    ws.set(1, 0, `${{ dimension: "Dimension bridge", variance: "Variance bridge", measures: "Measure bridge" }[this._model.mode]} · exported ${SacKit.stamp()}`, sSub);
    header.forEach((h, c) => ws.set(3, c, h, c >= 2 && c < header.length - 1 ? sHeadR : sHead));
    rows.forEach(({ r, s }, i) => {
      const rr = 4 + i;
      const total = s.kind !== "delta";
      const base = total ? { bold: true, fill: "#F5F6F7", border: "top", borderColor: "#BFC6CC" } : {};
      const typeColor = s.favorable == null ? null : s.favorable ? p.colorFavorable : p.colorUnfavorable;
      r.forEach((v, c) => {
        let st = Object.assign({}, base);
        if (c === 0) st.indent = total ? 0 : 1;
        if (c === 1 && typeColor) st.fontColor = typeColor;
        if (c === 2) st.numFmt = total ? fmtValue : fmtDelta;
        if (c === 3) st.numFmt = fmtValue;
        if (c === 4) st.numFmt = fmtPct;
        if (variance && (c === 5 || c === 6)) st.numFmt = fmtValue;
        ws.set(rr, c, v, Object.keys(st).length ? st : null);
      });
    });
    const lastRow = 3 + rows.length;
    ws.opts.autoFilter = `A4:${XlsxLite.colName(header.length - 1)}${lastRow + 1}`;
    ws.opts.colWidths = header.map((h, c) =>
      c === 0 ? XlsxLite.fitWidth(rows.map((x) => x.r[0]).concat([h]), 18, 60) : c === header.length - 1 ? 28 : c === 1 ? 14 : 16
    );
    // Info sheet
    const info = wb.addSheet("Info", { showGridLines: false });
    const kv = [
      ["Widget", `${WIDGET_NAME} ${WIDGET_VERSION}`],
      ["Widget instance", p.widgetName || ""],
      ["Exported at", SacKit.stamp()],
      ["Bridge mode", this._model.mode],
      ["Dimensions", this._parsed.dims.map((d) => `${d.label} [${d.id}]`).join(", ")],
      ["Measures", this._parsed.measures.map((m) => `${m.label} [${m.id}]`).join(", ")],
      ["Number scale (display)", f.value.scale],
      ["Sort / Top N", `${p.sortSteps} / ${p.topN || "all"}`],
      ["(Sub)total members", p.totalMembers || "—"],
      ["Inverted members", p.invertedMembers || "—"],
      ["Note", "Values are stored as true numbers; scaling is applied with Excel number formats only."],
    ];
    info.set(0, 0, "Export information", sTitle);
    kv.forEach(([k, v], i) => {
      info.set(2 + i, 0, k, { bold: true, fontColor: "#556B82" });
      info.set(2 + i, 1, v, { wrap: true });
    });
    info.opts.colWidths = [26, 90];
    return wb.toBlob();
  }

  /**
   * SAC story export (PDF / PowerPoint / Google Slides), Developer Guide ch. 9: the framework calls this and
   * puts the returned Base64 image into the export, so the bridge is exported exactly as drawn.
   */
  async serializeCustomWidgetToImage() {
    try {
      if (this._model && this._model.steps && this._model.steps.length) {
        const { svg, W, H, bg } = this._standaloneSvg();
        return SacKit.blobToDataUrl(await SacKit.svgStringToPngBlob(svg, W, H, 2, bg));
      }
    } catch (e) {
      console.warn("[WaterfallBridge] export image failed", e);
    }
    return SacKit.blankPngDataUrl(this.clientWidth, this.clientHeight);
  }

  /** Public: export the bridge (png | svg | xlsx | csv). */
  async exportAs(format, fileName) {
    if (!this._model) return false;
    const fmt = String(format || "xlsx").toLowerCase();
    const base = `${this._fileBase(fileName)}_${SacKit.fileStamp()}`;
    try {
      if (fmt === "png") {
        const { svg, W, H, bg } = this._standaloneSvg();
        SacKit.download(await SacKit.svgStringToPngBlob(svg, W, H, 2, bg), `${base}.png`);
      } else if (fmt === "svg") {
        SacKit.download(new Blob([this._standaloneSvg().svg], { type: "image/svg+xml;charset=utf-8" }), `${base}.svg`);
      } else if (fmt === "csv") {
        const { header, rows } = this._tableRows();
        const delim = /^(de|fr|es|it|pt|nl|ru|tr|pl|da|fi|sv|nb|cs|id)/i.test(this._props.locale || navigator.language || "") ? ";" : ",";
        SacKit.download(new Blob([SacKit.toCsv([header, ...rows.map((x) => x.r)], delim)], { type: "text/csv;charset=utf-8" }), `${base}.csv`);
      } else {
        SacKit.download(await this._xlsxBlob(), `${base}.xlsx`);
      }
      return true;
    } catch (err) {
      console.error(`[${WIDGET_NAME}] export failed`, err);
      return false;
    }
  }
}

WaterfallBridge.computeBridge = buildBridge;
WaterfallBridge.parseDataBinding = SacKit.parseDataBinding;
WaterfallBridge.version = WIDGET_VERSION;

if (!customElements.get(WIDGET_TAG)) customElements.define(WIDGET_TAG, WaterfallBridge);
