/* ==========================================================================
 * STARTER TEMPLATE — the smallest complete, data-bound SAC custom widget.
 * Read top to bottom; every SAC touch point is marked with "SAC:".
 * (The build injects WIDGET_TAG and PROPS_DEFAULTS; replace them with literals
 *  if you copy this file into your own project without the kit's build.)
 * ========================================================================== */

// Template is created once per page and cloned per widget instance.
const tpl = document.createElement("template");
tpl.innerHTML = `
  <style>
    /* Styles live inside the shadow DOM: they never leak into SAC and SAC theme/CSS never leaks in. */
    :host { display:block; width:100%; height:100%; font-family:'72',Arial,sans-serif; font-size:12px; color:#32363A; overflow:auto; }
    h3 { margin:6px 8px; font-size:14px; }
    .row { display:grid; grid-template-columns:40% 1fr 70px; gap:8px; align-items:center; padding:3px 8px; cursor:pointer; }
    .row:hover { background:#F2F4F6; }
    .row.sel { background:#DCEBFA; }
    .bar { height:10px; border-radius:3px; }
    .num { text-align:right; font-variant-numeric:tabular-nums; }
    .hint { padding:8px; opacity:.7; }
  </style>
  <h3></h3>
  <div class="body"></div>`;

class StarterWidget extends HTMLElement {
  constructor() {
    super();
    // SAC: the constructor also runs when the widget is dragged from the widget panel (it is cloned) — keep it cheap.
    this._shadow = this.attachShadow({ mode: "open" });
    this._shadow.appendChild(tpl.content.cloneNode(true));
    this._props = Object.assign({}, PROPS_DEFAULTS);
    this._selectedId = "";
    this._shadow.querySelector(".body").addEventListener("click", (e) => this._onRowClick(e));
  }

  // ---------------------------------------------------------------------------
  // SAC lifecycle: called with ONLY the properties that changed (all of them on load).
  // Data binding results arrive here too, under the binding id from the JSON ("dataBinding").
  onCustomWidgetBeforeUpdate(changedProperties) {
    this._props = { ...this._props, ...changedProperties };
  }

  onCustomWidgetAfterUpdate(changedProperties) {
    // Output-only property written by ourselves: nothing to redraw.
    if (Object.keys(changedProperties).length === 1 && "clickedMember" in changedProperties) return;
    this._render();
  }

  // SAC: called when the widget is resized (on the canvas or with the browser window).
  onCustomWidgetResize(width, height) {
    this._render();
  }

  // SAC: called when the widget is removed / the story is closed — release timers, observers, charts.
  onCustomWidgetDestroy() {}

  // ---------------------------------------------------------------------------
  _render() {
    const p = this._props;
    this._shadow.querySelector("h3").textContent = p.widgetTitle;
    const body = this._shadow.querySelector(".body");

    // SAC: the result set of the data binding. state is "success" once data is there.
    const binding = p.dataBinding || this.dataBinding;
    // SAC: the result set has data + metadata; "state" ("loading"/"success") is not always present,
    // so treat a binding that has a data array as loaded.
    const loaded = binding && (binding.state === "success" || (!binding.state && Array.isArray(binding.data)));
    if (!loaded) {
      body.innerHTML = `<div class="hint">${binding && binding.state === "loading" ? "Loading…" : "Builder panel → add a dimension and a measure."}</div>`;
      this.dispatchEvent(new Event("customWidgetRenderComplete")); // SAC: tells export / viewport loading we are done
      return;
    }

    // SAC: metadata maps feed keys (dimensions_0, measures_0 …) to model IDs and descriptions.
    const dimKey = Object.keys(binding.metadata.dimensions || {})[0];
    const meaKey = Object.keys(binding.metadata.mainStructureMembers || {})[0];
    if (!dimKey || !meaKey) {
      body.innerHTML = `<div class="hint">Add one dimension and one measure.</div>`;
      return;
    }
    this._dimensionId = binding.metadata.dimensions[dimKey].id; // used for linked analysis selections

    // SAC: each row = { dimensions_0: {id, label, parentId?}, measures_0: {raw, formatted} }
    this._rows = binding.data.map((row) => ({ id: row[dimKey].id, label: row[dimKey].label, raw: row[meaKey].raw, text: row[meaKey].formatted }));
    const max = Math.max(1e-9, ...this._rows.map((r) => Math.abs(r.raw || 0)));
    const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);

    body.innerHTML = this._rows
      .map(
        (r, i) => `<div class="row ${r.id === this._selectedId ? "sel" : ""}" data-i="${i}">
          <span>${esc(r.label)}</span>
          <span class="bar" style="width:${(Math.abs(r.raw || 0) / max) * 100}%;background:${esc(p.accentColor)}"></span>
          <span class="num">${esc(r.text)}</span></div>`
      )
      .join("");
    this.dispatchEvent(new Event("customWidgetRenderComplete"));
  }

  async _onRowClick(e) {
    const rowEl = e.target.closest(".row");
    if (!rowEl) return;
    const row = this._rows[Number(rowEl.dataset.i)];
    this._selectedId = this._selectedId === row.id ? "" : row.id;
    this._render();

    // SAC: linked analysis ("Filter on Data Point Selection" must be switched on for this widget in the story,
    //      and the JSON must declare supportsLinkedAnalysisFilterOnSelection: true).
    try {
      const dataBindings = this._props.dataBindings || this.dataBindings;
      const la = await Promise.resolve(dataBindings.getDataBinding("dataBinding").getLinkedAnalysis());
      if (this._selectedId) await la.setFilters({ [this._dimensionId]: this._selectedId });
      else await la.removeFilters();
    } catch (err) {
      console.warn("linked analysis not available", err);
    }

    // SAC: write an output property (scripts read it through getClickedMember()) …
    this.dispatchEvent(new CustomEvent("propertiesChanged", { detail: { properties: { clickedMember: this._selectedId } } }));
    // … then fire the event declared in the JSON so the story designer can script onClick.
    this.dispatchEvent(new Event("onClick"));
  }
}

// Guard: the same tag must never be defined twice (e.g. two instances, or re-uploads of the same major version).
if (!customElements.get(WIDGET_TAG)) customElements.define(WIDGET_TAG, StarterWidget);
