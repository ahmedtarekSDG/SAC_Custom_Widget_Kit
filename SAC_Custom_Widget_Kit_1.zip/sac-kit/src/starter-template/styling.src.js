/* ==========================================================================
 * STARTER TEMPLATE — hand-written styling panel.
 * SAC renders this web component in the Styling panel of the widget.
 *  - SAC passes the widget's current property values via onCustomWidgetBeforeUpdate
 *  - the panel sends edits back with a "propertiesChanged" event
 * ========================================================================== */
const panelTpl = document.createElement("template");
panelTpl.innerHTML = `
  <style>
    :host { display:block; font-family:'72',Arial,sans-serif; font-size:12px; }
    label { display:block; margin:8px 0 3px; color:#556B82; }
    input { width:100%; height:26px; box-sizing:border-box; }
  </style>
  <label for="t">Title</label><input id="t" type="text">
  <label for="c">Accent colour</label><input id="c" type="color">`;

class StarterStylingPanel extends HTMLElement {
  constructor() {
    super();
    this._shadow = this.attachShadow({ mode: "open" });
    this._shadow.appendChild(panelTpl.content.cloneNode(true));
    this._title = this._shadow.getElementById("t");
    this._color = this._shadow.getElementById("c");
    // Send each edit back to SAC; SAC then calls onCustomWidgetBefore/AfterUpdate on the widget.
    this._title.addEventListener("change", () => this._send({ widgetTitle: this._title.value }));
    this._color.addEventListener("change", () => this._send({ accentColor: this._color.value }));
  }
  _send(properties) {
    this.dispatchEvent(new CustomEvent("propertiesChanged", { detail: { properties } }));
  }
  // SAC calls this with the widget's property values when the panel opens and whenever they change.
  onCustomWidgetBeforeUpdate(changedProperties) {
    if ("widgetTitle" in changedProperties) this._title.value = changedProperties.widgetTitle;
    if ("accentColor" in changedProperties) this._color.value = changedProperties.accentColor;
  }
  onCustomWidgetAfterUpdate() {}
}
if (!customElements.get(PANEL_TAG)) customElements.define(PANEL_TAG, StarterStylingPanel);
