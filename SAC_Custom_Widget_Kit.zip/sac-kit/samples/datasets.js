/* Sample result sets in the exact shape SAC hands to a custom widget data binding:
 *   { state, data: [ { dimensions_0:{id,label,parentId?}, measures_0:{raw,formatted} } ], metadata:{ dimensions, mainStructureMembers, feeds } }
 * Used by tools/harness (local testing without a tenant). */
(function () {
  const fmt = (v) => (v == null ? "" : (v / 1e6).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
  const uq = (dim, hier, id) => `[${dim}].[${hier}].&[${id}]`;
  const meta = (dims, measures) => ({
    feeds: {
      dimensions: { values: dims.map((_, i) => `dimensions_${i}`), type: "dimension" },
      measures: { values: measures.map((_, i) => `measures_${i}`), type: "mainStructureMember" },
    },
    dimensions: Object.fromEntries(dims.map((d, i) => [`dimensions_${i}`, { id: d.id, description: d.description }])),
    mainStructureMembers: Object.fromEntries(measures.map((m, i) => [`measures_${i}`, { id: m.id, label: m.label }])),
  });
  const row = (dimCells, values) => {
    const r = {};
    dimCells.forEach((c, i) => (r[`dimensions_${i}`] = c));
    values.forEach((v, i) => (r[`measures_${i}`] = { raw: v, formatted: fmt(v) }));
    return r;
  };

  // 1) P&L account hierarchy (parents delivered before children, like a SAC hierarchy)
  const ACC = "Account_7h2kq01";
  const H = "parentId";
  const pnl = [
    ["NI", "Net Income", "", 180],
    ["EBIT", "EBIT", "NI", 230],
    ["GP", "Gross Profit", "EBIT", 400],
    ["REV", "Revenue", "GP", 1000],
    ["COGS", "Cost of Goods Sold", "GP", -600],
    ["OPEX", "Operating Expenses", "EBIT", -170],
    ["SAL", "Salaries & Wages", "OPEX", -100],
    ["RENT", "Rent & Facilities", "OPEX", -50],
    ["MKT", "Marketing", "OPEX", -20],
    ["TAX", "Income Tax", "NI", -50],
  ];
  const pnlBinding = {
    state: "success",
    metadata: meta([{ id: ACC, description: "Account" }], [{ id: "Amount", label: "Amount (SAR)" }]),
    data: pnl.map(([id, label, parent, v]) =>
      row([{ id: uq(ACC, H, id), label, parentId: parent ? uq(ACC, H, parent) : undefined }], [v * 1e6])
    ),
  };

  // 2) Budget vs Actual by region (flat) — variance bridge
  const REG = "Region_3kd02ma";
  const regions = [
    ["SA_C", "KSA Central", 410, 452],
    ["SA_W", "KSA Western", 380, 351],
    ["SA_E", "KSA Eastern", 295, 330],
    ["AE_DXB", "UAE Dubai", 260, 248],
    ["AE_AUH", "UAE Abu Dhabi", 190, 214],
    ["EG_CAI", "Egypt Cairo", 120, 108],
    ["EG_ALX", "Egypt Alexandria", 64, 70],
    ["KW", "Kuwait", 58, 57.5],
    ["QA", "Qatar", 77, 81],
    ["BH", "Bahrain", 33, 31],
    ["OM", "Oman", 41, 41],
  ];
  const varianceBinding = {
    state: "success",
    metadata: meta([{ id: REG, description: "Region" }], [
      { id: "BUDGET", label: "Budget 2026" },
      { id: "ACTUAL", label: "Actual 2026" },
    ]),
    data: regions.map(([id, label, b, a]) => row([{ id, label }], [b * 1e6, a * 1e6])),
  };

  // 3) Price-Volume-Mix: measures are the steps (one total row, no dimension)
  const pvmBinding = {
    state: "success",
    metadata: meta([], [
      { id: "REV_PY", label: "Revenue PY" },
      { id: "PRICE", label: "Price effect" },
      { id: "VOLUME", label: "Volume effect" },
      { id: "MIX", label: "Mix effect" },
      { id: "FX", label: "FX effect" },
      { id: "REV_CY", label: "Revenue CY" },
    ]),
    data: [row([], [1250e6, 84e6, -37e6, 12.5e6, -21e6, 1292e6])],
  };

  // 4) Cash bridge: opening balance + flows (flat, first member is the start)
  const CF = "CashFlow_k29";
  const cash = [
    ["OPEN", "Opening cash", 520],
    ["OCF", "Operating cash flow", 610],
    ["CAPEX", "Capital expenditure", -340],
    ["WC", "Working capital", -95],
    ["DEBT", "Net debt movement", 120],
    ["DIV", "Dividends paid", -200],
    ["FXT", "FX translation", -14],
  ];
  const cashBinding = {
    state: "success",
    metadata: meta([{ id: CF, description: "Cash flow item" }], [{ id: "AMOUNT", label: "Amount" }]),
    data: cash.map(([id, label, v]) => row([{ id, label }], [v * 1e6])),
  };

  // 5) Table: Product x Region with Actual / Budget / PY
  const PRD = "Product_9as8d";
  const products = [
    ["P100", "Laban 1L"],
    ["P110", "Fresh Milk 2L"],
    ["P200", "Mango Juice 1L"],
    ["P210", "Orange Juice 1L"],
    ["P300", "Yoghurt 170g"],
  ];
  const regs = [
    ["SA_C", "KSA Central"],
    ["AE_DXB", "UAE Dubai"],
    ["EG_CAI", "Egypt Cairo"],
  ];
  const tableData = [];
  let seed = 7;
  const rnd = () => ((seed = (seed * 9301 + 49297) % 233280) / 233280);
  products.forEach(([pid, pl]) =>
    regs.forEach(([rid, rl]) => {
      const bud = Math.round((20 + rnd() * 80) * 10) / 10;
      const act = Math.round(bud * (0.82 + rnd() * 0.36) * 10) / 10;
      const py = Math.round(bud * (0.8 + rnd() * 0.3) * 10) / 10;
      tableData.push(row([{ id: pid, label: pl }, { id: rid, label: rl }], [act * 1e6, bud * 1e6, py * 1e6]));
    })
  );
  const tableBinding = {
    state: "success",
    metadata: meta(
      [
        { id: PRD, description: "Product" },
        { id: REG, description: "Region" },
      ],
      [
        { id: "ACTUAL", label: "Actual" },
        { id: "BUDGET", label: "Budget" },
        { id: "PY", label: "Prior Year" },
      ]
    ),
    data: tableData,
  };

  // 6) Table: cost-centre hierarchy with Actual / Budget
  const CC = "CostCenter_77x";
  const ccRows = [
    ["CORP", "Corporate", "", 0, 0],
    ["FIN", "Finance", "CORP", 0, 0],
    ["FIN_ACC", "Accounting", "FIN", 4.2, 4.0],
    ["FIN_TRS", "Treasury", "FIN", 2.1, 2.4],
    ["FIN_CTRL", "Controlling", "FIN", 3.3, 3.1],
    ["IT", "IT", "CORP", 0, 0],
    ["IT_INF", "Infrastructure", "IT", 7.8, 7.0],
    ["IT_APP", "Applications", "IT", 6.1, 6.5],
    ["HR", "Human Resources", "CORP", 0, 0],
    ["HR_REC", "Recruiting", "HR", 1.9, 2.2],
    ["HR_PAY", "Payroll", "HR", 1.2, 1.1],
  ];
  // aggregate parents
  const kids = {};
  ccRows.forEach((r) => {
    if (r[2]) (kids[r[2]] = kids[r[2]] || []).push(r);
  });
  const agg = (r) => {
    const k = kids[r[0]];
    if (!k) return [r[3], r[4]];
    const s = k.map(agg).reduce((a, b) => [a[0] + b[0], a[1] + b[1]], [0, 0]);
    r[3] = s[0];
    r[4] = s[1];
    return s;
  };
  agg(ccRows[0]);
  const ccBinding = {
    state: "success",
    metadata: meta([{ id: CC, description: "Cost Centre" }], [
      { id: "ACTUAL", label: "Actual" },
      { id: "BUDGET", label: "Budget" },
    ]),
    data: ccRows.map(([id, label, parent, a, b]) =>
      row([{ id: uq(CC, "H1", id), label, parentId: parent ? uq(CC, "H1", parent) : undefined }], [a * 1e6, b * 1e6])
    ),
  };

  // 7) Time series (month) for KPI sparkline / line charts
  const MON = "Date_m12";
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const tsBinding = {
    state: "success",
    metadata: meta([{ id: MON, description: "Month" }], [
      { id: "ACTUAL", label: "Revenue Actual" },
      { id: "BUDGET", label: "Revenue Budget" },
    ]),
    data: months.map((m, i) =>
      row([{ id: `2026${String(i + 1).padStart(2, "0")}`, label: `${m} 2026` }], [(98 + i * 4 + (i % 3) * 6) * 1e6, (100 + i * 4.2) * 1e6])
    ),
  };

  window.SAC_SAMPLES = {
    pnl_hierarchy: { label: "P&L account hierarchy (Amount)", binding: pnlBinding },
    variance_region: { label: "Budget vs Actual by region", binding: varianceBinding },
    pvm_measures: { label: "Price-Volume-Mix (measures as steps)", binding: pvmBinding },
    cash_bridge: { label: "Cash bridge (opening + flows)", binding: cashBinding },
    product_region: { label: "Product × Region (Actual, Budget, PY)", binding: tableBinding },
    costcenter_hierarchy: { label: "Cost-centre hierarchy (Actual, Budget)", binding: ccBinding },
    monthly_series: { label: "Monthly revenue (Actual, Budget)", binding: tsBinding },
    loading: { label: "(state: loading)", binding: { state: "loading", data: [], metadata: {} } },
    empty: { label: "(no data bound)", binding: null },
  };
})();
